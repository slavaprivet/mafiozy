"""Registered tiny native compile check of isolated home helpers and hooks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def pins(folder):return {p.relative_to(folder).as_posix():sha(p) for p in folder.rglob('*') if p.is_file() and '.godot' not in p.parts}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('name');a=parser.parse_args()
    assert a.name and all(c.isalnum() or c in '_-' for c in a.name)
    game=ROOT/'outputs/coordinator31_npc57/game'
    manifest=ROOT/'outputs/coordinator31_npc57/extended31/stage58_04/CANDIDATE58.json'
    expected=read(manifest)['source_pins'];assert pins(game)==expected
    scheduler=ROOT/'tools/godot/test_scheduler.py'
    assert sha(scheduler)=='adcb834390e476edd118f62d8e3e5b391c6ebc97925391e66beeb80430ba8373'
    engine=Path(os.environ['LOCALAPPDATA'])/'MafioziTools/Godot-4.7.2/Godot_v4.7.2-stable_win64.exe'
    lock=ROOT/'docs/godot/ENGINE_LOCK.json';assert sha(engine)==read(lock)['editor']['gui']['sha256']
    run=HERE/'runs'/a.name;run.mkdir(parents=True,exist_ok=False)
    payloads=[HERE/'entry_parse58.gd',Path(__file__).resolve(),*sorted((HERE/'patch').rglob('*.gd'))]
    control_files=[manifest,scheduler,lock,ROOT/'godot/current_version.json',*payloads]
    controls={str(p.resolve()):sha(p) for p in control_files}
    save(run/'CONTROL_PINS.json',controls);save(run/'HARNESS.json',{p.relative_to(HERE).as_posix():sha(p) for p in payloads})
    with zipfile.ZipFile(run/'HARNESS.zip','x',zipfile.ZIP_DEFLATED) as archive:
        for path in control_files:archive.write(path,path.relative_to(ROOT).as_posix())
    command=[str(engine),'--headless','--path',str(game),'--script',str(HERE/'entry_parse58.gd'),'--','--patch='+str(HERE/'patch'),'--out='+str(run/'PARSE58.json')]
    record=dict(passed=False,physics_simulation=False,production_modified=False,command=command,engine_sha256=sha(engine),manifest_sha256=sha(manifest))
    sys.path.insert(0,str(ROOT));from tools.godot.test_scheduler import Lease,probe,ERRORS
    try:
        save(run/'PROBE.json',probe('headless',game,'read'))
        with Lease('headless',game,'read',60) as lease:
            record['lease']=lease.request
            assert pins(game)==expected and controls=={str(p.resolve()):sha(p) for p in control_files}
            save(run/'SOURCE.json',expected);start=time.monotonic()
            with (run/'stdout.log').open('wb') as out,(run/'stderr.log').open('wb') as err:
                child=subprocess.Popen(command,cwd=game,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
                try:record['child']=lease.register_child(child);child.wait(timeout=45)
                finally:
                    if child.poll() is None:child.terminate();child.wait(timeout=10)
            record['wall_s']=time.monotonic()-start;record['exit_code']=child.returncode
            after=pins(game);save(run/'SOURCE_AFTER.json',after)
            record['source_drift']=[k for k in expected.keys()|after.keys() if expected.get(k)!=after.get(k)]
            after_controls={str(p.resolve()):sha(p) for p in control_files};save(run/'CONTROL_PINS_AFTER.json',after_controls)
            record['control_drift']=[k for k in controls if controls[k]!=after_controls.get(k)]
            record['errors']=[line for name in ['stdout.log','stderr.log'] for line in (run/name).read_text(encoding='utf-8-sig',errors='replace').splitlines() if ERRORS.search(line)]
            record['stderr_bytes']=(run/'stderr.log').stat().st_size
            record['passed']=child.returncode==0 and read(run/'PARSE58.json')['passed'] and not record['source_drift'] and not record['control_drift'] and not record['errors'] and not record['stderr_bytes']
    except Exception as exc:record['error']=type(exc).__name__+': '+str(exc)
    finally:
        if not (run/'SOURCE_AFTER.json').exists():save(run/'SOURCE_AFTER.json',pins(game))
        save(run/'RUN.json',record)
    print(json.dumps({k:v for k,v in record.items() if k not in ['command','lease','child']}))
    return 0 if record['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
