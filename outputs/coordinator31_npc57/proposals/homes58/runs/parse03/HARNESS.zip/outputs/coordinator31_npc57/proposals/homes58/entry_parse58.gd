extends SceneTree
var keep: Array=[]
func _initialize()->void: call_deferred("_run")
func _arg(prefix: String)->String:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with(prefix):return arg.trim_prefix(prefix)
	return ""
func _run()->void:
	await create_timer(2.0).timeout
	var base: String=_arg("--patch=")
	var checks: Dictionary={}
	for name: String in ["npc_home_pose58.gd","npc_home_claim58.gd","npc_home_route58.gd","npc_home_controller58.gd"]:
		var script: Script=load(base.path_join("scripts/homes").path_join(name))
		checks[name]=script!=null and script.can_instantiate()
		if checks[name]:
			script.take_over_path("res://scripts/homes/"+name)
			keep.append(script);keep.append(script.new())
	for relative: String in ["scripts/navigation/npc_passage31.gd","scripts/npc_visual/preview_resident_host.gd"]:
		var script: GDScript=GDScript.new()
		# The new helper is intentionally not installed in production yet. Compile
		# the exact host text with only its new preload path rebound to this package.
		script.source_code=FileAccess.get_file_as_string(base.path_join(relative)).replace("res://scripts/homes/npc_home_pose58.gd",base.path_join("scripts/homes/npc_home_pose58.gd").replace("\\","/"))
		script.take_over_path(base.path_join(relative)+".parse58.gd")
		var error: int=script.reload()
		checks[relative]=error==OK and script.can_instantiate()
		keep.append(script)
	var passed:=true
	for value: bool in checks.values(): passed=passed and value
	var result: Dictionary={"passed":passed,"checks":checks,"scope":"Native parse/construct only; host's new preload is rebound to the external candidate helper. No physical home, sleep, collision or lifecycle acceptance."}
	var file:=FileAccess.open(_arg("--out="),FileAccess.WRITE)
	file.store_string(JSON.stringify(result,"\t"));file.close()
	print("HOME58_PARSE ",JSON.stringify(result));quit(0 if passed else 1)
