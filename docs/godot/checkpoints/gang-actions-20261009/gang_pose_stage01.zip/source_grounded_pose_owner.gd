extends RefCounted
## Same-life physical pose owner. HP, death decisions and source admission belong
## to the registry/medical owner. Call tick once AFTER physics, outside query flush.
const Ragdoll = preload("res://scripts/npc_visual/npc_ragdoll_host.gd")
const Pose = preload("res://scripts/character_physics/character_physics_pose.gd")
const Clearance = preload("res://scripts/character_physics/recovery_clearance.gd")
const SurfaceBounds = preload("res://scripts/character_physics/recovery_surface_bounds.gd")
const GET_UP_SECONDS := 0.9
var mode := "UNBOUND"
var _host: RefCounted
var _pose: RefCounted
var _clearance: RefCounted
var _surface: RefCounted
var _actor: WeakRef
var _model: WeakRef
var _rig: WeakRef
var _capsule: WeakRef
var _providers: Dictionary = {}
var _binding: Dictionary = {}
var _canonical: Array[Transform3D] = []
var _names: Array[String] = []
var _lease: Dictionary = {}
var _busy := false
var _error := ""
var _event_id := ""
var _request_id := ""
var _standing_layer := 0
var _standing_mask := 0
var _guard: StaticBody3D
var _guard_shape: CollisionShape3D
var _query := PhysicsShapeQueryParameters3D.new()
var _query_box := BoxShape3D.new()
var _target := Transform3D.IDENTITY
var _committed_target := Transform3D.IDENTITY
var _frozen_actor := Transform3D.IDENTITY
var _initial_pose: Dictionary = {}
var _accepted_skin: Dictionary = {}
var _physical: Dictionary = {}
var _elapsed := 0.0
var _rollback_count := 0
var _clearance_checks := 0
var _support_rid: RID
var _support_y := 0.0
var _pending_sweep: Dictionary = {}
var _pending_target := Transform3D.IDENTITY
var _committed := false
var _life_plan: Dictionary = {}
var _completion_done := false
var _completion_state := "none"

func _callback(key: String) -> Callable:
	var value: Variant = _providers.get(key)
	return value if value is Callable else Callable()

func _call(key: String, args: Array = [], fallback: Variant = null) -> Variant:
	var callback := _callback(key)
	return callback.callv(args) if callback.is_valid() else fallback

func _result(ok: bool, reason: String = "") -> Dictionary:
	_error = reason
	return {"ok":ok,"reason":reason,"mode":mode,"source_event_id":_event_id,
		"request_id":_request_id,"hp_authority":false,"same_body":_nodes_current(),"committed":_committed}

func observed_body() -> CharacterBody3D:
	return _actor.get_ref() as CharacterBody3D if _actor != null else null

func observed_rig() -> Skeleton3D:
	return _rig.get_ref() as Skeleton3D if _rig != null else null

func observed_guard() -> StaticBody3D:
	return _guard if is_instance_valid(_guard) else null

func owned_bodies() -> Array[RigidBody3D]:
	var values: Array[RigidBody3D] = []
	if _host != null: values.assign(_host.owned_bodies())
	return values

func _nodes_current() -> bool:
	var actor := observed_body()
	var rig := observed_rig()
	var model: Node3D = _model.get_ref() as Node3D if _model != null else null
	if not is_instance_valid(actor) or not is_instance_valid(rig) or not is_instance_valid(model): return false
	if not actor.is_inside_tree() or actor.is_queued_for_deletion() or not rig.is_inside_tree() or rig.is_queued_for_deletion(): return false
	if not actor.is_ancestor_of(model) or not model.is_ancestor_of(rig) or rig.get_bone_count() != 28: return false
	if actor.get_instance_id() != _binding.get("body_instance_id") or actor.get_rid() != _binding.get("body_rid") or rig.get_instance_id() != _binding.get("rig_instance_id"): return false
	for i in _names.size():
		if str(rig.get_bone_name(i)) != _names[i]: return false
	return true

func _same_binding(value: Variant) -> bool:
	if not value is Dictionary: return false
	for key: String in Ragdoll.IDENTITY_FIELDS:
		if typeof(value.get(key)) != typeof(_binding.get(key)) or value.get(key) != _binding.get(key): return false
	return true

func _current(binding: Dictionary) -> bool:
	return _same_binding(binding) and _nodes_current() and _call("current_binding",[binding.duplicate()],false) == true and _nodes_current()

func _events(request: Dictionary) -> Dictionary:
	var value: Variant = _call("confirmed_events",[request],{})
	return value if value is Dictionary else {}

func _writers_current() -> bool:
	return not _lease.is_empty() and _current(_binding) and _call("writers_current",[_binding.duplicate(),_lease.lease_id],false) == true and _current(_binding)

func configure(body: CharacterBody3D, model: Node3D, token: Dictionary,
		providers: Dictionary, options: Dictionary = {}) -> Dictionary:
	if not Thread.is_main_thread() or _busy or mode != "UNBOUND": return _result(false,"lifetime")
	for key: String in ["current_binding","confirmed_events","acquire_writers","writers_current","release_writers","source_recovery"]:
		if not providers.get(key) is Callable or not providers[key].is_valid(): return _result(false,"provider:"+key)
	if not is_instance_valid(body) or not is_instance_valid(model) or token.get("body") != body or not token.get("rig") is Skeleton3D: return _result(false,"actual_binding")
	if not body.is_inside_tree() or not body.is_ancestor_of(model) or not model.is_ancestor_of(token.rig): return _result(false,"model_ancestry")
	var capsule: CollisionShape3D
	for child: Node in body.get_children():
		if child is CollisionShape3D and not child.disabled:
			if capsule != null or not child.shape is CapsuleShape3D: return _result(false,"standing_shape")
			capsule = child
	if capsule == null or body.collision_layer == 0 or body.collision_mask == 0: return _result(false,"standing_capsule")
	if not Clearance._uniform(body.global_basis) or not body.global_basis.get_scale().is_equal_approx(Vector3.ONE): return _result(false,"body_scale")
	if body.global_basis.y.dot(Vector3.UP)<0.999: return _result(false,"standing_body_upright")
	for key: String in Ragdoll.IDENTITY_FIELDS:
		if not token.has(key): return _result(false,"identity:"+key)
		_binding[key] = token[key]
	_actor = weakref(body)
	_model = weakref(model)
	_rig = weakref(token.rig)
	_capsule = weakref(capsule)
	_providers = providers.duplicate()
	if not _current(_binding): return _result(false,"source_admission")
	var rig := observed_rig()
	for i in rig.get_bone_count():
		_canonical.append(rig.get_bone_pose(i))
		_names.append(str(rig.get_bone_name(i)))
	_pose = Pose.new()
	# Use the actual body as motion root; _to_motion includes the fixture's real
	# UniformModelScale/offset. No assumed hero height or invented bone transforms.
	if not _pose.configure(rig,body,_canonical,1.0,model): return _configure_failed("source_skin_binding")
	_clearance = Clearance.new()
	if not _clearance.configure(_pose): return _configure_failed("source_clearance_binding")
	_surface = SurfaceBounds.new()
	if not _surface.configure(_pose): return _configure_failed("source_geometry_guard_binding")
	_host = Ragdoll.new()
	var configured: Dictionary = _host.configure(token,body.get_parent() as Node3D,_current,_events,options)
	if not configured.get("ok",false): return _configure_failed("ragdoll:"+str(configured.get("error")))
	_standing_layer = body.collision_layer
	_standing_mask = body.collision_mask
	_query.shape = _query_box
	_query.margin = 0.001
	_query.collision_mask = _standing_mask
	mode = "IDLE"
	return _result(true)

func _configure_failed(reason: String) -> Dictionary:
	if _host != null: _host.dispose()
	if _surface != null: _surface.dispose()
	if _pose != null: _pose.dispose()
	_host = null
	_pose = null
	_clearance = null
	mode = "RETIRED"
	return _result(false,reason)

func down(event_id: String) -> Dictionary:
	if not Thread.is_main_thread() or _busy or mode != "IDLE" or event_id.is_empty() or not _lease.is_empty() or _completion_state == "pending": return _result(false,"down_lifetime")
	_busy = true
	if not _current(_binding): _busy = false; return _result(false,"stale_binding")
	var receipt := _events({"mode":"event","binding":_binding.duplicate(),"event_id":event_id})
	var event: Variant = receipt.get("event")
	if receipt.get("known") != true or receipt.get("completed") != true or receipt.get("accepted") != true or not _same_binding(receipt.get("binding")) or not event is Dictionary or event.get("kind") != "source_medical_down":
		_busy = false
		return _result(false,"medical_event_not_confirmed")
	var lease: Variant = _call("acquire_writers",[_binding.duplicate()],{})
	if not lease is Dictionary or lease.get("ok") != true or not _same_binding(lease.get("binding")) or not lease.get("lease_id") is String or lease.lease_id.is_empty():
		_busy = false
		return _result(false,"writer_lease")
	_lease = lease.duplicate()
	if not _writers_current(): _busy = false; return _result(false,"writer_not_suspended")
	var started: Dictionary = _host.activate(event_id)
	if not started.get("ok",false):
		_release_writers("down_rejected")
		_busy = false
		return _result(false,"activate:"+str(started.get("error")))
	_event_id = event_id
	_committed = false
	mode = "ACTIVE"
	_busy = false
	return _result(true)

func _release_writers(reason: String) -> bool:
	if _lease.is_empty(): return true
	if not _current(_binding): return false
	var released: Variant = _call("release_writers",[_binding.duplicate(),_lease.lease_id,reason],false)
	if released == true: _lease.clear()
	return released == true

func _exclusions() -> Array[RID]:
	var values: Array[RID] = []
	var actor := observed_body()
	if is_instance_valid(actor): values.append(actor.get_rid())
	for part: RigidBody3D in owned_bodies():
		if is_instance_valid(part): values.append(part.get_rid())
	if is_instance_valid(_guard): values.append(_guard.get_rid())
	return values

func _floor_hit(point: Vector3) -> Dictionary:
	if not _current(_binding): return {}
	var ray := PhysicsRayQueryParameters3D.create(point+Vector3.UP*0.5,point-Vector3.UP*2.5,_standing_mask,_exclusions())
	var hit := observed_body().get_world_3d().direct_space_state.intersect_ray(ray)
	if hit.is_empty() or not hit.get("position") is Vector3 or not hit.position.is_finite() or not hit.get("normal") is Vector3 or hit.normal.dot(Vector3.UP)<0.7: return {}
	if not hit.get("rid") is RID or not hit.rid.is_valid(): return {}
	var state := PhysicsServer3D.body_get_direct_state(hit.rid)
	if state == null or state.linear_velocity.length()>0.1 or state.angular_velocity.length()>0.1: return {}
	return hit

func _floor_height(x: float, z: float) -> float:
	var hit := _floor_hit(Vector3(x,_support_y+0.25,z))
	return float(hit.position.y) if not hit.is_empty() else NAN

func _standing_clear(target: Transform3D) -> bool:
	var shape: CollisionShape3D = _capsule.get_ref() as CollisionShape3D
	if not is_instance_valid(shape) or shape.disabled or not shape.shape is CapsuleShape3D: return false
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = shape.shape
	query.transform = target*shape.transform
	query.margin = 0.001
	query.collision_mask = _standing_mask
	query.exclude = _exclusions()
	return observed_body().get_world_3d().direct_space_state.intersect_shape(query,1).is_empty()

func _skin_clear(sweep: Dictionary) -> bool:
	_clearance_checks += 1
	if not sweep.get("valid",false) or not sweep.get("bounds") is AABB: return false
	var bounds: AABB = sweep.bounds
	if not bounds.position.is_finite() or not bounds.size.is_finite(): return false
	_query_box.size = bounds.size.max(Vector3.ONE*0.001)
	_query.transform = Transform3D(Basis.IDENTITY,bounds.get_center())
	_query.exclude = _exclusions()
	var space := observed_body().get_world_3d().direct_space_state
	var contacts: Array[Vector3] = space.collide_shape(_query,32)
	if contacts.size()>=64 or contacts.size()%2 != 0: return false
	var below_support := false
	for i in range(0,contacts.size(),2):
		var separation := contacts[i+1]-contacts[i]
		if separation.length()<0.000001 or separation.length()>float(sweep.get("angular_padding_m",0.0))+0.012: return false
		if separation.normalized().dot(Vector3.UP)>=0.95 and absf(contacts[i+1].y-_support_y)<=0.01: continue
		if maxf(contacts[i].y,contacts[i+1].y)>_support_y+0.0001: return false
		below_support = true
	if below_support:
		var lower := bounds.position
		var upper := bounds.end
		lower.y = maxf(lower.y,_support_y+0.002)
		if upper.y<=lower.y: return false
		_query_box.size = (upper-lower).max(Vector3.ONE*0.001)
		_query.transform = Transform3D(Basis.IDENTITY,(upper+lower)*0.5)
		if not space.intersect_shape(_query,1).is_empty(): return false
	return true

func _source_release(phase: String) -> bool:
	var request := {"phase":phase,"request_id":_request_id,"down_event_id":_event_id,"binding":_binding.duplicate(),"target":_pending_target,
		"source_id":_life_plan.get("source_id"),"member_id":_life_plan.get("member_id"),"event_id":_life_plan.get("event_id"),
		"source_generation":_life_plan.get("source_generation"),"physical_epoch":_life_plan.get("physical_epoch"),
		"body":observed_body(),"revision":_life_plan.get("revision")}
	var proof: Variant = _call("source_recovery",[request],{})
	return proof is Dictionary and proof.get("ok") == true and proof.get("medical_release_allowed") == true and proof.get("request_id") == _request_id and proof.get("phase") == phase and _same_binding(proof.get("binding")) and _writers_current()

func _recovery_clear(phase: String, binding: Dictionary) -> bool:
	if not _same_binding(binding) or not _writers_current() or observed_body().global_transform != _frozen_actor: return false
	# Existing source guard observes mesh/skin resources, topology and transforms.
	if _surface == null or not _surface._live(): return false
	var support := _floor_hit(_target.origin+Vector3.UP*0.25)
	if support.is_empty() or support.rid != _support_rid or absf(support.position.y-_support_y)>0.002: return false
	return _standing_clear(_pending_target) and _skin_clear(_pending_sweep) and _source_release(phase)

func _frames(selected: Dictionary, world: Transform3D) -> Dictionary:
	var values: Dictionary = {}
	var global: Array[Transform3D] = []
	var poses: Array = selected.get("poses",[])
	if poses.size() != 28: return values
	var offset: Vector3 = selected.get("visual_offset",Vector3.ZERO)
	var rotation: Quaternion = selected.get("visual_rotation",Quaternion.IDENTITY)
	var prefix: Transform3D = Transform3D(world.basis,world*offset)*Transform3D(Basis(rotation),Vector3.ZERO)*(_pose.get("_to_motion") as Transform3D)
	var rig := observed_rig()
	for i in 28:
		var parent := rig.get_bone_parent(i)
		global.append(poses[i] if parent<0 else global[parent]*poses[i])
		values[_names[i]] = prefix*global[i]
	return values

func _physical_skin_bounds(frames: Dictionary) -> Dictionary:
	var points := PackedVector3Array()
	for bone: int in _pose.get("_rigid"):
		if not frames.get(_names[bone]) is Transform3D: return {}
		points.append_array((frames[_names[bone]] as Transform3D)*(_pose.get("_rigid")[bone] as PackedVector3Array))
	var first := 0
	for end: int in _pose.get("_ends"):
		var point := Vector3.ZERO
		for at in range(first,end):
			var frame: Transform3D = frames[_names[_pose.get("_bones")[at]]]
			point += frame.basis*_pose.get("_points")[at]+frame.origin*_pose.get("_weights")[at]
		points.append(point)
		first = end
	if points.is_empty(): return {}
	var bounds := AABB(points[0],Vector3.ZERO)
	for point: Vector3 in points:
		if not point.is_finite(): return {}
		bounds = bounds.expand(point)
	return {"valid":true,"bounds":bounds}

func _guard_bounds(bounds: AABB) -> void:
	(_guard_shape.shape as BoxShape3D).size = bounds.size.max(Vector3.ONE*0.001)
	_guard.global_transform = Transform3D(Basis.IDENTITY,bounds.get_center())

func _create_guard(bounds: AABB) -> void:
	_guard = StaticBody3D.new()
	_guard.name = "SameLifeRecoveryGuard"
	_guard.collision_layer = 0
	_guard.collision_mask = 0
	_guard_shape = CollisionShape3D.new()
	_guard_shape.shape = BoxShape3D.new()
	_guard.add_child(_guard_shape)
	observed_body().get_parent().add_child(_guard)
	_guard_bounds(bounds)
	_guard.collision_layer = _standing_layer
	_guard.collision_mask = _standing_mask

func _remove_guard() -> void:
	if is_instance_valid(_guard):
		_guard.collision_layer = 0
		_guard.collision_mask = 0
		_guard.queue_free()
	_guard = null
	_guard_shape = null

func recover(plan: Dictionary) -> Dictionary:
	if not Thread.is_main_thread() or _busy or mode != "ACTIVE": return _result(false,"recovery_lifetime")
	if plan.get("source_id") != _binding.source_id or plan.get("body") != observed_body() or plan.get("physical_epoch") != _binding.life_generation:
		return _result(false,"recovery_plan_identity")
	if not plan.get("source_generation") is int or plan.source_generation<0 or not plan.get("revision") is int or plan.revision<1:
		return _result(false,"recovery_plan_revision")
	if not plan.get("event_id") is String or plan.event_id.is_empty() or not plan.get("completion") is Callable or not plan.completion.is_valid():
		return _result(false,"recovery_completion")
	if not _writers_current(): return _result(false,"writer_lease")
	_busy = true
	var advanced: Dictionary = _host.advance()
	if not advanced.get("ok",false): _busy = false; return _result(false,"physical_snapshot")
	_physical = advanced.get("physical",{})
	if not _physical.get("settled",false): _busy = false; return _result(false,"physical_not_settled")
	var anchor: Variant = _physical.get("anchor_world")
	if not anchor is Vector3 or not anchor.is_finite(): _busy = false; return _result(false,"physical_anchor")
	var support := _floor_hit(anchor)
	if support.is_empty(): _busy = false; return _result(false,"standing_support")
	_support_rid = support.rid
	_support_y = support.position.y
	_frozen_actor = observed_body().global_transform
	_target = Transform3D(_frozen_actor.basis,support.position+Vector3.UP*0.003)
	_pending_target = _target
	_request_id = plan.event_id
	_life_plan = plan.duplicate()
	_completion_done = false
	_completion_state = "not_admitted"
	if not _standing_clear(_target): _busy = false; return _result(false,"standing_capsule_blocked")
	# Re-express real settled world frames around the candidate root WITHOUT
	# moving the actual actor. The first recovered pose still occupies that skin.
	var adjusted: Dictionary = {}
	var rebase := _frozen_actor*_target.affine_inverse()
	for name: String in _physical.bone_world_frames:
		adjusted[name] = rebase*(_physical.bone_world_frames[name] as Transform3D)
	_initial_pose = _pose.from_world_frames(adjusted,int(_binding.rig_epoch))
	_accepted_skin = _clearance.snapshot(_initial_pose,_target,false)
	var real_skin := _physical_skin_bounds(_physical.bone_world_frames)
	if not _accepted_skin.get("valid",false) or not real_skin.get("valid",false): _busy = false; return _result(false,"source_skin")
	_pending_sweep = {"valid":true,"bounds":(_accepted_skin.bounds as AABB).merge(real_skin.bounds).grow(0.00002),"angular_padding_m":0.00002}
	if not _recovery_clear("begin",_binding): _busy = false; return _result(false,"recovery_admission")
	_create_guard(_pending_sweep.bounds)
	var begun: Dictionary = _host.begin_recovery(_guard,_recovery_clear)
	if not begun.get("ok",false): _remove_guard(); _busy = false; return _result(false,"begin:"+str(begun.get("error")))
	mode = "RECOVERING"
	_elapsed = 0.0
	var applied: Dictionary = _host.apply_recovery_pose(_frames(_initial_pose,_target),_recovery_clear)
	_busy = false
	if not applied.get("ok",false): return cancel_recovery("initial_pose_blocked")
	_completion_state = "pending"
	var result := _result(true)
	result["pending"] = true
	return result

func _recover_step(delta: float) -> Dictionary:
	if not _writers_current(): return _rollback("writer_changed")
	var proposed := minf(GET_UP_SECONDS,_elapsed+delta)
	var selected: Dictionary = _pose.blend_release(_initial_pose,0.55+0.45*clampf(proposed/GET_UP_SECONDS,0.0,1.0),_floor_height,_target,int(_binding.rig_epoch))
	if not selected.get("valid",false): return _rollback("source_pose:"+str(selected.get("reason")))
	var next: Dictionary = _clearance.snapshot(selected,_target)
	_pending_sweep = _clearance.between(_accepted_skin,next)
	_pending_target = _target
	if not _pending_sweep.get("valid",false) or not _recovery_clear("step",_binding): return _rollback("skin_or_source_blocked")
	_guard_bounds(_pending_sweep.bounds)
	var applied: Dictionary = _host.apply_recovery_pose(_frames(selected,_target),_recovery_clear)
	if not applied.get("ok",false): return _rollback("apply_rejected")
	_accepted_skin = next
	_elapsed = proposed
	if _elapsed<GET_UP_SECONDS: return _result(true)
	# Final source standing pose has no visual rotation. Fold only its exact
	# grounded offset into the SAME actor root, then restore canonical bone poses.
	var rotation: Quaternion = selected.get("visual_rotation",Quaternion.IDENTITY)
	if rotation.angle_to(Quaternion.IDENTITY)>0.00001: return _rollback("standing_rotation")
	_pending_target = Transform3D(_target.basis,_target*(selected.visual_offset as Vector3))
	_pending_sweep = {"valid":true,"bounds":next.bounds,"angular_padding_m":0.0}
	var poses: Array[Transform3D] = []
	poses.assign(selected.poses)
	var committed: Dictionary = _host.commit_recovery(_pending_target,poses,_recovery_clear)
	if not committed.get("ok",false): return _rollback("commit_rejected")
	_committed = true
	_committed_target = _pending_target
	mode = "IDLE"
	_remove_guard()
	if not _release_writers("recovered"): return _result(false,"physical_committed_writer_release_pending")
	_complete(true,"recovered")
	return _result(true)

func _complete(ok: bool, reason: String) -> void:
	if _completion_done or _completion_state != "pending": return
	_completion_done = true
	if not _current(_binding):
		_completion_state = "suppressed_stale_life"
		return
	var callback: Variant = _life_plan.get("completion")
	if not callback is Callable or not callback.is_valid():
		_completion_state = "completion_unavailable"
		return
	_completion_state = "committed" if ok else "rolled_back"
	# Mark before dispatch: completion may synchronously heal, change generation,
	# retire the old owner or issue another order. It cannot be delivered twice.
	callback.call({"ok":ok,"physical_committed":ok and _committed,"event_id":_life_plan.event_id,
		"body_instance_id":_binding.body_instance_id,"revision":_life_plan.revision,"reason":reason,
		"source_id":_binding.source_id,"physical_epoch":_binding.life_generation,
		"source_generation":_life_plan.source_generation})

func tick(delta: float = 0.0) -> Dictionary:
	if not Thread.is_main_thread() or _busy or not is_finite(delta) or delta<0 or delta>0.1: return _result(false,"tick_lifetime_or_delta")
	if mode == "IDLE":
		if _committed and (_lease.is_empty() or _release_writers("recovered")): _complete(true,"recovered")
		return _result(_lease.is_empty(),"" if _lease.is_empty() else "writer_release_pending")
	if mode == "RECOVERING":
		_busy = true
		var result := _recover_step(delta)
		_busy = false
		return result
	if mode != "ACTIVE": return _result(false,"inactive")
	if not _writers_current(): return _result(false,"writer_lease_lost")
	_busy = true
	var advanced: Dictionary = _host.advance()
	mode = str(_host.mode)
	if advanced.get("ok",false): _physical = advanced.get("physical",{})
	_busy = false
	return _result(advanced.get("ok",false),str(advanced.get("error","")))

func cancel_recovery(reason: String = "blocked") -> Dictionary:
	if not Thread.is_main_thread() or _busy or mode != "RECOVERING": return _result(false,"cancel_lifetime")
	_busy = true
	var result := _rollback(reason)
	_busy = false
	return result

func _rollback(reason: String) -> Dictionary:
	var resumed: Dictionary = _host.cancel_recovery(reason)
	mode = str(_host.mode)
	_rollback_count += 1
	if resumed.get("ok",false): _remove_guard()
	# On failed rollback the source host keeps its colliding guard. Never remove
	# the only remaining collision owner or release animation into a disabled body.
	_complete(false,reason if resumed.get("ok",false) else "rollback_hold")
	return _result(false,reason if resumed.get("ok",false) else "rollback_hold:"+str(resumed.get("error")))

func evidence() -> Dictionary:
	var actor := observed_body()
	var rig := observed_rig()
	return {"mode":mode,"last_error":_error,"binding":_binding.duplicate(),"hp_authority":false,
		"body_instance_id":actor.get_instance_id() if is_instance_valid(actor) else 0,
		"body_rid":actor.get_rid() if is_instance_valid(actor) else RID(),
		"rig_instance_id":rig.get_instance_id() if is_instance_valid(rig) else 0,
		"guard_instance_id":_guard.get_instance_id() if is_instance_valid(_guard) else 0,
		"writer_lease_active":not _lease.is_empty(),"standing_layer":_standing_layer,"standing_mask":_standing_mask,
		"actual_layer":actor.collision_layer if is_instance_valid(actor) else 0,"actual_mask":actor.collision_mask if is_instance_valid(actor) else 0,
		"source_event_id":_event_id,"request_id":_request_id,"physical":_physical.duplicate(true),
		"completion_state":_completion_state,"completion_done":_completion_done,
		"recovery_progress":_elapsed/GET_UP_SECONDS,"rollback_count":_rollback_count,"clearance_checks":_clearance_checks,
		"recovery_target":_target,"last_committed_target":_committed_target,"canonical_poses":_canonical.duplicate(),
		"accepted_skin_bounds":_accepted_skin.get("bounds"),"committed":_committed,"native_validation":"NOT_RUN"}

func dispose(reason: String = "disposed") -> Dictionary:
	if not Thread.is_main_thread() or _busy: return _result(false,"dispose_busy")
	if mode == "RETIRED" and _host == null and _pose == null and not is_instance_valid(_guard): return _result(true)
	# An active life may be retired only after its source registry revokes it or
	# its actual node leaves the tree. A live downed body is not silently deleted.
	if mode in ["ACTIVE","RECOVERING","RECOVERY_HOLD"] and _current(_binding): return _result(false,"active_life_requires_source_retirement")
	if mode == "IDLE" and not _release_writers(reason): return _result(false,"writer_release_pending")
	if _host != null: _host.dispose()
	if _surface != null: _surface.dispose()
	if _pose != null: _pose.dispose()
	_remove_guard()
	_host = null
	_pose = null
	_surface = null
	mode = "RETIRED"
	_providers.clear()
	return _result(true)
