extends RefCounted
## Read-only observer for the ONE shared QA scene. It never downs, recovers,
## changes HP/filters/poses, fabricates events, or creates substitute actors.
## All handles below must come from the real integrated owner/scene.

static func _check(out: Array, id: String, passed: bool, observed: Variant = null) -> void:
	out.append({"id": id, "pass": passed, "observed": observed})

static func _enabled_shapes(node: Node) -> int:
	var count: int = 0
	for child: Node in node.get_children():
		if child is CollisionShape3D and child.shape != null and not child.disabled:
			count += 1
		count += _enabled_shapes(child)
	return count

static func _pose_finite(poses: Array) -> bool:
	if poses.size() != 28:
		return false
	for pose: Variant in poses:
		if not pose is Transform3D or not pose.is_finite():
			return false
	return true

static func _same_pose(a: Array, b: Array, epsilon: float = 0.002) -> bool:
	if not _pose_finite(a) or not _pose_finite(b):
		return false
	for index: int in 28:
		var left: Transform3D = a[index]
		var right: Transform3D = b[index]
		if left.origin.distance_to(right.origin) > epsilon:
			return false
		if left.basis.x.distance_to(right.basis.x) > epsilon or left.basis.y.distance_to(right.basis.y) > epsilon or left.basis.z.distance_to(right.basis.z) > epsilon:
			return false
	return true

static func capture(handles: Dictionary) -> Dictionary:
	# Mandatory: actual pose_owner, capsule, actual walking writer Node,
	# and current_binding() reading the authoritative current source/life binding.
	var owner: Variant = handles.get("pose_owner")
	if not is_instance_valid(owner) or not owner.has_method("observed_body") or not owner.has_method("observed_rig") or not owner.has_method("owned_bodies") or not owner.has_method("evidence"):
		return {"valid": false, "reason": "actual_pose_owner_missing"}
	var body: Variant = owner.observed_body()
	var rig: Variant = owner.observed_rig()
	var capsule: Variant = handles.get("capsule")
	var writer: Variant = handles.get("walk_writer")
	var current: Variant = handles.get("current_binding")
	if not is_instance_valid(body) or not body is CharacterBody3D or not body.is_inside_tree():
		return {"valid": false, "reason": "actual_body_missing"}
	if not is_instance_valid(rig) or not rig is Skeleton3D or not body.is_ancestor_of(rig) or rig.get_bone_count() != 28:
		return {"valid": false, "reason": "actual_source_skeleton_missing"}
	if not is_instance_valid(capsule) or not capsule is CollisionShape3D or not capsule.shape is CapsuleShape3D or not body.is_ancestor_of(capsule):
		return {"valid": false, "reason": "actual_capsule_missing"}
	if not is_instance_valid(writer) or not writer is Node or not writer.is_inside_tree():
		return {"valid": false, "reason": "actual_walk_writer_missing"}
	if not current is Callable or not current.is_valid():
		return {"valid": false, "reason": "binding_reader_missing"}
	var binding: Variant = current.call()
	if not binding is Dictionary or not binding.get("source_id") is String or str(binding.source_id).is_empty() or not binding.get("life_generation") is int:
		return {"valid": false, "reason": "source_life_binding_missing"}
	var status: Dictionary = owner.evidence()
	var guard: Variant = owner.observed_guard() if owner.has_method("observed_guard") else null
	var guard_state: Dictionary = {"enabled": false}
	if is_instance_valid(guard) and guard is CollisionObject3D:
		guard_state = {"instance": guard.get_instance_id(), "layer": guard.collision_layer, "mask": guard.collision_mask,
			"enabled": guard.is_inside_tree() and guard.collision_layer != 0 and guard.collision_mask != 0 and _enabled_shapes(guard) > 0}
	var local_poses: Array = []
	var world_poses: Array = []
	for bone: int in rig.get_bone_count():
		local_poses.append(rig.get_bone_pose(bone))
		world_poses.append(rig.global_transform * rig.get_bone_global_pose(bone))
	var parts: Array = []
	var active_parts: int = 0
	for part: Variant in owner.owned_bodies():
		if not is_instance_valid(part) or not part is RigidBody3D:
			return {"valid": false, "reason": "invalid_owned_rigidbody"}
		var colliders: int = _enabled_shapes(part)
		var active: bool = part.is_inside_tree() and not part.freeze and part.collision_layer != 0 and part.collision_mask != 0 and colliders > 0
		if active:
			active_parts += 1
		parts.append({"instance": part.get_instance_id(), "rid": part.get_rid().get_id(), "active": active, "freeze": part.freeze, "shapes": colliders, "layer": part.collision_layer, "mask": part.collision_mask, "transform": part.global_transform})
	return {"valid": _pose_finite(local_poses) and _pose_finite(world_poses),
		"physics_frame": Engine.get_physics_frames(), "body": body.get_instance_id(), "body_rid": body.get_rid().get_id(),
		"rig": rig.get_instance_id(), "source_id": binding.source_id, "life_generation": binding.life_generation,
		"binding": binding.duplicate(), "owner_evidence": status, "mode": status.get("mode", ""), "writer_lease_active": status.get("writer_lease_active", false),
		"body_transform": body.global_transform, "capsule": capsule.get_instance_id(), "capsule_disabled": capsule.disabled,
		"capsule_layer": body.collision_layer, "capsule_mask": body.collision_mask,
		"writer": writer.get_instance_id(), "writer_process": writer.is_processing(), "writer_physics": writer.is_physics_processing(),
		"local_poses": local_poses, "world_poses": world_poses, "parts": parts, "active_parts": active_parts, "guard": guard_state}

static func _identity(a: Dictionary, b: Dictionary) -> bool:
	if not a.get("valid", false) or not b.get("valid", false):
		return false
	for key: String in ["body", "body_rid", "rig", "source_id", "life_generation", "capsule", "writer"]:
		if a.get(key) != b.get(key):
			return false
	return true

static func _down_physical(sample: Dictionary) -> bool:
	return sample.get("valid", false) and sample.get("mode") == "ACTIVE" and sample.get("writer_lease_active") == true and int(sample.get("active_parts", 0)) > 0 and sample.get("capsule_layer") == 0 and sample.get("capsule_mask") == 0 and not sample.get("writer_process", true) and not sample.get("writer_physics", true)

static func check_down(before: Dictionary, down: Dictionary, receipt: Dictionary, event: Dictionary) -> Array:
	var out: Array = []
	_check(out, "pose_down_same_body_rig_source_life", _identity(before, down))
	_check(out, "pose_down_real_medical_event", event.get("confirmed") == true and event.get("kind") == "source_medical_down" and event.get("medical_downed") == true and event.get("source_id") == before.get("source_id") and event.get("life_generation") == before.get("life_generation") and event.get("local_preview_hp_revision") is int and event.get("local_preview_hp_revision", 0) > 0 and str(event.get("id", "")) != "")
	_check(out, "pose_down_owner_used_same_event", down.get("owner_evidence", {}).get("source_event_id") == event.get("id") and str(event.get("id", "")) != "")
	_check(out, "pose_down_receipt_and_physical_lease", receipt.get("ok") == true and _down_physical(down), {"receipt": receipt, "mode": down.get("mode"), "active_parts": down.get("active_parts")})
	_check(out, "pose_down_distinct_physics_sample", int(down.get("physics_frame", -1)) > int(before.get("physics_frame", -1)))
	_check(out, "pose_down_actual_skeleton_changed", not _same_pose(before.get("world_poses", []), down.get("world_poses", [])) and _pose_finite(down.get("world_poses", [])))
	return out

static func check_recovery_lease(before_down: Dictionary, during: Dictionary) -> Array:
	var out: Array = []
	_check(out, "pose_recovery_same_body_rig_source_life", _identity(before_down, during))
	_check(out, "pose_recovery_single_physical_lease", during.get("mode") in ["RECOVERING", "RECOVERY_HOLD"] and during.get("guard", {}).get("enabled") == true and during.get("active_parts") == 0 and during.get("capsule_layer") == 0 and during.get("capsule_mask") == 0)
	_check(out, "pose_recovery_writer_still_suspended", during.get("writer_lease_active") == true and not during.get("writer_process", true) and not during.get("writer_physics", true))
	_check(out, "pose_recovery_actual_skin_pose_finite", _pose_finite(during.get("world_poses", [])))
	return out

static func check_blocked(before_down: Dictionary, after: Dictionary, receipt: Dictionary) -> Array:
	var out: Array = []
	_check(out, "pose_blocked_not_success", receipt.has("ok") and receipt.ok is bool and not receipt.ok, receipt)
	_check(out, "pose_blocked_same_body_rig_source_life", _identity(before_down, after))
	_check(out, "pose_blocked_keeps_down_capsule_and_writer_lease", _down_physical(after) and before_down.get("capsule_disabled") == after.get("capsule_disabled"))
	# Physics may continue evolving the lying pose: exact bone equality is NOT required.
	_check(out, "pose_blocked_finite_actual_skeleton", _pose_finite(after.get("world_poses", [])))
	return out

static func check_recovered(standing_before: Dictionary, after: Dictionary, receipt: Dictionary, expected_world: Transform3D, expected_local_poses: Array) -> Array:
	# expected poses/transform must come from the independently captured approved
	# source standing pose + real clearance result, never copied from `after`.
	var out: Array = []
	_check(out, "pose_recover_same_body_rig_source_life", _identity(standing_before, after))
	_check(out, "pose_recover_confirmed", receipt.get("ok") == true and after.get("mode") == "IDLE", receipt)
	_check(out, "pose_recover_capsule_filters_restored", after.get("capsule_layer") == standing_before.get("capsule_layer") and after.get("capsule_mask") == standing_before.get("capsule_mask") and after.get("capsule_disabled") == standing_before.get("capsule_disabled") and int(after.get("capsule_layer", 0)) != 0 and int(after.get("capsule_mask", 0)) != 0)
	_check(out, "pose_recover_rigid_pool_disabled", after.get("valid", false) and int(after.get("active_parts", -1)) == 0)
	_check(out, "pose_recover_guard_disabled", after.get("guard", {}).get("enabled") == false)
	_check(out, "pose_recover_walk_writer_restored", after.get("writer_lease_active") == false and after.get("writer_process") == standing_before.get("writer_process") and after.get("writer_physics") == standing_before.get("writer_physics") and (standing_before.get("writer_process", false) or standing_before.get("writer_physics", false)))
	var world: Variant = after.get("body_transform")
	_check(out, "pose_recover_real_standing_root", world is Transform3D and expected_world.is_finite() and world.is_equal_approx(expected_world))
	_check(out, "pose_recover_real_source_standing_skeleton", _same_pose(after.get("local_poses", []), expected_local_poses))
	return out

static func check_denied(case_id: String, before: Dictionary, after: Dictionary, receipt: Dictionary) -> Array:
	# Snapshot the CURRENT replacement actor for stale/rebound tests. Do not compare
	# an old destroyed actor with the replacement and call that preservation.
	var out: Array = []
	_check(out, case_id + "_denied", receipt.has("ok") and receipt.ok is bool and not receipt.ok, receipt)
	_check(out, case_id + "_current_actor_identity_preserved", _identity(before, after))
	_check(out, case_id + "_current_capsule_writer_preserved", before.get("capsule_layer") == after.get("capsule_layer") and before.get("capsule_mask") == after.get("capsule_mask") and before.get("capsule_disabled") == after.get("capsule_disabled") and before.get("writer_process") == after.get("writer_process") and before.get("writer_physics") == after.get("writer_physics"))
	_check(out, case_id + "_current_pose_preserved", _same_pose(before.get("local_poses", []), after.get("local_poses", [])) and before.get("body_transform") == after.get("body_transform"))
	return out
