extends RefCounted
## Identity admission for the existing common-scene actors and exact source hero.
## This is a local registry, not the imported preview/current286 resident packet.
## No actor creation, HP mutation, damage acknowledgement or collision override.
const PROVENANCE := "common_scene_actual_source_hero"
const HERO_SHA256 := "8130dfb1f7eb91bff31e932feef1717672070a6767ccc726d7cb1ee23133fd00"
const IDENTITY_FIELDS := ["session_id", "source_id", "render_id", "bridge_id",
	"descriptor_sha256", "placement_mode", "life_generation", "rig_epoch",
	"body_instance_id", "body_rid", "rig_instance_id"]
const CAPSULE_RADIUS := 0.30
const CAPSULE_HEIGHT := 1.9
var _world: WeakRef
var _life_owner: WeakRef
var _source_model: PackedScene
var _session := ""
var _records: Dictionary = {}
var _configured := false
var _busy := false
var _disposed := false
var _last_error := ""

func configure(world: Node3D, lifecycle_owner: RefCounted, options: Dictionary = {}) -> Dictionary:
	if _configured or _busy or _disposed or not Thread.is_main_thread():
		return _reject("admission_lifetime")
	if not _node_live(world) or not is_instance_valid(lifecycle_owner):
		return _reject("live_registry_and_lifecycle_owner_required")
	for method: String in ["is_local", "original_residents", "original_resident",
		"source_body", "model_metadata", "registered_actor_body"]:
		if not world.has_method(method):
			return _reject("missing_registry_method:" + method)
	for method: String in ["actor_life", "physical_event", "source_recovery"]:
		if not lifecycle_owner.has_method(method):
			return _reject("missing_lifecycle_method:" + method)
	var source: Variant = options.get("source_model")
	if not source is PackedScene or source.resource_path.is_empty() \
		or not FileAccess.file_exists(source.resource_path) \
		or FileAccess.get_sha256(source.resource_path).to_lower() != HERO_SHA256:
		return _reject("verified_source_hero_required")
	if world.is_local() != true:
		return _reject("local_scene_required")
	_busy = true
	_world = weakref(world)
	_life_owner = weakref(lifecycle_owner)
	_source_model = source
	# A new registry gets a new session; no imported/browser identity is claimed.
	_session = "common-scene:%d:%d:%d" % [world.get_instance_id(), get_instance_id(), Time.get_ticks_usec()]
	var originals: Variant = world.original_residents()
	var staged := {}
	if originals is Array and not originals.is_empty():
		for original: Variant in originals:
			var record := _capture(original)
			if record.is_empty() or staged.has(record.source_id):
				staged.clear()
				break
			staged[record.source_id] = record
	var player_record := _capture(world.player, true) if not staged.is_empty() else {}
	if staged.has("player") or player_record.is_empty():
		staged.clear()
	else:
		staged["player"] = player_record
	if staged.is_empty() or not _context_live():
		_world = null
		_life_owner = null
		_source_model = null
		_session = ""
		_busy = false
		return _reject("original_actor_or_life_admission_failed")
	_records = staged
	_configured = true
	_busy = false
	return {"ok": true, "provenance": PROVENANCE, "session_id": _session,
		"actors": _records.size(), "asset_sha256": HERO_SHA256, "source_authority": false}

func _node_live(value: Variant) -> bool:
	return value is Node and is_instance_valid(value) and value.is_inside_tree() \
		and not value.is_queued_for_deletion()

func _context_live() -> bool:
	if _disposed or _world == null or _life_owner == null:
		return false
	var world: Variant = _world.get_ref()
	return _node_live(world) and world.is_local() == true and is_instance_valid(_life_owner.get_ref())

func _capture(original: Variant, is_player: bool = false) -> Dictionary:
	if not _context_live() or (not is_player and not original is Dictionary):
		return {}
	var source_id: Variant = "player" if is_player else original.get("id")
	if not source_id is String or source_id.is_empty() or source_id.length() > 256:
		return {}
	var world: Node3D = _world.get_ref()
	var body: Variant = world.player if is_player else world.source_body(source_id)
	if not body is CharacterBody3D or not _node_live(body) or not world.is_ancestor_of(body):
		return {}
	if is_player:
		if not is_same(original, body) or body.get_meta("isHero", false) != true:
			return {}
	elif not is_same(world.original_resident(source_id), original) \
		or not is_same(world.registered_actor_body(original), body) \
		or not is_same(original.get("body"), body) or body.get_meta("sourceBotId", "") != source_id:
		return {}
	var metadata: Variant = world.model_metadata(source_id)
	if not metadata is Dictionary:
		return {}
	var model: Variant = metadata.get("model")
	var rig: Variant = metadata.get("skeleton")
	if not model is Node3D or not _node_live(model) or model.scene_file_path != _source_model.resource_path \
		or not rig is Skeleton3D or not _node_live(rig) or rig.get_bone_count() != 28 \
		or not body.is_ancestor_of(model) or not model.is_ancestor_of(rig):
		return {}
	var rigs: Array[Node] = model.find_children("*", "Skeleton3D", true, false)
	if rigs.size() != 1 or not is_same(rigs[0], rig):
		return {}
	var shapes: Array[Node] = body.find_children("*", "CollisionShape3D", true, false)
	if shapes.size() != 1 or not shapes[0] is CollisionShape3D:
		return {}
	var shape: CollisionShape3D = shapes[0]
	if shape.get_parent() != body or not _capsule_current(shape) or not _sole_shape(body, shape) \
		or body.collision_layer == 0 or body.collision_mask == 0 or not body.global_transform.is_finite():
		return {}
	var topology: Array = []
	var names: Dictionary = {}
	var rests: Array[Transform3D] = []
	for index: int in 28:
		var name := str(rig.get_bone_name(index))
		var parent: int = rig.get_bone_parent(index)
		var rest: Transform3D = rig.get_bone_rest(index)
		if name.is_empty() or names.has(name) or parent < -1 or parent >= 28 \
			or parent == index or not rest.is_finite():
			return {}
		names[name] = true
		rests.append(rest)
		topology.append({"name": name, "parent": parent, "rest": _transform_values(rest)})
	var nodes: Array = []
	var transforms: Array[Transform3D] = []
	var chain: Array = []
	var node: Node = rig
	while not is_same(node, body):
		if not node is Node3D or not _node_live(node) or nodes.size() >= 32 \
			or not node.transform.is_finite():
			return {}
		nodes.append(weakref(node))
		transforms.append(node.transform)
		chain.append({"instance_id": node.get_instance_id(), "name": str(node.name),
			"transform": _transform_values(node.transform)})
		node = node.get_parent()
	var render_id := "common-source-hero:%d" % model.get_instance_id()
	var descriptor := {"provenance": PROVENANCE, "asset_sha256": HERO_SHA256,
		"source_model": _source_model.resource_path, "source_id": source_id,
		"session_id": _session, "body_instance_id": body.get_instance_id(),
		"model_instance_id": model.get_instance_id(), "rig_instance_id": rig.get_instance_id(),
		"body_rid": body.get_rid().get_id(), "rig_epoch": rig.get_instance_id(),
		"topology": topology, "model_chain": chain,
		"capsule_radius": shape.shape.radius, "capsule_height": shape.shape.height,
		"capsule_transform": _transform_values(shape.transform),
		"walking_layer": body.collision_layer, "walking_mask": body.collision_mask}
	var record := {"source_id": source_id, "original": original, "is_player": is_player,
		"body": weakref(body), "body_rid": body.get_rid(), "model": weakref(model), "rig": weakref(rig),
		"shape": weakref(shape), "shape_resource": shape.shape, "shape_transform": shape.transform,
		"nodes": nodes, "transforms": transforms, "topology": topology, "rests": rests,
		"walking_layer": body.collision_layer, "walking_mask": body.collision_mask,
		"render_id": render_id, "highest_epoch": 0, "source_generation": -1, "hp_revision": 0,
		"descriptor_sha256": JSON.stringify(descriptor, "", true).sha256_text()}
	# Actor identity can be recorded before recruitment. A token is issued only
	# when the actual lifecycle owner later supplies that actor's current lease.
	return record

func _capsule_current(shape: CollisionShape3D) -> bool:
	return _node_live(shape) and not shape.disabled and shape.shape is CapsuleShape3D \
		and is_equal_approx(shape.shape.radius, CAPSULE_RADIUS) \
		and is_equal_approx(shape.shape.height, CAPSULE_HEIGHT) \
		and shape.transform.is_equal_approx(Transform3D(Basis.IDENTITY, Vector3(0, CAPSULE_HEIGHT * 0.5, 0)))

func _sole_shape(body: CharacterBody3D, shape: CollisionShape3D) -> bool:
	var owners: Array = body.get_shape_owners()
	return owners.size() == 1 and is_same(body.shape_owner_get_owner(owners[0]), shape) \
		and body.shape_owner_get_shape_count(owners[0]) == 1

func _life(record: Dictionary) -> Dictionary:
	if not _context_live():
		return {}
	var owner: RefCounted = _life_owner.get_ref()
	var body: Variant = record.body.get_ref()
	if not _node_live(body):
		return {}
	var life: Variant = owner.call("actor_life", record.source_id, body)
	if not _context_live() or not life is Dictionary or life.get("source_id") != record.source_id \
		or not is_same(life.get("body"), body) or life.get("owner_instance_id") != owner.get_instance_id() \
		or not life.get("life_generation") is int or life.life_generation < 1 \
		or not life.get("source_life_generation") is int or life.source_life_generation < 0 \
		or not life.get("hp_revision") is int or life.hp_revision < 0:
		return {}
	var world: Node3D = _world.get_ref()
	if record.is_player:
		if not is_same(world.player, body) or not is_same(record.original, body) \
			or body.get_meta("isHero", false) != true \
			or body.get_meta("life_generation", 0) != life.source_life_generation \
			or not _number(body.get_meta("hp", null)) or not _number(body.get_meta("max_hp", null)):
			return {}
	elif not life.get("row") is Dictionary or not is_same(world.source_body(record.source_id), body) \
		or not is_same(world.original_resident(record.source_id), record.original) \
		or not is_same(world.registered_actor_body(life.row), body) \
		or life.row.get("sourceBotId") != record.source_id:
		return {}
	# Source generation zero is legitimate. Never rewrite it to satisfy the
	# physical host's positive-epoch convention, or accept a reused old epoch.
	if not record.is_player and life.row.has("_mercenaryLifeGeneration") \
		and life.row._mercenaryLifeGeneration != life.source_life_generation:
		return {}
	if life.life_generation < record.highest_epoch \
		or (life.life_generation == record.highest_epoch and
			(life.source_life_generation != record.source_generation or life.hp_revision < record.hp_revision)):
		return {}
	record.highest_epoch = life.life_generation
	record.source_generation = life.source_life_generation
	record.hp_revision = life.hp_revision
	return life

func _record_current(record: Dictionary, walking: bool) -> bool:
	if not _context_live():
		return false
	var body: Variant = record.body.get_ref()
	var model: Variant = record.model.get_ref()
	var rig: Variant = record.rig.get_ref()
	var shape: Variant = record.shape.get_ref()
	if not _node_live(body) or not _node_live(model) or not _node_live(rig) or not _node_live(shape) \
		or not body.global_transform.is_finite() or body.get_rid() != record.body_rid \
		or not _world.get_ref().is_ancestor_of(body) or body.get_world_3d() != _world.get_ref().get_world_3d() \
		or not body.is_ancestor_of(model) or not model.is_ancestor_of(rig) \
		or model.scene_file_path != _source_model.resource_path or rig.get_bone_count() != 28 \
		or shape.get_parent() != body or not is_same(shape.shape, record.shape_resource) \
		or not _capsule_current(shape) or not _sole_shape(body, shape):
		return false
	if record.is_player:
		if not is_same(_world.get_ref().player, body) or body.get_meta("isHero", false) != true:
			return false
	elif body.get_meta("sourceBotId", "") != record.source_id:
		return false
	var metadata: Variant = _world.get_ref().model_metadata(record.source_id)
	if not metadata is Dictionary or not is_same(metadata.get("model"), model) \
		or not is_same(metadata.get("skeleton"), rig):
		return false
	var walker: bool = body.collision_layer == record.walking_layer and body.collision_mask == record.walking_mask
	if not walker and (walking or body.collision_layer != 0 or body.collision_mask != 0):
		return false
	var previous: Node = null
	for index: int in record.nodes.size():
		var node: Variant = record.nodes[index].get_ref()
		if not _node_live(node) or not node.transform.is_equal_approx(record.transforms[index]) \
			or (previous != null and not is_same(previous.get_parent(), node)):
			return false
		previous = node
	if previous == null or not is_same(previous.get_parent(), body):
		return false
	for index: int in 28:
		if str(rig.get_bone_name(index)) != record.topology[index].name \
			or rig.get_bone_parent(index) != record.topology[index].parent \
			or not rig.get_bone_rest(index).is_equal_approx(record.rests[index]):
			return false
	return true

func _token(record: Dictionary, life: Dictionary) -> Dictionary:
	var body: CharacterBody3D = record.body.get_ref()
	var rig: Skeleton3D = record.rig.get_ref()
	return {"ok": true, "source_authority": false, "provenance": PROVENANCE,
		"session_id": _session, "source_id": record.source_id,
		"bridge_id": record.render_id, "render_id": record.render_id,
		"descriptor_sha256": record.descriptor_sha256, "placement_mode": "COMMON_SCENE_ACTUAL",
		"life_generation": life.life_generation, "body": body, "rig": rig,
		"source_life_generation": life.source_life_generation,
		"body_instance_id": body.get_instance_id(), "body_rid": body.get_rid(),
		"rig_instance_id": rig.get_instance_id(), "rig_epoch": rig.get_instance_id()}

func target_from_collider(collider: Object) -> Dictionary:
	if not _configured or _disposed or _busy or not Thread.is_main_thread() \
		or not collider is CharacterBody3D or not _node_live(collider):
		return _reject("current_actual_walker_required")
	_busy = true
	var result := {}
	for record: Dictionary in _records.values():
		if not is_same(record.body.get_ref(), collider):
			continue
		var life := _life(record)
		if not life.is_empty() and _record_current(record, true):
			result = _token(record, life)
		break
	_busy = false
	return result if not result.is_empty() else _reject("actor_registry_or_life_stale")

func _current(binding: Dictionary) -> Dictionary:
	var record: Dictionary = _records.get(binding.get("source_id"), {})
	if record.is_empty():
		return {}
	var life := _life(record)
	if life.is_empty() or not _record_current(record, false):
		return {}
	var expected := _token(record, life)
	for field: String in IDENTITY_FIELDS:
		if typeof(binding.get(field)) != typeof(expected[field]) or binding.get(field) != expected[field]:
			return {}
	return life

func physical_life_current(binding: Dictionary) -> bool:
	if not _configured or _disposed or _busy or not Thread.is_main_thread():
		return false
	_busy = true
	var current := not _current(binding).is_empty()
	_busy = false
	return current

## Borrowed actual nodes plus a new token Dictionary. Never copies actor rows.
## A manager may prewarm one pose owner for each of these existing walkers.
func registration_records() -> Array:
	var result: Array = []
	for source_id: Variant in _records.keys():
		var actor := actor_binding(str(source_id), true)
		if actor.get("ok") != true:
			continue
		result.append(actor)
	return result

func actor_binding(source_id: String, walking: bool = false) -> Dictionary:
	if not _configured or _disposed or _busy or not Thread.is_main_thread():
		return _reject("actor_binding_unavailable")
	_busy = true
	var result := {}
	var record: Dictionary = _records.get(source_id, {})
	if not record.is_empty():
		var life := _life(record)
		if not life.is_empty() and _record_current(record, walking):
			result = {"ok": true, "source_id": source_id, "body": record.body.get_ref(),
				"model": record.model.get_ref(), "rig": record.rig.get_ref(), "token": _token(record, life)}
	_busy = false
	return result if not result.is_empty() else _reject("actor_registry_or_life_stale")

## Route only a unique, committed same-life medical receipt. An event ID alone
## never establishes identity, and this function does not activate a pose.
func resolve_event(event_id: String) -> Dictionary:
	if event_id.is_empty() or not _configured or _disposed or _busy or not Thread.is_main_thread():
		return _reject("event_route_unavailable")
	var result := {}
	for source_id: Variant in _records.keys():
		var actor := actor_binding(str(source_id))
		if actor.get("ok") != true:
			continue
		var binding := {}
		for field: String in IDENTITY_FIELDS:
			binding[field] = actor.token[field]
		var receipt := physical_event({"mode": "event", "binding": binding, "event_id": event_id})
		if receipt.is_empty():
			continue
		if not result.is_empty():
			return _reject("event_actor_ambiguous")
		result = actor
		result.receipt = receipt
	return result if not result.is_empty() else _reject("event_actor_not_admitted")

func physical_event(request: Dictionary) -> Dictionary:
	if not _configured or _disposed or _busy or not Thread.is_main_thread() \
		or request.get("mode") != "event" or not request.get("binding") is Dictionary:
		return {}
	_busy = true
	var life := _current(request.binding)
	var result := {}
	if not life.is_empty():
		var raw: Variant = _life_owner.get_ref().call("physical_event", request.duplicate(true))
		var fresh := _current(request.binding)
		if raw is Dictionary and not fresh.is_empty() and raw.get("known") == true \
			and raw.get("completed") == true and raw.get("accepted") == true \
			and raw.get("binding") == request.binding and raw.get("event") is Dictionary:
			var event: Dictionary = raw.event
			# A metadata-only caller cannot create an admitted medical event here.
			if event.get("kind") == "source_medical_down" and event.get("id") == request.get("event_id") \
				and _medical_event_shape(event) \
				and event.get("source_id") == fresh.source_id \
				and event.get("life_generation") == fresh.life_generation \
				and event.get("local_preview_hp_revision") is int \
				and event.local_preview_hp_revision > 0 \
				and event.local_preview_hp_revision == fresh.hp_revision \
				and _medical_down_current(fresh):
				result = raw.duplicate(true)
	_busy = false
	return result

func source_recovery(request: Dictionary) -> Dictionary:
	if not _configured or _disposed or _busy or not Thread.is_main_thread() \
		or not request.get("binding") is Dictionary or request.get("phase") not in ["begin", "step", "commit"] \
		or not request.get("request_id") is String or request.request_id.is_empty() \
		or not request.get("down_event_id") is String or request.down_event_id.is_empty() \
		or not request.get("target") is Transform3D or not request.target.is_finite():
		return _reject("recovery_request_invalid")
	_busy = true
	var life := _current(request.binding)
	var result := {}
	if not life.is_empty() and _medical_down_current(life):
		var raw: Variant = _life_owner.get_ref().call("source_recovery", request.duplicate(true))
		var fresh := _current(request.binding)
		if raw is Dictionary and not fresh.is_empty() and raw.get("ok") == true \
			and fresh.hp_revision == life.hp_revision \
			and raw.get("binding") == request.binding and raw.get("request_id") == request.get("request_id") \
			and raw.get("phase") == request.phase and raw.get("medical_release_allowed") == true \
			and _medical_down_current(fresh):
			result = raw.duplicate(true)
	_busy = false
	return result if not result.is_empty() else _reject("medical_release_not_admitted")

func _medical_event_shape(event: Dictionary) -> bool:
	if not event.get("confirmed") is bool or not event.confirmed \
		or not event.get("medical_downed") is bool or not event.medical_downed \
		or not event.get("already_solved_by_godot") is bool or not event.get("apply_again") is bool \
		or event.already_solved_by_godot == event.apply_again:
		return false
	for field: String in ["linear_velocity", "angular_velocity", "reference_point", "impulse_ns"]:
		if not event.get(field) is Vector3 or not event[field].is_finite():
			return false
	return true

func _medical_down_current(life: Dictionary) -> bool:
	if life.source_id == "player":
		var body: CharacterBody3D = life.body
		return _number(body.get_meta("hp", null)) and float(body.get_meta("hp")) <= 0 \
			and body.get_meta("dead", false) == true and body.get_meta("_localDeath", false) == true \
			and body.get_meta("_mercenaryVehicleExplosionFatal", false) != true
	# Canonical gang down state is HP-based (mercenary_world.js:566,660,771).
	# _medicalDowned is a civilian field, not an additional gang admission gate.
	return _number(life.row.get("hp")) \
		and float(life.row.hp) <= 0 and life.row.get("dead", false) != true \
		and life.row.get("_mercenaryVehicleExplosionFatal", false) != true

func _number(value: Variant) -> bool:
	return (value is float or value is int) and is_finite(float(value))

func _transform_values(value: Transform3D) -> Array:
	return [value.basis.x.x, value.basis.x.y, value.basis.x.z,
		value.basis.y.x, value.basis.y.y, value.basis.y.z,
		value.basis.z.x, value.basis.z.y, value.basis.z.z,
		value.origin.x, value.origin.y, value.origin.z]

func _reject(reason: String) -> Dictionary:
	_last_error = reason
	return {"ok": false, "reason": reason, "provenance": PROVENANCE, "preserved": true}

func diagnostics() -> Dictionary:
	return {"configured": _configured, "disposed": _disposed, "provenance": PROVENANCE,
		"session_id": _session, "actors": _records.size(), "asset_sha256": HERO_SHA256,
		"last_error": _last_error, "source_authority": false, "medical_authority": false}

func dispose() -> void:
	_disposed = true
	_configured = false
	_records.clear()
	_world = null
	_life_owner = null
	_source_model = null
