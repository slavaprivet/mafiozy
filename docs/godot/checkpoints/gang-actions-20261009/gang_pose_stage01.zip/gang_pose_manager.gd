extends RefCounted
## Routes genuine common-scene medical events to one physical owner per actor.
## HP, source life generations, effects and movement remain external authorities.
const Admission = preload("gang_actor_admission.gd")
const PoseOwner = preload("source_grounded_pose_owner.gd")

var _admission: RefCounted
var _owners: Dictionary = {}
var _bindings: Dictionary = {}
var _writers: Dictionary = {}
var _options: Dictionary = {}
var _configured := false
var _disposed := false
var _busy := false
var _last_error := ""

func _reject(reason: String) -> Dictionary:
	_last_error = reason
	return {"ok":false,"reason":reason,"physical_committed":false}

func configure(world: Node3D, life_owner: RefCounted, source_model: PackedScene,
		writer_providers: Dictionary, options: Dictionary = {}) -> Dictionary:
	if _configured or _disposed or _busy or not Thread.is_main_thread():
		return _reject("manager_lifetime")
	for key: String in ["acquire_writers","writers_current","release_writers"]:
		var callback: Variant = writer_providers.get(key)
		if not callback is Callable or not callback.is_valid():
			return _reject("writer_provider:"+key)
	_busy = true
	var admission := Admission.new()
	var receipt: Dictionary = admission.configure(world,life_owner,{"source_model":source_model})
	if receipt.get("ok") != true:
		admission.dispose()
		_busy = false
		return _reject("admission:"+str(receipt.get("reason","rejected")))
	_admission = admission
	_writers = writer_providers.duplicate()
	_options = options.duplicate(true)
	_configured = true
	_busy = false
	return {"ok":true,"provenance":receipt.get("provenance"),"session_id":receipt.get("session_id"),
		"lazy_physical_owners":true,"physical_committed":false}

func _ready_for_call() -> bool:
	return _configured and not _disposed and not _busy and Thread.is_main_thread() \
		and is_instance_valid(_admission)

func _same_life(left: Dictionary, right: Dictionary) -> bool:
	for key: String in Admission.IDENTITY_FIELDS:
		if typeof(left.get(key)) != typeof(right.get(key)) or left.get(key) != right.get(key):
			return false
	return true

func _provider_set() -> Dictionary:
	return {"current_binding":Callable(_admission,"physical_life_current"),
		"confirmed_events":Callable(_admission,"physical_event"),
		"source_recovery":Callable(_admission,"source_recovery"),
		"acquire_writers":_writers.acquire_writers,"writers_current":_writers.writers_current,
		"release_writers":_writers.release_writers}

func _ensure_owner(actor: Dictionary) -> Dictionary:
	if actor.get("ok") != true or not actor.get("source_id") is String \
		or not actor.get("token") is Dictionary or not actor.get("body") is CharacterBody3D \
		or not actor.get("model") is Node3D:
		return _reject("actor_not_admitted")
	var source_id: String = actor.source_id
	var existing: Variant = _owners.get(source_id)
	if is_instance_valid(existing):
		if _same_life(_bindings.get(source_id,{}),actor.token):
			if existing.observed_body() != actor.body:
				return _reject("actor_body_changed")
			return {"ok":true,"owner":existing,"reused":true}
		# Never rebind the old owner to a new generation. It can retire only under
		# its own stale-life/physical lease rules; rejection preserves it intact.
		var retired: Dictionary = existing.dispose("source_life_replaced")
		if retired.get("ok") != true:
			return _reject("previous_life_not_retired")
		_owners.erase(source_id)
		_bindings.erase(source_id)
	var standing: Dictionary = _admission.actor_binding(source_id,true)
	if standing.get("ok") != true or not _same_life(standing.get("token",{}),actor.token) \
		or standing.get("body") != actor.body:
		return _reject("current_standing_actor_required")
	var owner := PoseOwner.new()
	var configured: Dictionary = owner.configure(standing.body,standing.model,standing.token,
		_provider_set(),_options)
	if configured.get("ok") != true:
		owner.dispose("configuration_rejected")
		return _reject("pose_configuration:"+str(configured.get("reason",configured.get("error","rejected"))))
	_owners[source_id] = owner
	_bindings[source_id] = standing.token.duplicate()
	return {"ok":true,"owner":owner,"reused":false}

## Optional prewarming of a real actor; QA uses this to capture standing state.
## It never invents an actor or a medical event, and does not allocate for the city.
func admit_actor(source_id: String) -> Dictionary:
	if not _ready_for_call(): return _reject("manager_not_ready")
	_busy = true
	var actor: Dictionary = _admission.actor_binding(source_id,true)
	if actor.get("ok") != true:
		_busy = false
		return _reject("actor_not_admitted")
	var receipt := _ensure_owner(actor)
	_busy = false
	return receipt

func down(event_id: String) -> Dictionary:
	if not _ready_for_call(): return _reject("manager_not_ready")
	_busy = true
	var actor: Dictionary = _admission.resolve_event(event_id)
	if actor.get("ok") != true:
		_busy = false
		return _reject("medical_event_not_admitted")
	var prepared := _ensure_owner(actor)
	if prepared.get("ok") != true:
		_busy = false
		return prepared
	var receipt: Dictionary = prepared.owner.down(event_id)
	_busy = false
	return receipt

func recover(plan: Dictionary) -> Dictionary:
	if not _ready_for_call(): return _reject("manager_not_ready")
	if not plan.get("source_id") is String or not plan.get("body") is CharacterBody3D:
		return _reject("recovery_actor_required")
	_busy = true
	var actor: Dictionary = _admission.actor_binding(plan.source_id,false)
	if actor.get("ok") != true or actor.get("body") != plan.body:
		_busy = false
		return _reject("recovery_actor_stale")
	var owner: Variant = _owners.get(plan.source_id)
	if not is_instance_valid(owner) or not _same_life(_bindings.get(plan.source_id,{}),actor.token):
		_busy = false
		return _reject("downed_owner_missing_or_stale")
	# The per-actor owner validates source release at begin/step/commit and is the
	# sole dispatcher of the exact completion Callable supplied by the life owner.
	var receipt: Dictionary = owner.recover(plan)
	_busy = false
	return receipt

## Call once after actual physics; do not use this to advance squad/core time.
func tick(delta: float) -> Dictionary:
	if not _ready_for_call() or not is_finite(delta) or delta < 0.0 or delta > 0.1:
		return _reject("manager_tick_context")
	_busy = true
	var results: Array = []
	var ok := true
	# Completion may change source life. Iterate a snapshot and leave admission
	# of the next generation to an explicit event/prewarm, never an automatic heal.
	for source_id: Variant in _owners.keys():
		var owner: Variant = _owners.get(source_id)
		if not is_instance_valid(owner):
			ok = false
			results.append({"source_id":source_id,"ok":false,"reason":"owner_missing"})
			continue
		if owner.mode == "RETIRED": continue
		var receipt: Dictionary = owner.tick(delta)
		results.append({"source_id":source_id,"receipt":receipt})
		if receipt.get("ok") != true: ok = false
	_busy = false
	return {"ok":ok,"actors":results,"core_ticks":0}

func actor_owner(source_id: String) -> Variant:
	return _owners.get(source_id) if _configured and not _disposed else null

## Writer callbacks validate the actual life while down/tick holds _busy.
## This read-only authority check must remain available inside those callbacks.
func physical_life_current(binding: Dictionary) -> bool:
	if not _configured or _disposed or not Thread.is_main_thread() \
		or not is_instance_valid(_admission):
		return false
	return _admission.physical_life_current(binding)

func actor_binding(source_id: String) -> Dictionary:
	if not _ready_for_call(): return {}
	_busy = true
	var receipt: Dictionary = _admission.actor_binding(source_id,false)
	_busy = false
	return receipt

func diagnostics() -> Dictionary:
	if _busy:
		return {"configured":_configured,"disposed":_disposed,"busy":true,
			"last_error":_last_error,"actors":{},"authority":"physical_pose_only"}
	_busy = true
	var actors := {}
	for source_id: Variant in _owners:
		var owner: Variant = _owners[source_id]
		actors[source_id] = owner.evidence() if is_instance_valid(owner) else {"mode":"MISSING"}
	_busy = false
	return {"configured":_configured,"disposed":_disposed,"busy":false,
		"last_error":_last_error,"actors":actors,"authority":"physical_pose_only"}

func dispose(reason: String = "disposed") -> Dictionary:
	if _disposed: return {"ok":true}
	if _busy or not Thread.is_main_thread(): return _reject("manager_busy")
	_busy = true
	# Preflight before mutating any owner, so a live downed actor does not leave
	# a half-disposed scene. Source registry retirement precedes scene teardown.
	for source_id: Variant in _owners:
		var owner: Variant = _owners[source_id]
		if is_instance_valid(owner) and owner.mode in ["ACTIVE","RECOVERING","RECOVERY_HOLD"] \
			and _admission.physical_life_current(_bindings.get(source_id,{})):
			_busy = false
			return _reject("active_life_requires_source_retirement")
	for source_id: Variant in _owners:
		var owner: Variant = _owners[source_id]
		if is_instance_valid(owner):
			var receipt: Dictionary = owner.dispose(reason)
			if receipt.get("ok") != true:
				_busy = false
				return _reject("owner_disposal_rejected:"+str(source_id))
	if is_instance_valid(_admission): _admission.dispose()
	_owners.clear()
	_bindings.clear()
	_writers.clear()
	_disposed = true
	_busy = false
	return {"ok":true}
