extends Node3D
## Port of mercenary_selection_view.mjs. Presentation never changes target state.
var _scene:Node3D
var _selected:Node3D
var _selected_kind:String=""
var _downed:bool=false
var _outline:MeshInstance3D
var _npc:MeshInstance3D
var _rally:Node3D
var _outline_material:StandardMaterial3D
var _npc_material:StandardMaterial3D
var _rally_material:StandardMaterial3D
var _bounds_cache:Dictionary={}
var _disposed:bool=false
var _phase:float=0.0
var _age:float=0.0
var _bounds_computed:int=0
var _outline_builds:int=0
var _outline_vertices:int=0
var _build_max_ms:float=0.0

func _finite(value:Variant)->bool:return (value is float or value is int) and is_finite(float(value))

func configure(scene:Node3D)->Dictionary:
	if _disposed or _scene!=null or not is_instance_valid(scene):return {"ok":false,"reason":"selection_lifecycle"}
	_scene=scene
	_outline_material=_material(Color("f03532"),1.0)
	_npc_material=_material(Color("91e7ba"),.95)
	_rally_material=_material(Color("e6c58a"),.82)
	_rally=Node3D.new();_rally.name="Mercenary_Rally_Marker";scene.add_child(_rally);_rally.hide()
	var shaft:Array=[]
	var heights:Array=[.045,.5,1.9,2.8];var widths:Array=[.09,.055,.025,.006];var tones:Array=[.42,1.0,.48,.08]
	for axis:int in 2:
		for i:int in 3:
			var a:Vector3=Vector3(0,heights[i],-widths[i]) if axis==1 else Vector3(-widths[i],heights[i],0)
			var b:Vector3=Vector3(0,heights[i],widths[i]) if axis==1 else Vector3(widths[i],heights[i],0)
			var c:Vector3=Vector3(0,heights[i+1],widths[i+1]) if axis==1 else Vector3(widths[i+1],heights[i+1],0)
			var d:Vector3=Vector3(0,heights[i+1],-widths[i+1]) if axis==1 else Vector3(-widths[i+1],heights[i+1],0)
			shaft.append([[a,tones[i]],[b,tones[i]],[c,tones[i+1]]]);shaft.append([[a,tones[i]],[c,tones[i+1]],[d,tones[i+1]]])
	_make_mesh(shaft,_rally_material,_rally,"Rally_Gold_Beacon")
	var ornament:Array=[]
	for radius:float in [.65,.82]:_arc_triangles(ornament,radius-.012,radius+.012,.16,1.0)
	for i:int in 4:
		var a:float=i*PI/2.0;var p:Vector3=_point(a,.94);var q:Vector3=_point(a+.085,.76);var r:Vector3=_point(a,.64);var s:Vector3=_point(a-.085,.76)
		ornament.append([[p,1.0],[q,1.0],[r,1.0]]);ornament.append([[p,1.0],[r,1.0],[s,1.0]])
	_make_mesh(ornament,_rally_material,_rally,"Rally_Art_Deco_Arcs")
	var npc_triangles:Array=[]
	_arc_triangles(npc_triangles,.49,.545,.17,1.0);_arc_triangles(npc_triangles,.61,.635,.17,.6)
	for i:int in 4:
		var a:float=i*PI/2.0;var tip:Vector3=_point(a,.50);var left:Vector3=_point(a-.12,.81);var middle:Vector3=_point(a,.69);var right:Vector3=_point(a+.12,.81)
		npc_triangles.append([[tip,1.0],[left,1.0],[middle,.8]]);npc_triangles.append([[tip,1.0],[middle,.8],[right,1.0]])
	_npc=_make_mesh(npc_triangles,_npc_material,scene,"Mercenary_Npc_Selection_Ring");_npc.hide()
	return {"ok":true}

func _material(color:Color,alpha:float)->StandardMaterial3D:
	var value:StandardMaterial3D=StandardMaterial3D.new();value.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;value.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;value.depth_draw_mode=BaseMaterial3D.DEPTH_DRAW_DISABLED;value.cull_mode=BaseMaterial3D.CULL_DISABLED;value.vertex_color_use_as_albedo=true;color.a=alpha;value.albedo_color=color;return value

func _point(angle:float,radius:float)->Vector3:return Vector3(cos(angle)*radius,.035,sin(angle)*radius)

func _arc_triangles(out:Array,inner:float,outer:float,gap:float,tone:float)->void:
	for side:int in 4:
		for i:int in 16:
			var a:float=side*PI/2.0+gap+i*(PI/2.0-gap*2)/16;var b:float=side*PI/2.0+gap+(i+1)*(PI/2.0-gap*2)/16
			var p:Vector3=_point(a,inner);var q:Vector3=_point(a,outer);var r:Vector3=_point(b,outer);var s:Vector3=_point(b,inner)
			out.append([[p,tone],[q,tone],[r,tone]]);out.append([[p,tone],[r,tone],[s,tone]])

func _make_mesh(triangles:Array,material:Material,parent:Node3D,title:String)->MeshInstance3D:
	var vertices:PackedVector3Array=PackedVector3Array();var colors:PackedColorArray=PackedColorArray()
	for triangle:Array in triangles:
		for v:Array in triangle:vertices.append(v[0]);colors.append(Color(v[1],v[1],v[1],1))
	var arrays:Array=[];arrays.resize(Mesh.ARRAY_MAX);arrays[Mesh.ARRAY_VERTEX]=vertices;arrays[Mesh.ARRAY_COLOR]=colors
	var mesh:ArrayMesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	var object:MeshInstance3D=MeshInstance3D.new();object.name=title;object.mesh=mesh;object.material_override=material;object.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;object.set_meta("mercenaryPickIgnore",true);parent.add_child(object);return object

func _metadata(object:Node3D)->Dictionary:
	var value:Variant=object.get_meta("mercenaryTarget",{});return value if value is Dictionary else {}

func local_bounds(object:Node3D)->Variant:
	var metadata:Dictionary=_metadata(object);var authored:Variant=metadata.get("highlightBounds");var revision:Variant=metadata.get("boundsRevision",0);var key:int=object.get_instance_id()
	if _bounds_cache.has(key):
		var cached:Dictionary=_bounds_cache[key]
		if cached.object.get_ref()==object and cached.authored==authored and cached.revision==revision:return cached.box
	var box:Variant=null
	if authored is Dictionary:
		var lo:Variant=authored.get("min");var hi:Variant=authored.get("max")
		if lo is Array and hi is Array and lo.size()==3 and hi.size()==3 and lo.all(_finite) and hi.all(_finite):
			var low:Vector3=Vector3(lo[0],lo[1],lo[2]);var high:Vector3=Vector3(hi[0],hi[1],hi[2])
			if low.is_finite() and high.is_finite():box=AABB(low,high-low)
	if box==null:
		var meshes:Array=object.find_children("*","GeometryInstance3D",true,false)
		if object is GeometryInstance3D:meshes.append(object)
		var inverse:Transform3D=object.global_transform.affine_inverse()
		for node:GeometryInstance3D in meshes:
			if not node.is_visible_in_tree():continue
			var ignored:bool=false;var p:Node=node
			while p!=null:
				if p.get_meta("mercenaryPickIgnore",false):ignored=true;break
				if p==object:break
				p=p.get_parent()
			if ignored:continue
			if node is MeshInstance3D and node.mesh!=null:
				var visible_material:bool=false
				for surface:int in node.mesh.get_surface_count():
					var material:Material=node.get_active_material(surface)
					if not material is BaseMaterial3D or material.transparency==BaseMaterial3D.TRANSPARENCY_DISABLED or material.albedo_color.a>.01:visible_material=true;break
				if visible_material:
					var transformed:AABB=(inverse*node.global_transform)*node.get_aabb();box=transformed if box==null else box.merge(transformed)
			elif node is MultiMeshInstance3D and node.multimesh!=null and node.multimesh.mesh!=null:
				var count:int=node.multimesh.instance_count if node.multimesh.visible_instance_count<0 else node.multimesh.visible_instance_count
				for i:int in count:
					var transformed:AABB=(inverse*node.global_transform*node.multimesh.get_instance_transform(i))*node.multimesh.mesh.get_aabb();box=transformed if box==null else box.merge(transformed)
	_bounds_computed+=1;_bounds_cache[key]={"object":weakref(object),"authored":authored.duplicate(true) if authored is Dictionary else authored,"revision":revision,"box":box};return box

func _clear_outline()->void:
	if is_instance_valid(_outline):
		_outline.hide()
		if _outline.get_parent()!=null:_outline.get_parent().remove_child(_outline)
		_outline.queue_free()
	_outline=null;_outline_vertices=0

func _refresh_outline(object:Node3D)->void:
	if is_instance_valid(_outline):return
	var start:int=Time.get_ticks_usec();var value:Variant=local_bounds(object)
	if not value is AABB or not value.position.is_finite() or not value.end.is_finite() or value.size.x<0 or value.size.y<0 or value.size.z<0:return
	var box:AABB=value;var size:Vector3=box.size;var center:Vector3=box.get_center();var rx:float=maxf(.20,size.x*.5+.09);var rz:float=maxf(.22,size.z*.5+.08);var hy:float=maxf(.24,size.y*.5+.04);var width:float=maxf(.020,minf(.040,maxf(size.x,size.y)*.012))
	var vertices:PackedVector3Array=PackedVector3Array();var colors:PackedColorArray=PackedColorArray();var indices:PackedInt32Array=PackedInt32Array()
	for side:int in 4:_ribbon(vertices,colors,indices,28,func(t:float)->Vector3:
		var a:float=side*PI/2.0+.20+t*(PI/2.0-.40);return Vector3(center.x+rx*cos(a),box.position.y+.035,center.z+rz*sin(a)),true,width)
	for side:int in [-1,1]:_ribbon(vertices,colors,indices,40,func(t:float)->Vector3:
		var a:float=-1.20+t*2.40;return Vector3(center.x+side*rx*(1+.12*cos(a)),center.y+hy*sin(a),center.z),false,width)
	var arrays:Array=[];arrays.resize(Mesh.ARRAY_MAX);arrays[Mesh.ARRAY_VERTEX]=vertices;arrays[Mesh.ARRAY_COLOR]=colors;arrays[Mesh.ARRAY_INDEX]=indices
	var mesh:ArrayMesh=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	_outline=MeshInstance3D.new();_outline.name="Mercenary_Object_Focus_Arcs";_outline.mesh=mesh;_outline.material_override=_outline_material;_outline.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;_outline.set_meta("mercenaryPickIgnore",true);_outline.set_meta("focusBounds",{"min":[box.position.x,box.position.y,box.position.z],"max":[box.end.x,box.end.y,box.end.z]});object.add_child(_outline)
	_outline_builds+=1;_outline_vertices=vertices.size();_build_max_ms=maxf(_build_max_ms,(Time.get_ticks_usec()-start)/1000.0)

func _ribbon(vertices:PackedVector3Array,colors:PackedColorArray,indices:PackedInt32Array,segments:int,sample:Callable,ground:bool,width:float)->void:
	var previous:int=-1
	for i:int in segments+1:
		var t:float=float(i)/segments;var point:Vector3=sample.call(t);var delta:Vector3=sample.call(minf(1,t+.001))-sample.call(maxf(0,t-.001));var normal:Vector3=Vector3(-delta.z,0,delta.x).normalized() if ground else Vector3(-delta.y,delta.x,0).normalized();var edge:float=minf(1,minf(t/.10,(1-t)/.10));var fade:float=edge*edge*(3-2*edge);var base:int=vertices.size()
		for band:int in [-1,0,1]:vertices.append(point+normal*width*band);colors.append(Color(1,1,1,fade*.78 if band==0 else 0))
		if previous>=0:
			for j:int in 2:indices.append_array(PackedInt32Array([previous+j,base+j,base+j+1,previous+j,base+j+1,previous+j+1]))
		previous=base

func _update_npc()->void:
	if not is_instance_valid(_npc):return
	if not is_instance_valid(_selected) or _selected_kind!="npc" or not _selected.is_inside_tree() or not _selected.is_visible_in_tree():_npc.hide();return
	_npc.global_position=_selected.global_position;var forward:Vector3=_selected.global_basis*Vector3(0,0,1);_npc.global_rotation=Vector3(0,atan2(forward.x,forward.z),0);_npc.scale=Vector3(1.05,1,1.5) if _downed else Vector3.ONE;_npc.show()

func set_target(target:Variant=null)->bool:
	if _disposed or _scene==null:return false
	var row:Dictionary=target if target is Dictionary else {};var object:Variant=row.get("object");var metadata:Dictionary=_metadata(object) if is_instance_valid(object) and object is Node3D else {};var kind:String=str(row.get("kind",metadata.get("kind","")))
	var rejected:bool=row.get("valid",true)==false or row.get("invalid",false) or row.get("completed",false) or row.get("opened",false) or (is_instance_valid(object) and object.get_meta("mercenaryOpened",false)) or metadata.get("opened",false) or (kind=="fence" and is_instance_valid(object) and object.get_meta("mercenaryCut",false)) or (kind=="power_panel" and metadata.get("powered",true)==false) or str(row.get("state","")) in ["completed","opened","invalid"] or kind=="vehicle"
	if rejected:object=null
	var selected_kind:String="npc" if kind in ["npc","member","player"] else "object"
	_downed=row.get("downed",false) or row.get("dead",false) or (row.get("hp") is float or row.get("hp") is int) and float(row.hp)<=0
	var color:Color=Color("61df89") if row.get("working",false) else Color("d4aa62") if row.get("queued",false) else Color("f03532");_outline_material.albedo_color=color
	var npc_color:Color=Color("61df89") if row.get("working",false) else Color("d4aa62") if row.get("queued",false) else Color("ffce83") if _downed else Color("91e7ba");npc_color.a=_npc_material.albedo_color.a;_npc_material.albedo_color=npc_color
	if object==_selected and selected_kind==_selected_kind:
		if is_instance_valid(_selected) and _selected_kind=="object":_refresh_outline(_selected)
		_update_npc();return is_instance_valid(_selected)
	_clear_outline();_npc.hide();_selected=null;_selected_kind=""
	if not is_instance_valid(object) or not object is Node3D or object==_scene:return false
	_selected=object;_selected_kind=selected_kind;_age=0
	if selected_kind=="object":_refresh_outline(object)
	_update_npc();return true

func set_rally(point:Variant=null)->bool:
	if _disposed or not is_instance_valid(_rally):return false
	if not point is Vector3 or not point.is_finite():_rally.hide();return false
	_rally.global_position=point;_phase=0;var color:Color=_rally_material.albedo_color;color.a=.82;_rally_material.albedo_color=color;_rally.show();return true

func update(delta:float=0)->void:
	if _disposed:return
	var step:float=maxf(0,delta) if is_finite(delta) else 0.0
	if is_instance_valid(_selected):_age+=step;var color:Color=_npc_material.albedo_color;color.a=.88+sin(_age*2.4)*.06;_npc_material.albedo_color=color;_update_npc()
	elif is_instance_valid(_npc):_npc.hide()
	if not is_instance_valid(_rally) or not _rally.visible:return
	_phase=minf(3,_phase+step);var t:float=_phase/3;var smooth:float=t*t*(3-2*t);var color:Color=_rally_material.albedo_color;color.a=.82*(1-smooth);_rally_material.albedo_color=color
	if _phase>=3:_rally.hide()

func stats()->Dictionary:
	return {"disposed":_disposed,"selected":is_instance_valid(_selected),"selectedKind":_selected_kind,"npcRing":not _disposed and is_instance_valid(_npc) and _npc.visible,"rally":not _disposed and is_instance_valid(_rally) and _rally.visible,"boundsComputed":_bounds_computed,"outlineBuilds":_outline_builds,"outlineVertices":_outline_vertices,"outlineLimited":false,"building":false,"buildSliceMaxMs":_build_max_ms,"materialClones":0,"geometries":0 if _disposed else 3+int(is_instance_valid(_outline)),"materials":0 if _disposed else 3}

func dispose()->void:
	if _disposed:return
	_disposed=true;_clear_outline()
	for node:Node3D in [_rally,_npc]:
		if is_instance_valid(node):node.hide();node.queue_free()
	_rally=null;_npc=null;_selected=null;_selected_kind="";_bounds_cache.clear();_outline_material=null;_npc_material=null;_rally_material=null;_scene=null

func _exit_tree()->void:dispose()
