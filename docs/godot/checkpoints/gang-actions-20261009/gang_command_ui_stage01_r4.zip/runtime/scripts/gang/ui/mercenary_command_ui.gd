extends Control
## Original command UI / Walk input consumers. All mutations require the live host.
## Accepted recruitment dialog and nameplate modules remain independent.
signal open_changed(opened:bool)
signal action_result(kind:String,result:Dictionary)
const Menu=preload("res://scripts/gang/ui/mercenary_action_menu.gd")
const PRIORITY=["revive","unlock_safe","cut_fence","disable_power","breach_door","plant_bomb","unlock_door","eliminate","intimidate"]
const QUEUE_LABELS={"unlock_safe":"Сейф","cut_fence":"Сетка","disable_power":"Щиток","plant_bomb":"Подрыв","breach_door":"Дверь","unlock_door":"Замок","revive":"Помощь","intimidate":"Запугивание"}
const PHASES={"awaiting":"Ожидает выполнения","returning":"Возвращается из больницы","completed":"Готово","cancelled":"Приказ отменён","active":"Готов к приказу","approach":"Подходит к цели","moving":"Подходит к цели","working":"Выполняет действие","planting":"Закладывает заряд","healing":"Лечит","reviving":"Поднимает бойца","cutting":"Режет ограждение","picking":"Вскрывает замок","retreat":"Отходит","retreating":"Отходит","countdown":"До взрыва","complete":"Готово","idle":"Готов к приказу","follow":"Следует за вами","following":"Следует за вами","dead":"Погиб","downed":"Нужна помощь"}
var _host:Object
var _providers:Dictionary={}
var _disposed=false
var _opened=false
var _pending=false
var _generation=0
var _clock=0.0
var _panel_elapsed=.1
var _hospital_elapsed=.3
var _aim_elapsed=.12
var _notice_until=0.0
var _selected_member_id=""
var _captured_target:Dictionary={}
var _roster:Dictionary={"members":[],"candidates":[],"weapons":[]}
var _cards:Dictionary={}
var _actions:Dictionary={}
var _hospital_ids:Dictionary={}
var _presentation:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://scripts/gang/ui/data/presentation.json"))
var panel:PanelContainer
var title:Label
var back:Button
var intro:Label
var target_label:Label
var wallet:Label
var orders:VBoxContainer
var people:VBoxContainer
var candidates:VBoxContainer
var candidate_heading:Label
var empty_orders:Label
var empty_people:Label
var empty_candidates:Label
var status:Label
var follow_button:Button
var hospital:PanelContainer
var hospital_notice:Label
var hospital_countdown:Label
var notice:Label
var action_prompt:Label
var reticle:Label
var action_menu:Variant
var _selection:Variant
var _task_markers:Variant
var _timers:Variant
var _previous_focus:WeakRef

var is_open:bool:
	get:return _opened
var selected_member_id:Variant:
	get:return null if _selected_member_id=="" else _selected_member_id

func _ready()->void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	z_index=102
	_build()

func configure(host:Object,providers:Dictionary={})->Dictionary:
	if _disposed or _host!=null or not is_instance_valid(host):return {"ok":false,"reason":"ui_lifecycle"}
	for method:String in ["get_roster","get_actions","get_action","get_queue","command","follow","rally","cancel_command"]:
		if not host.has_method(method):return {"ok":false,"reason":"host_api:"+method}
	for key:String in ["get_target","pick_target","pick_ground","is_transport_interaction"]:
		var callback:Variant=providers.get(key)
		if not callback is Callable or not callback.is_valid():return {"ok":false,"reason":"ui_provider:"+key}
	_host=host;_providers=providers.duplicate()
	_selection=_providers.get("selection")
	_task_markers=_providers.get("task_markers")
	_timers=_providers.get("action_timers")
	var menu_receipt:Dictionary=action_menu.configure({"get_target":_target,"get_actions":_context_actions,"on_choose":dispatch_action,"on_open_change":_menu_changed,"is_blocked":_blocked,"is_transport_interaction":_transport})
	if menu_receipt.get("ok")!=true:_host=null;_providers.clear();return menu_receipt
	refresh(true)
	return {"ok":true}

func _provide(name:String,args:Array=[],fallback:Variant=null)->Variant:
	var callback:Callable=_providers.get(name,Callable())
	return callback.callv(args) if callback.is_valid() else fallback

func _host_read(method:String,args:Array=[],fallback:Variant=null)->Variant:
	if not is_instance_valid(_host) or not _host.has_method(method):return fallback
	return _host.callv(method,args)

func _target(id:String)->Dictionary:
	var value:Variant=_provide("get_target",[id],{})
	return value if value is Dictionary else {}

func _pick()->Dictionary:
	var value:Variant=_provide("pick_target",[],{})
	return value if value is Dictionary else {}

func _transport()->bool:
	return _provide("is_transport_interaction",[],false)==true

func _blocked()->bool:
	return _disposed or _transport() or _provide("is_blocked",[],false)==true

func _label(text:String="",size_px:int=12)->Label:
	var node=Label.new();node.text=text;node.add_theme_font_size_override("font_size",size_px)
	node.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;node.mouse_filter=Control.MOUSE_FILTER_IGNORE
	return node

func _button(text:String,callback:Callable)->Button:
	var node=Button.new();node.text=text;node.pressed.connect(callback);return node

func _style(bg:String,border:String,padding:int)->StyleBoxFlat:
	var box=StyleBoxFlat.new();box.bg_color=Color(bg);box.border_color=Color(border)
	box.set_border_width_all(1);box.set_corner_radius_all(5)
	box.content_margin_left=padding;box.content_margin_right=padding;box.content_margin_top=padding;box.content_margin_bottom=padding
	return box

func _build()->void:
	var ui_theme=Theme.new();ui_theme.set_color("font_color","Label",Color("eee6d7"));ui_theme.set_color("font_color","Button",Color("eee6d7"))
	var font=SystemFont.new();font.font_names=PackedStringArray(["Segoe UI","sans-serif"]);ui_theme.default_font=font
	ui_theme.set_stylebox("normal","Button",_style("302b2b","8d7953",7));ui_theme.set_stylebox("hover","Button",_style("56343d","8d7953",7));theme=ui_theme
	panel=PanelContainer.new();panel.name="CommandSquadPanel";panel.mouse_filter=Control.MOUSE_FILTER_STOP;panel.add_theme_stylebox_override("panel",_style("151b1efc","a68a59",12));add_child(panel)
	var scroll=ScrollContainer.new();scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;panel.add_child(scroll)
	var column=VBoxContainer.new();column.size_flags_horizontal=Control.SIZE_EXPAND_FILL;scroll.add_child(column)
	var heading=HBoxContainer.new();column.add_child(heading);title=_label("Мой отряд",19);title.size_flags_horizontal=Control.SIZE_EXPAND_FILL;heading.add_child(title);heading.add_child(_button("×",close))
	back=_button("Весь отряд",func():_generation+=1;_selected_member_id="";refresh(true));column.add_child(back)
	intro=_label("X на другом объекте — следующее задание в очередь. V — за мной; X на земле — к точке. Эти команды очищают очередь, установленный заряд остаётся.",11);column.add_child(intro)
	target_label=_label();target_label.modulate=Color("e6c88b");column.add_child(target_label)
	orders=VBoxContainer.new();column.add_child(orders);empty_orders=_label();column.add_child(empty_orders)
	wallet=_label();column.add_child(wallet);people=VBoxContainer.new();column.add_child(people)
	empty_people=_label("Наймите специалиста, чтобы отдавать приказы.");column.add_child(empty_people)
	candidate_heading=_label("Нанять специалиста");column.add_child(candidate_heading);candidates=VBoxContainer.new();column.add_child(candidates)
	empty_candidates=_label("Рядом нет доступных наёмников.");column.add_child(empty_candidates)
	status=_label();status.modulate=Color("efce8e");column.add_child(status)
	follow_button=_button("Следовать за мной",request_follow);column.add_child(follow_button);panel.hide()
	hospital=PanelContainer.new();hospital.add_theme_stylebox_override("panel",_style("1d2425ec","9f8959",6));hospital.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(hospital)
	var hospital_column=VBoxContainer.new();hospital.add_child(hospital_column);hospital_notice=_label();hospital_column.add_child(hospital_notice);hospital_countdown=_label();hospital_column.add_child(hospital_countdown);hospital.hide()
	notice=_label();notice.custom_minimum_size.x=230;notice.add_theme_stylebox_override("normal",_style("20312cf5","aa95668c",10));add_child(notice);notice.hide()
	action_prompt=_label("",14);action_prompt.add_theme_stylebox_override("normal",_style("153326eb","89c49b",8));add_child(action_prompt);action_prompt.hide()
	reticle=_label("·",16);add_child(reticle);reticle.hide()
	action_menu=Menu.new();action_menu.name="MercenaryActionMenu";add_child(action_menu)
	resized.connect(_layout);_layout()

func _layout()->void:
	if panel==null:return
	var area:Vector2=get_viewport_rect().size
	panel.size=Vector2(minf(350,maxf(100,area.x-36)),maxf(120,area.y-330));panel.position=Vector2(area.x-panel.size.x-18,minf(280,area.y*.4))
	hospital.size.x=minf(350,maxf(100,area.x-36));hospital.position=Vector2(area.x-hospital.size.x-18,panel.position.y+(panel.size.y if _opened else 0)+6)
	notice.position=Vector2(area.x-246,area.y-300);notice.size.x=230
	action_prompt.position=Vector2((area.x-action_prompt.get_combined_minimum_size().x)*.5,area.y*.59);reticle.position=area*.5-Vector2(2.5,8)

func _read_roster()->void:
	var value:Variant=_host_read("get_roster",[],{})
	_roster=value if value is Dictionary else {"members":value if value is Array else [],"candidates":[],"weapons":[]}

func _member(id:String)->Dictionary:
	for row:Dictionary in _roster.get("members",[]):
		if str(row.get("id",""))==id:return row
	return {}

func _hospitalized(row:Dictionary)->bool:
	return row.get("status")=="hospital" or row.get("phase")=="hospital" or row.get("hospital")==true

func _finite(value:Variant)->bool:
	return (value is float or value is int) and is_finite(float(value))

func _set_text(node:Label,value:String)->void:
	if node.text!=value:node.text=value

func refresh(force:bool=false)->void:
	if _disposed or _host==null:return
	if not force and _panel_elapsed<.1:return
	_panel_elapsed=0
	if not _opened and not force and _hospital_elapsed<.3:return
	_read_roster()
	if force or _hospital_elapsed>=.3:
		_hospital_elapsed=0;_refresh_hospital()
	if not _opened:return
	if _selected_member_id!="" and _member(_selected_member_id).is_empty():_generation+=1;_selected_member_id=""
	var personal:bool=_selected_member_id!=""
	var selected:Dictionary=_member(_selected_member_id)
	_set_text(title,str(selected.get("name","Боец отряда")) if personal else "Мой отряд")
	back.visible=personal;intro.visible=not personal;target_label.visible=not personal;orders.visible=not personal;wallet.visible=not personal;candidate_heading.visible=not personal;candidates.visible=not personal
	var rows:Array=_roster.get("members",[])
	_set_text(wallet,str(rows.size())+("/"+str(_roster.capacity) if _finite(_roster.get("capacity")) else "")+" в отряде"+(" · $"+str(_roster.cash) if _finite(_roster.get("cash")) else ""))
	_render_people([selected] if personal else rows,false)
	_render_people(_roster.get("candidates",[]),true)
	empty_people.visible=rows.is_empty();empty_candidates.visible=not personal and _roster.get("candidates",[]).is_empty()
	follow_button.visible=not personal and rows.any(func(row):return row.get("order")=="rally");follow_button.disabled=_pending
	_set_text(target_label,"Цель: "+str(_captured_target.get("label",_captured_target.get("name","объект"))) if not _captured_target.is_empty() else "Цель не выбрана")
	_refresh_orders()
	_layout()

func _refresh_hospital()->void:
	var ids:Dictionary={};var patients:Array=[];var new_patients:Array[String]=[]
	for row:Dictionary in _roster.get("members",[]):
		if not _hospitalized(row):continue
		var id:String=str(row.get("id",""));ids[id]=true;patients.append(row)
		if not _hospital_ids.has(id):new_patients.append(str(row.get("name","Боец"))+" отправлен в больницу.")
	if not new_patients.is_empty():_set_text(hospital_notice," ".join(new_patients))
	_hospital_ids=ids;hospital.visible=not patients.is_empty()
	var lines:Array[String]=[]
	for row:Dictionary in patients:
		var remaining:Variant=row.get("hospitalRemainingSeconds")
		var label:String="Восстанавливается"
		if _finite(remaining):
			var left:int=maxi(0,int(ceil(float(remaining))))
			label="Ожидает выхода" if left==0 else "%d:%02d до возвращения" % [left/60,left%60]
		lines.append(str(row.get("name","Боец"))+" · "+label)
	_set_text(hospital_countdown,"\n".join(lines))

func _card(id:String,candidate:bool)->Dictionary:
	var key:String=("candidate:" if candidate else "member:")+id
	if _cards.has(key):return _cards[key]
	var node=PanelContainer.new();node.add_theme_stylebox_override("panel",_style("28282bcc","75664e",8))
	(candidates if candidate else people).add_child(node)
	var column=VBoxContainer.new();node.add_child(column)
	var card:Dictionary={"node":node,"name":_label(),"detail":_label(),"description":_label("",11),"skills_label":_label("",11),"phase":_label(),"queued":_label("",11),"reason":_label("",11),"weapon_signature":"","skill_signature":"","item":{}}
	for field:String in ["name","detail","description","skills_label","phase","queued"]:column.add_child(card[field])
	var progress=ProgressBar.new();progress.max_value=1;progress.show_percentage=false;progress.custom_minimum_size.y=8;card.progress=progress;column.add_child(progress)
	var weapon=OptionButton.new();weapon.tooltip_text="Оружие из инвентаря";card.weapon=weapon;column.add_child(weapon);weapon.item_selected.connect(func(_index):refresh(true))
	var skill=OptionButton.new();skill.tooltip_text="Навык для улучшения";card.skill=skill;column.add_child(skill)
	var buttons=HFlowContainer.new();column.add_child(buttons)
	card.primary=_button("",func():_person_action(id,candidate,card));buttons.add_child(card.primary)
	card.equip=_button("Выдать оружие",func():_equip(id,card));buttons.add_child(card.equip);card.equip.visible=not candidate
	card.dismiss=_button("Уволить",func():_invoke("dismiss",[id]));card.dismiss.tooltip_text="Выданное оружие вернётся в инвентарь";buttons.add_child(card.dismiss);card.dismiss.visible=not candidate
	column.add_child(card.reason);_cards[key]=card;return card

func _select_value(selector:OptionButton)->String:
	return str(selector.get_item_metadata(selector.selected)) if selector.selected>=0 else ""

func _populate(selector:OptionButton,rows:Array,none:bool=false)->void:
	var chosen:String=_select_value(selector);selector.clear()
	if none:selector.add_item("Без выдачи оружия");selector.set_item_metadata(0,"")
	var preferred:int=0 if none else -1
	for item:Dictionary in rows:
		var index:int=selector.item_count;var level:Variant=item.get("level")
		selector.add_item(str(item.get("label",item.get("name",item.get("id",""))))+(" · ур. "+str(level) if _finite(level) else "")+(" · максимум" if _finite(level) and float(level)>=5 else ""))
		selector.set_item_metadata(index,str(item.get("id","")));selector.set_item_disabled(index,not none and _finite(level) and float(level)>=5)
		if not selector.is_item_disabled(index) and (preferred<0 or str(item.get("id",""))==chosen):preferred=index
	if preferred>=0:selector.select(preferred)

func _skill_rows(value:Variant)->Array:
	var result:Array=[]
	if value is Array:
		for item:Variant in value:result.append({"id":item,"label":item} if item is String else item)
	elif value is Dictionary:
		for id:Variant in value:result.append({"id":id,"label":str(id),"level":value[id]})
	return result.filter(func(row):return row is Dictionary and row.has("id"))

func _render_people(rows:Array,candidate:bool)->void:
	var seen:Dictionary={}
	var weapons:Array=[]
	for weapon:Dictionary in _roster.get("weapons",[]):
		if weapon.has("id") and (not _finite(weapon.get("count")) or float(weapon.count)>0):weapons.append(weapon)
	for row:Dictionary in rows:
		if not row.has("id"):continue
		var id:String=str(row.id);var key:String=("candidate:" if candidate else "member:")+id
		if seen.has(key):continue
		seen[key]=true;var card:Dictionary=_card(id,candidate);card.item=row
		var role:String=str(row.get("profession",row.get("role","")))
		var aliases:Dictionary={"doctor":"medic","enforcer":"bruiser","thug":"bruiser","locksmith":"safecracker","cutter":"electrician","engineer":"electrician","demolition":"demolitions","demolitionist":"demolitions","bomber":"demolitions"}
		var profession:Dictionary=_presentation.professions.get(aliases.get(role,role),{"label":role if role!="" else "Боец","description":""})
		_set_text(card.name,str(row.get("name",profession.label)))
		var detail:String=str(profession.label)+" · Ур. "+str(row.get("level",1))
		if _finite(row.get("hp")):detail+=" · HP "+str(maxi(0,int(round(float(row.hp)))))+("/"+str(int(round(float(row.maxHp)))) if _finite(row.get("maxHp")) else "")
		var weapon_label:String=str(row.get("weaponLabel",row.get("weaponId","")))
		if not candidate and weapon_label!="":detail+=" · "+("Пистолет" if weapon_label=="pistol" else weapon_label)
		_set_text(card.detail,detail);_set_text(card.description,str(profession.description))
		var skills:Array=_skill_rows(row.get("skills",[]));var skill_labels:Array[String]=[]
		for skill:Dictionary in skills:skill_labels.append(str(skill.get("label",skill.get("name",skill.id)))+(" "+str(skill.level) if _finite(skill.get("level")) else ""))
		_set_text(card.skills_label," · ".join(skill_labels));card.skills_label.visible=not skill_labels.is_empty()
		var hospitalized:bool=_hospitalized(row)
		var phase:String="В больнице"+(" · "+str(int(ceil(float(row.hospitalRemainingSeconds))))+" с до возвращения" if _finite(row.get("hospitalRemainingSeconds")) else "") if hospitalized else str(row.get("phaseLabel",PHASES.get(row.get("phase"),row.get("phase",""))))
		_set_text(card.phase,phase);card.phase.visible=phase!=""
		var queued:Array=row.get("queued",[]);var queue_labels:Array[String]=[]
		for index:int in queued.size():queue_labels.append(str(index+1)+". "+str(QUEUE_LABELS.get(queued[index].get("kind"),queued[index].get("kind",""))))
		_set_text(card.queued,"В очереди: "+str(queued.size())+" · "+" → ".join(queue_labels) if not queued.is_empty() else "");card.queued.visible=not queued.is_empty()
		card.progress.visible=_finite(row.get("progress"))
		if card.progress.visible:card.progress.value=clampf(float(row.progress),0,1)
		var weapon_signature:String=JSON.stringify(weapons)
		if card.weapon_signature!=weapon_signature:_populate(card.weapon,weapons,true);card.weapon_signature=weapon_signature
		card.weapon.visible=not weapons.is_empty();card.weapon.disabled=_pending or hospitalized
		card.equip.visible=not candidate and _host.has_method("equip") and not weapons.is_empty();card.equip.disabled=_pending or hospitalized or _select_value(card.weapon)==""
		var skill_signature:String=JSON.stringify(skills)
		if card.skill_signature!=skill_signature:_populate(card.skill,skills);card.skill_signature=skill_signature
		card.skill.visible=not candidate and _host.has_method("upgrade") and not skills.is_empty();card.skill.disabled=_pending or hospitalized or row.get("canUpgrade")==false
		var cost:Variant=row.get("hireCost" if candidate else "upgradeCost")
		card.primary.text=("Нанять" if candidate else "Улучшить")+(" · $"+str(cost) if _finite(cost) else "")
		# Production Walk does not wire command-panel recruitment; R4 conversation owns it.
		card.primary.visible=not candidate and _host.has_method("upgrade")
		card.primary.disabled=_pending or hospitalized or str(row.get("disabledReason",""))!="" or row.get("canUpgrade")==false
		card.dismiss.visible=not candidate and _host.has_method("dismiss");card.dismiss.disabled=_pending or row.get("canDismiss")==false
		_set_text(card.reason,("%.1f м · " % float(row.distanceMeters) if _finite(row.get("distanceMeters")) else "")+"Подойдите и нажмите E"+(" · "+str(row.disabledReason) if str(row.get("disabledReason",""))!="" else "") if candidate else str(row.get("disabledReason","")))
		card.reason.visible=card.reason.text!=""
	for key:String in _cards.keys():
		if key.begins_with("candidate:" if candidate else "member:") and not seen.has(key):_cards[key].node.queue_free();_cards.erase(key)

func _person_action(id:String,candidate:bool,card:Dictionary)->void:
	if candidate or _pending or card.primary.disabled:return
	_read_roster();var row:Dictionary=_member(id)
	if row.is_empty() or row.get("canUpgrade")==false or str(row.get("disabledReason",""))!="" or _hospitalized(row):refresh(true);return
	var skill:String=_select_value(card.skill)
	_invoke("upgrade",[id,skill])

func _equip(id:String,card:Dictionary)->void:
	if card.equip.disabled:return
	var weapon:String=_select_value(card.weapon)
	if weapon!="":_invoke("equip",[id,weapon])

func _eligible(target:Dictionary)->bool:
	# Walk S12 has a specific aim predicate. An intimidated NPC remains eligible;
	# generic completed flags/action phases do not suppress every profession prompt.
	return not target.is_empty() and target.get("valid")==true and not _completed_aim(target)

func _completed_aim(target:Dictionary)->bool:
	return target.get("opened",false) or target.get("cut",false) or (target.get("kind")=="safe" and not target.get("locked",false)) or (target.get("kind")=="power_panel" and (target.get("disabled",false) or not target.get("powered",false)))

func _context_actions(target:Dictionary)->Array:
	# Source contextActions validates actual aim and authority, not a generic phase.
	if _blocked() or target.is_empty() or target.get("valid")!=true:return []
	var value:Variant=_host_read("get_actions",[target],[])
	var actions:Array=[];var seen:Dictionary={}
	var source_index:int=0
	for row:Dictionary in value if value is Array else []:
		var id:String=str(row.get("id",row.get("kind","")))
		if id=="" or seen.has(id) or row.get("enabled")==false or row.get("available")==false or str(row.get("disabledReason",""))!="":continue
		seen[id]=true;var projected:Dictionary=row.duplicate();projected._source_index=source_index;source_index+=1;actions.append(projected)
	actions.sort_custom(func(a,b):
		var ai:int=PRIORITY.find(a.get("id",a.get("kind")));var bi:int=PRIORITY.find(b.get("id",b.get("kind")))
		ai=99 if ai<0 else ai;bi=99 if bi<0 else bi
		if ai!=bi:return ai<bi
		if a.get("willQueue",false)!=b.get("willQueue",false):return not a.get("willQueue",false)
		if int(a.get("queuedCount",0))!=int(b.get("queuedCount",0)):return int(a.get("queuedCount",0))<int(b.get("queuedCount",0))
		return a._source_index<b._source_index)
	return actions

func _refresh_orders()->void:
	var seen:Dictionary={}
	var target:Dictionary=_target(str(_captured_target.get("id",""))) if not _captured_target.is_empty() else {}
	for row:Dictionary in _host_read("get_actions",[target],[]) if not target.is_empty() else []:
		var id:String=str(row.get("id",row.get("kind","")))
		if id=="" or seen.has(id):continue
		seen[id]=true
		if not _actions.has(id):
			var button:Button=_button("",func():_panel_order(id));orders.add_child(button);_actions[id]=button
		var reason:String=str(row.get("disabledReason",""))
		_actions[id].text=("В очередь · " if row.get("willQueue",false) else "")+str(row.get("label",id))+(" — "+reason if reason!="" else "")
		_actions[id].disabled=_pending or row.get("enabled")==false or reason!=""
		_actions[id].tooltip_text=str(row.get("description",reason))
	for id:String in _actions.keys():
		if not seen.has(id):_actions[id].queue_free();_actions.erase(id)
	_set_text(empty_orders,"Для этой цели нет доступных приказов." if not _captured_target.is_empty() else "Посмотрите на машину, замок, ограждение или союзника.")
	empty_orders.visible=_selected_member_id=="" and seen.is_empty()

func _panel_order(kind:String)->void:
	if _pending or _blocked():return
	var target:Dictionary=_target(str(_captured_target.get("id","")))
	if not _context_actions(target).any(func(row):return str(row.get("id",row.get("kind","")))==kind):_set_text(status,"Цель или специалист больше недоступны.");refresh(true);return
	_set_text(status,"Выполняю приказ…")
	var generation:int=_generation
	var receipt:Dictionary=await dispatch_action(kind,target)
	if not _disposed and generation==_generation and _opened:_set_text(status,str(receipt.get("message",receipt.get("reason","Приказ не принят."))))

func _receipt(value:Variant)->Dictionary:
	if value is Dictionary:
		var result:Dictionary=value.duplicate();result["ok"]=value.get("ok") is bool and value.ok
		if not result.ok and not result.has("reason") and not result.has("message"):result.reason="Действие не подтверждено миром."
		return result
	return {"ok":false,"reason":"Действие не подтверждено миром."}

func _invoke(kind:String,args:Array=[])->Dictionary:
	if _pending or _blocked() or not is_instance_valid(_host) or not _host.has_method(kind):return {"ok":false,"reason":"Сейчас этот приказ недоступен."}
	_pending=true;var generation:int=_generation;refresh(true)
	var value:Variant=await _host.callv(kind,args)
	# A synchronous native receipt must keep the duplicate guard through this frame.
	if not _disposed and is_inside_tree():await get_tree().process_frame
	var receipt:Dictionary=_receipt(value);_pending=false
	if not _disposed and generation==_generation:
		var fallback:String="Приказ принят." if receipt.ok else "Приказ не принят."
		if kind=="follow":fallback="Отряд следует за вами." if receipt.ok else "Не удалось вернуть сопровождение."
		if kind=="cancel_command":fallback="Приказ отменён." if receipt.ok else "Не удалось отменить приказ."
		if receipt.ok and kind=="command" and receipt.get("queued",false):
			var has_active:bool=_host_read("get_action",[str(receipt.get("memberId",""))])!=null
			fallback="Добавлено задание №"+str(int(receipt.get("queuePosition",1))+(1 if has_active else 0))
		if not receipt.has("message") and receipt.ok:receipt.message=fallback
		show_notice(str(receipt.get("message",receipt.get("reason",fallback))))
		if receipt.ok and kind in ["follow","command"] and is_instance_valid(_selection):_selection.set_rally(null)
		action_result.emit(kind,receipt);refresh(true)
	return receipt

func dispatch_action(kind:String,target:Dictionary)->Dictionary:
	# Resolve again using captured source ID; a deleted/moved target is not the stale aim.
	var fresh:Dictionary=_target(str(target.get("id","")))
	if not _context_actions(fresh).any(func(row):return str(row.get("id",row.get("kind","")))==kind):return {"ok":false,"reason":"Цель или специалист больше недоступны."}
	return await _invoke("command",[kind,fresh])

func command_at_aim()->Dictionary:
	if _blocked() or _pending:return {"ok":false,"reason":"Сейчас этот приказ недоступен."}
	var target:Dictionary=_pick()
	if not target.is_empty():
		var actions:Array=_context_actions(target)
		if actions.is_empty():show_notice("Нет свободного специалиста для этого объекта.");return {"ok":false,"reason":"Нет свободного специалиста для этого объекта."}
		if actions.size()>1:
			var opened:bool=action_menu.open(target)
			return {"ok":false,"selectionRequired":opened}
		return await dispatch_action(str(actions[0].get("id",actions[0].get("kind",""))),target)
	var point:Variant=_provide("pick_ground")
	if not point is Vector3 or not point.is_finite():show_notice("Посмотри на свободную землю для точки сбора");return {"ok":false,"reason":"Точка сбора недоступна."}
	var generation:int=_generation
	var receipt:Dictionary=await _invoke("rally",[{"x":point.x,"y":point.y,"z":point.z}])
	if not _disposed and generation==_generation and receipt.ok:
		if is_instance_valid(_selection):_selection.set_rally(point)
		show_notice("Точка сбора назначена · "+str(receipt.get("count",0))+" бойцов")
	return receipt

func request_follow()->Dictionary:
	return await _invoke("follow")

func cancel_active(command:Dictionary)->Dictionary:
	if command.get("armed")==true or command.get("cancelable")==false:
		var reason:String="Заряд уже установлен — отменить нельзя." if command.get("armed")==true else "Этот приказ уже нельзя отменить."
		show_notice(reason);return {"ok":false,"reason":reason}
	var generation:int=_generation
	var receipt:Dictionary=await _invoke("cancel_command",[str(command.get("memberId",""))])
	if receipt.ok and not _disposed and generation==_generation:close()
	return receipt

func show_notice(message:String)->void:
	if _disposed:return
	_set_text(notice,message);notice.visible=message!="";_notice_until=_clock+2.5

func open()->bool:
	if _selected_member_id!="":_generation+=1
	_selected_member_id=""
	return _set_open(true)

func open_member(id:String)->bool:
	if _blocked():return false
	_read_roster()
	if _member(id).is_empty():return false
	if not _set_open(true):return false
	if _selected_member_id!=id:_generation+=1
	_selected_member_id=id;refresh(true);return true

func close()->void:
	_set_open(false)

func _set_open(value:bool)->bool:
	if _disposed or (value and _blocked()):return false
	if value==_opened:return true
	_opened=value;_generation+=1
	if value:
		action_menu.close();_captured_target=_pick()
		var focus:Control=get_viewport().gui_get_focus_owner();_previous_focus=weakref(focus) if focus!=null else null
	else:
		_selected_member_id="";_captured_target={};_hide_selectors()
		var focus:Control=_previous_focus.get_ref() if _previous_focus!=null else null
		if is_instance_valid(focus) and focus.is_visible_in_tree() and not _transport():focus.grab_focus()
		_previous_focus=null
	panel.visible=value;_set_text(status,"");open_changed.emit(value);_provide("on_open_change",[value]);refresh(true);return true

func _menu_changed(value:bool)->void:
	_provide("on_open_change",[value])

func _hide_selectors()->void:
	for card:Dictionary in _cards.values():
		card.weapon.get_popup().hide();card.skill.get_popup().hide()

func interrupt()->void:
	_previous_focus=null;close();action_menu.interrupt_for_transport();_hide_selectors();_generation+=1
	reticle.hide();action_prompt.hide()
	if is_instance_valid(_selection):_selection.set_target(null);_selection.set_rally(null)
	if is_instance_valid(_task_markers):_task_markers.clear()
	var focus:Control=get_viewport().gui_get_focus_owner()
	if focus!=null and (focus==self or is_ancestor_of(focus)):focus.release_focus()

func _input(event:InputEvent)->void:
	# E down/echo/up always reaches the existing interaction owner.
	if not _disposed and event is InputEventKey and (event.physical_keycode==KEY_E or event.keycode==KEY_E) and _transport():interrupt()

func _text_focus()->bool:
	var focus:Control=get_viewport().gui_get_focus_owner()
	return focus is LineEdit or focus is TextEdit or focus is OptionButton or focus is PopupMenu

func _unhandled_key_input(event:InputEvent)->void:
	if _disposed or not event is InputEventKey or not event.pressed or event.echo or event.ctrl_pressed or event.meta_pressed or event.alt_pressed or _text_focus():return
	if action_menu.is_open():return
	var key:int=event.physical_keycode if event.physical_keycode!=0 else event.keycode
	if key==KEY_ESCAPE and _opened:close();get_viewport().set_input_as_handled()
	elif key==KEY_V and not _blocked():close();request_follow();get_viewport().set_input_as_handled()
	elif key==KEY_X and not _opened and not _blocked():command_at_aim();get_viewport().set_input_as_handled()

func _task_rows(aimed:Dictionary)->Array:
	var rows:Array=[]
	var roster:Variant=_host_read("get_roster",[],{})
	var members:Array=roster.get("members",[]) if roster is Dictionary else roster if roster is Array else []
	for member:Dictionary in members.slice(0,5):
		var id:String=str(member.get("id",""));var action:Variant=_host_read("get_action",[id])
		var active:bool=action is Dictionary and not action.is_empty() and not action.get("phase") in ["completed","cancelled"]
		if active:var row:Dictionary=action.duplicate();row.memberName=member.get("name","Специалист");row.number=1;row.queued=false;rows.append(row)
		var queue:Variant=_host_read("get_queue",[id],member.get("queued",[]))
		if queue is Array:
			for index:int in mini(8,queue.size()):
				var row:Dictionary=queue[index].duplicate();row.memberName=member.get("name","Специалист");row.number=index+(2 if active else 1);row.queued=true;rows.append(row)
	for charge:Dictionary in _host_read("get_charges",[],[]):
		if not rows.any(func(row):return row.get("targetId")==charge.get("targetId") and not row.get("queued",false)):
			var row:Dictionary=charge.duplicate();row.number=1;row.queued=false;rows.append(row)
	for index:int in rows.size():rows[index]._source_index=index
	rows.sort_custom(func(a,b):
		if a.get("queued",false)!=b.get("queued",false):return not a.get("queued",false)
		if int(a.get("number",1))!=int(b.get("number",1)):return int(a.get("number",1))<int(b.get("number",1))
		return a._source_index<b._source_index)
	var aim_index:int=-1
	for index:int in rows.size():
		if str(rows[index].get("targetId",""))==str(aimed.get("id","")):aim_index=index;break
	if aim_index>=10:var row:Dictionary=rows.pop_at(aim_index);rows.insert(9,row)
	var result:Array=[];var seen:Dictionary={}
	for row:Dictionary in rows:
		var id:String=str(row.get("targetId",""))
		if seen.has(id):continue
		seen[id]=true;var target:Dictionary=_target(id)
		if not is_instance_valid(target.get("object")) or target.get("valid")==false:continue
		var projected:Dictionary=row.duplicate();projected.target=target;result.append(projected)
		if result.size()>=10:break
	return result

func update_aim_selection()->void:
	if _disposed:return
	if _transport():interrupt();return
	var can_pick:bool=not _blocked() and not _opened and not action_menu.is_open()
	var aimed:Dictionary=_target(str(action_menu.target_id())) if action_menu.is_open() else _pick() if can_pick else {}
	var marked:Dictionary={}
	if is_instance_valid(_task_markers):marked=_task_markers.sync(_task_rows(aimed),aimed if _eligible(aimed) else null)
	if is_instance_valid(_selection):
		var selected:Dictionary=aimed.duplicate();var working:bool=false
		for member:Dictionary in _roster.get("members",[]):
			var action:Variant=_host_read("get_action",[str(member.get("id",""))])
			if action is Dictionary and str(action.get("targetId",""))==str(aimed.get("id","")) and (action.get("armed",false) or action.get("phase") in ["working","awaiting","retreat","countdown"]):working=true;break
		selected.working=working
		_selection.set_target(selected if _eligible(aimed) and not marked.has(str(aimed.get("id",""))) else null)
	reticle.visible=can_pick
	var actions:Array=[] if _completed_aim(aimed) else _context_actions(aimed)
	action_prompt.visible=can_pick and not _pending and not actions.is_empty()
	if action_prompt.visible:
		_set_text(action_prompt,"X — Выбрать действие" if actions.size()>1 else "X — "+("В очередь · " if actions[0].get("willQueue",false) else "")+str(actions[0].get("label",actions[0].get("id",""))))
	_layout()

func _process(delta:float)->void:
	if _disposed:return
	_clock+=maxf(0,delta);_panel_elapsed+=maxf(0,delta);_hospital_elapsed+=maxf(0,delta);_aim_elapsed+=maxf(0,delta)
	if _transport():
		if _opened or action_menu.is_open():interrupt()
	refresh();action_menu.update(delta)
	if _aim_elapsed>=.12:_aim_elapsed=0;update_aim_selection()
	if notice.visible and _clock>=_notice_until:notice.hide();_set_text(notice,"")
	if is_instance_valid(_selection):_selection.update(delta)
	if is_instance_valid(_task_markers):_task_markers.update(delta)
	if is_instance_valid(_timers):_timers.update_presentation(delta)

func hud_rects()->Array[Rect2]:
	var result:Array[Rect2]=[]
	for control:Control in [panel,hospital,notice,action_prompt]:
		if control.visible:result.append(control.get_global_rect())
	result.append_array(action_menu.hud_rects())
	# Timers are real HUD rectangles; transparent task marker overlay is not a mask.
	if is_instance_valid(_timers):result.append_array(_timers.hud_rects())
	return result

func blocks_world_input(point:Variant=null)->bool:
	if _disposed or _transport():return false
	if point is Vector2:
		for rect:Rect2 in hud_rects():
			if rect.has_point(point):return true
		return false
	return _opened or action_menu.is_open()

func dispose()->void:
	if _disposed:return
	interrupt();_disposed=true;_generation+=1;_host=null;_providers.clear();_cards.clear();_actions.clear()
	action_menu.dispose();set_process(false);set_process_input(false);set_process_unhandled_key_input(false);hide()
	# Presentation owners may be shared by BUILD; caller disposes injected modules.

func _exit_tree()->void:
	dispose()
