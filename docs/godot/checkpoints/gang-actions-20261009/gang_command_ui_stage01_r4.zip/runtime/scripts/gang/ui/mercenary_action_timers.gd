extends Control
## mercenary_action_timers.mjs: reads genuine receipts, never advances gameplay.
const LABELS:Dictionary={"unlock_safe":"Вскрытие","unlock_door":"Взлом замка","breach_door":"Выбивание двери","cut_fence":"Резка","disable_power":"Отключение питания","revive":"Лечение","plant_bomb":"Закладка","intimidate":"Запугивание"}
var camera:Camera3D
var options:Dictionary={}
var max_distance:float=100.0
var _slots:Array=[]
var _active:Dictionary={}
var _bounds:Dictionary={}
var _disposed:bool=false
var _elapsed:float=.1
var _polls:int=0
var _bounds_computed:int=0
var _visible:int=0

static func _finite(value:Variant)->bool:return (value is float or value is int) and is_finite(float(value))

static func timer_text(action:Dictionary,time:float)->Variant:
	if action.get("awaiting",false) or action.get("phase","")=="awaiting":return "Подтверждение действия"
	var detonate:Variant=action.get("detonateAt")
	if action.get("armed",false) or _finite(detonate):
		if action.get("waitingForSafety",false) or (action.get("phase","")=="retreat" and _finite(detonate) and float(detonate)<=time):return "Отходит на безопасное расстояние"
		if not _finite(detonate) or float(detonate)<=time:return "Подтверждение действия"
		return "До взрыва · "+str(int(ceil(float(detonate)-time)))+" с"
	var label:Variant=LABELS.get(str(action.get("kind","")))
	if label==null:return null
	if action.get("phase","")=="approach":return label+" · Подходит к цели"
	if action.get("phase","")!="working":return null
	var duration:Variant=action.get("duration");var progress:Variant=action.get("progress")
	if not _finite(duration) or float(duration)<=0 or not _finite(progress):return label
	var remaining:float=float(duration)*(1-clampf(float(progress),0,1))
	if remaining<=0:return "Подтверждение действия"
	return label+" · "+("%.1f"%(ceil(remaining*10)/10)).replace(".",",")+" с"

func configure(view:Camera3D,providers:Dictionary,distance:float=100.0)->Dictionary:
	if _disposed or camera!=null or not is_instance_valid(view):return {"ok":false,"reason":"timer_lifecycle"}
	for key:String in ["get_host","get_target","now_seconds"]:
		if not providers.get(key,Callable()).is_valid():return {"ok":false,"reason":"provider:"+key}
	camera=view;options=providers.duplicate();max_distance=distance;mouse_filter=Control.MOUSE_FILTER_IGNORE;set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);z_index=98;return {"ok":true}

func _call(name:String,args:Array=[],fallback:Variant=null)->Variant:
	var cb:Callable=options.get(name,Callable());return cb.callv(args) if cb.is_valid() else fallback

func _host_call(host:Variant,method:String,args:Array=[],fallback:Variant=null)->Variant:
	return host.callv(method,args) if is_instance_valid(host) and host.has_method(method) else fallback

func _hide(slot:Dictionary)->void:slot.node.hide()

func _acquire()->Dictionary:
	for slot:Dictionary in _slots:
		if slot.key==null:return slot
	if _slots.size()>=10:return {}
	var label:Label=Label.new();label.mouse_filter=Control.MOUSE_FILTER_IGNORE;label.add_theme_font_size_override("font_size",12);label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var font:SystemFont=SystemFont.new();font.font_names=PackedStringArray(["Segoe UI","sans-serif"]);font.font_weight=600;label.add_theme_font_override("font",font);label.add_theme_color_override("font_color",Color("f2db9e"));label.add_theme_color_override("font_shadow_color",Color.BLACK);label.add_theme_constant_override("shadow_offset_y",1)
	var style:StyleBoxFlat=StyleBoxFlat.new();style.bg_color=Color("201c1dec");style.border_color=Color("a88c58");style.set_border_width_all(1);style.set_corner_radius_all(5);style.content_margin_left=10;style.content_margin_right=10;style.content_margin_top=5;style.content_margin_bottom=5;label.add_theme_stylebox_override("normal",style);add_child(label);label.hide()
	var slot:Dictionary={"node":label,"key":null,"target":null,"anchor":null};_slots.append(slot);return slot

func _local_anchor(object:Node3D)->Vector3:
	var key:int=object.get_instance_id()
	if _bounds.has(key) and _bounds[key].object.get_ref()==object:return _bounds[key].anchor
	var metadata:Variant=object.get_meta("mercenaryTarget",{});var authored:Variant=metadata.get("highlightBounds") if metadata is Dictionary else null;var box:Variant=null
	if authored is Dictionary:
		var lo:Variant=authored.get("min");var hi:Variant=authored.get("max")
		if lo is Array and hi is Array and lo.size()==3 and hi.size()==3:
			var low:Vector3=Vector3(lo[0],lo[1],lo[2]);var high:Vector3=Vector3(hi[0],hi[1],hi[2])
			if low.is_finite() and high.is_finite():box=AABB(low,high-low)
	if box==null:
		var inverse:Transform3D=object.global_transform.affine_inverse();var meshes:Array=object.find_children("*","GeometryInstance3D",true,false)
		if object is GeometryInstance3D:meshes.append(object)
		for node:GeometryInstance3D in meshes:
			if not node.is_visible_in_tree():continue
			var ignored:bool=false;var parent:Node=node
			while parent!=null:
				if parent.get_meta("mercenaryPickIgnore",false):ignored=true;break
				if parent==object:break
				parent=parent.get_parent()
			if ignored:continue
			if node is MeshInstance3D and node.mesh!=null:
				var transformed:AABB=(inverse*node.global_transform)*node.get_aabb();box=transformed if box==null else box.merge(transformed)
			elif node is MultiMeshInstance3D and node.multimesh!=null and node.multimesh.mesh!=null:
				var count:int=node.multimesh.instance_count if node.multimesh.visible_instance_count<0 else node.multimesh.visible_instance_count
				for i:int in count:
					var transformed:AABB=(inverse*node.global_transform*node.multimesh.get_instance_transform(i))*node.multimesh.mesh.get_aabb();box=transformed if box==null else box.merge(transformed)
	var anchor:Vector3=Vector3(0,1.9,0)
	if box is AABB:anchor=box.get_center();anchor.y=box.end.y+.25
	_bounds_computed+=1;_bounds[key]={"object":weakref(object),"anchor":anchor};return anchor

func _add(action:Variant,member_id:Variant,time:float,rows:Array,seen:Dictionary,counts:Dictionary)->void:
	if not action is Dictionary or action.get("targetId")==null or action.get("targetId")==false or action.get("targetId")==0 or str(action.get("targetId"))=="":return
	var charge:bool=action.get("armed",false) or _finite(action.get("detonateAt")) or (action.get("kind","")=="plant_bomb" and (action.get("awaiting",false) or action.get("phase","")=="awaiting"))
	if int(counts.charges if charge else counts.works)>=5:return
	var identity:Variant=action.get("id")
	if identity==null:identity=action.get("actionId")
	if identity==null:identity=action.get("requestId")
	if identity==null:identity="member:"+str(member_id)
	var key:String=str(identity)
	if seen.has(key):return
	var text:Variant=timer_text(action,time)
	if text==null:return
	seen[key]=true;rows.append({"key":key,"text":text,"targetId":action.targetId})
	if charge:counts.charges+=1
	else:counts.works+=1

func _poll()->void:
	_polls+=1;var host:Variant=_call("get_host");var rows:Array=[];var seen:Dictionary={};var counts:Dictionary={"charges":0,"works":0};var time:Variant=_call("now_seconds")
	if _finite(time):
		for raw:Variant in _host_call(host,"get_charges",[],[]):
			if raw is Dictionary:var action:Dictionary=raw.duplicate();action.armed=true;_add(action,action.get("memberId"),float(time),rows,seen,counts)
		for raw:Variant in _host_call(host,"get_pending_transactions",[],[]):
			if raw is Dictionary:var action:Dictionary=raw.duplicate();action.awaiting=true;action.phase="awaiting";_add(action,action.get("memberId"),float(time),rows,seen,counts)
		var roster:Variant=_host_call(host,"get_roster",[],{});var members:Variant=roster if roster is Array else roster.get("members",[]) if roster is Dictionary else []
		for member:Dictionary in members.slice(0,5):_add(_host_call(host,"get_action",[member.id]),member.id,float(time),rows,seen,counts)
	for key:String in _active.keys():
		if not seen.has(key):var slot:Dictionary=_active[key];_active.erase(key);slot.key=null;slot.target=null;slot.anchor=null;_hide(slot)
	for row:Dictionary in rows:
		var slot:Dictionary=_active.get(row.key,{})
		if slot.is_empty():
			slot=_acquire()
			if slot.is_empty():continue
			slot.key=row.key;_active[row.key]=slot
		if slot.node.text!=row.text:slot.node.text=row.text
		slot.target=_call("get_target",[row.targetId]);var object:Variant=slot.target.get("object") if slot.target is Dictionary else null;slot.anchor=_local_anchor(object) if is_instance_valid(object) and object is Node3D else null

func _position(value:Variant)->Variant:
	if value is Vector3 and value.is_finite():return value
	if value is Dictionary and _finite(value.get("x")) and _finite(value.get("z")):return Vector3(value.x,float(value.get("y",0)),value.z)
	return null

func update_presentation(delta:float=0)->void:
	if _disposed or not is_instance_valid(camera):return
	_elapsed+=maxf(0,delta) if is_finite(delta) else 0.0
	if _elapsed>=.1:_elapsed=0;_poll()
	_visible=0;var viewport_size:Vector2=get_viewport_rect().size;var focus:Variant=_position(_call("get_focus"))
	for slot:Dictionary in _active.values():
		var target:Variant=slot.target
		if not target is Dictionary or target.get("valid",true)==false or viewport_size.x<=0 or viewport_size.y<=0:_hide(slot);continue
		var object:Variant=target.get("object");var point:Variant=null
		if is_instance_valid(object) and object is Node3D:
			if not object.is_inside_tree() or not object.is_visible_in_tree():_hide(slot);continue
			point=object.global_transform*slot.anchor
		else:
			point=_position(target.get("position"))
			if point is Vector3:point.y+=1.9 if target.get("kind","") in ["npc","player"] else .8
		if not point is Vector3:_hide(slot);continue
		if focus is Vector3 and Vector2(point.x-focus.x,point.z-focus.z).length()>max_distance:_hide(slot);continue
		var depth:float=-camera.to_local(point).z
		if depth<camera.near or depth>camera.far:_hide(slot);continue
		var pixel:Vector2=camera.unproject_position(point);var padding:float=maxf(70,slot.node.text.length()*3.6)
		if not pixel.is_finite() or pixel.x<padding or pixel.x>viewport_size.x-padding or pixel.y<26 or pixel.y>viewport_size.y:_hide(slot);continue
		slot.node.size=slot.node.get_combined_minimum_size();slot.node.position=pixel-Vector2(slot.node.size.x*.5,slot.node.size.y);slot.node.show();_visible+=1

func hud_rects()->Array:
	var rects:Array=[]
	for slot:Dictionary in _active.values():
		if slot.node.visible:rects.append(slot.node.get_global_rect())
	return rects

func stats()->Dictionary:return {"active":_active.size(),"pooled":_slots.size(),"visible":_visible,"polls":_polls,"boundsComputed":_bounds_computed,"disposed":_disposed}

func dispose()->void:
	if _disposed:return
	_disposed=true
	for slot:Dictionary in _slots:
		if is_instance_valid(slot.node):slot.node.hide();slot.node.queue_free()
	_active.clear();_slots.clear();_bounds.clear();options.clear();camera=null;hide()

func _exit_tree()->void:dispose()
