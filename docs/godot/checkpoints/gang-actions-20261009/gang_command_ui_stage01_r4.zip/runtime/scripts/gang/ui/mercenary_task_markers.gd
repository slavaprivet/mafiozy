extends Control
## mercenary_task_markers.mjs: bounded queue receipts; no command mutation.
const SelectionView=preload("res://scripts/gang/ui/mercenary_selection_view.gd")
var camera:Camera3D
var options:Dictionary={}
var _scene:Node3D
var _cap:int=10
var _records:Dictionary={}
var _pool:Array=[]
var _roof_anchors:Dictionary={}
var _disposed:bool=false
var _occlusion_enabled:bool=false
var _shown:int=0
var _builds:int=0
var _clock:float=0.0
var _last_ray:float=-INF
var _raycasts:int=0

func configure(view:Camera3D,providers:Dictionary,scene:Node3D,max_visible:int=10)->Dictionary:
	if _disposed or camera!=null or not is_instance_valid(view) or not is_instance_valid(scene):return {"ok":false,"reason":"markers_lifecycle"}
	camera=view;options=providers.duplicate();_scene=scene;_cap=clampi(max_visible,1,10);_occlusion_enabled=providers.get("occluded",Callable()).is_valid();mouse_filter=Control.MOUSE_FILTER_IGNORE;set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);z_index=97;return {"ok":true}

func _call(name:String,args:Array=[],fallback:Variant=null)->Variant:
	var cb:Callable=options.get(name,Callable());return cb.callv(args) if cb.is_valid() else fallback

func _done(target:Variant)->bool:
	if not target is Dictionary:return true
	var object:Variant=target.get("object")
	if not is_instance_valid(object) or not object is Node3D:return true
	var metadata:Variant=object.get_meta("mercenaryTarget",{});var meta:Dictionary=metadata if metadata is Dictionary else {}
	return target.get("valid",true)==false or target.get("invalid",false) or target.get("completed",false) or target.get("opened",false) or target.get("destroyed",false) or target.get("wrecked",false) or object.get_meta("mercenaryOpened",false) or meta.get("opened",false) or (target.get("kind","")=="fence" and (target.get("cut",false) or object.get_meta("mercenaryCut",false))) or (target.get("kind","")=="power_panel" and (target.get("powered",true)==false or target.get("disabled",false)))

func _hide(record:Dictionary)->void:record.node.hide()

func _acquire()->Dictionary:
	for record:Dictionary in _pool:
		if record.id==null:return record
	if _pool.size()>=_cap:return {}
	var label:Label=Label.new();label.mouse_filter=Control.MOUSE_FILTER_IGNORE;label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;label.custom_minimum_size.x=25;label.add_theme_font_size_override("font_size",13)
	var font:SystemFont=SystemFont.new();font.font_names=PackedStringArray(["Segoe UI","sans-serif"]);font.font_weight=700;label.add_theme_font_override("font",font);add_child(label);label.hide()
	var record:Dictionary={"node":label,"id":null,"object":null,"view":null,"anchor":Vector3.ZERO,"state":"","queued":null,"checkedAt":-INF,"occluded":_occlusion_enabled,"worldPoint":Vector3.ZERO,"target":null};_pool.append(record);return record

func _release(record:Dictionary)->void:
	record.id=null;record.object=null;record.target=null
	if is_instance_valid(record.view):record.view.set_target(null)
	_hide(record)

func _roof_anchor(object:Node3D,view:Variant)->Vector3:
	var key:int=object.get_instance_id()
	if _roof_anchors.has(key) and _roof_anchors[key].object.get_ref()==object:return _roof_anchors[key].anchor
	# Same actual mesh bounds; never writes geometry AABBs or collision state.
	var value:Variant=view.local_bounds(object);var anchor:Vector3=Vector3.ZERO
	if value is AABB:anchor=Vector3(value.get_center().x,value.end.y,value.get_center().z)
	_roof_anchors[key]={"object":weakref(object),"anchor":anchor};return anchor

func _make_view(record:Dictionary)->void:
	if is_instance_valid(record.view):return
	var view=SelectionView.new();add_child(view);view.configure(_scene);record.view=view

func sync(rows:Array=[],aimed:Variant=null)->Dictionary:
	if _disposed or camera==null:return {}
	var candidates:Array=[];var index:int=0
	for raw:Variant in rows:
		if raw is Dictionary and raw.has("target") and not _done(raw.target):
			var row:Dictionary=raw.duplicate();row._source_index=index;candidates.append(row)
		index+=1
	candidates.sort_custom(func(a:Dictionary,b:Dictionary)->bool:
		if bool(a.get("queued",false))!=bool(b.get("queued",false)):return not bool(a.get("queued",false))
		var an:int=int(a.get("number",1));var bn:int=int(b.get("number",1))
		return an<bn if an!=bn else a._source_index<b._source_index)
	var aim_id:Variant=str(aimed.get("id")) if aimed is Dictionary and not _done(aimed) else null;var aim_index:int=-1
	for i:int in candidates.size():
		if str(candidates[i].target.get("id"))==aim_id:aim_index=i;break
	if aim_index>=_cap:
		var row:Dictionary=candidates.pop_at(aim_index);candidates.insert(_cap-1,row)
	var external_aim:bool=aim_id!=null and aim_index<0;var limit:int=_cap-int(external_aim and aimed.get("kind","")!="vehicle");var chosen:Array=[];var seen:Dictionary={}
	for row:Dictionary in candidates:
		var id:String=str(row.target.get("id"))
		if seen.has(id) or chosen.size()>=limit:continue
		seen[id]=true;row.id=id;chosen.append(row)
	for id:String in _records.keys():
		if not seen.has(id):
			var record:Dictionary=_records[id];_records.erase(id);_release(record)
	for row:Dictionary in chosen:
		var target:Dictionary=row.target;var record:Dictionary=_records.get(row.id,{})
		if record.is_empty():
			record=_acquire()
			if record.is_empty():continue
			record.id=row.id;_records[row.id]=record
		var changed:bool=record.object!=target.object
		if changed:
			record.object=target.object
			if is_instance_valid(record.view):record.view.set_target(null)
			record.anchor=Vector3(0,.65 if target.get("downed",false) or float(target.get("hp",1))<=0 else 2.1,0) if target.get("kind","") in ["npc","player"] else Vector3(0,1.6,0);record.checkedAt=-INF;record.occluded=_occlusion_enabled
		if target.get("kind","")!="vehicle":
			_make_view(record);var before:int=int(record.view.stats().outlineBuilds);var marker_target:Dictionary=target.duplicate();marker_target.working=not row.get("queued",false);marker_target.queued=bool(row.get("queued",false));record.view.set_target(marker_target);_builds+=int(record.view.stats().outlineBuilds)-before
			var outline:Node=target.object.get_node_or_null("Mercenary_Object_Focus_Arcs")
			if is_instance_valid(outline):
				var bounds:Dictionary=outline.get_meta("focusBounds",{});var lo:Array=bounds.get("min",[]);var hi:Array=bounds.get("max",[])
				if lo.size()==3 and hi.size()==3:record.anchor=Vector3((lo[0]+hi[0])/2,hi[1]+.30,(lo[2]+hi[2])/2)
		else:
			if is_instance_valid(record.view):record.view.set_target(null)
			if changed:
				# A temporary bounds reader creates no world geometry for vehicles.
				var reader=SelectionView.new();record.anchor=_roof_anchor(target.object,reader);reader.free()
		var queued:bool=bool(row.get("queued",false));var color:Color=Color("d4aa62") if queued else Color("79d6a0")
		if record.queued!=queued:
			var style:StyleBoxFlat=StyleBoxFlat.new();style.bg_color=Color("18201fdd");style.border_color=color;style.set_border_width_all(1);style.set_corner_radius_all(12);style.content_margin_left=7;style.content_margin_right=7;style.content_margin_top=4;style.content_margin_bottom=4;record.node.add_theme_stylebox_override("normal",style);record.node.add_theme_color_override("font_color",color);record.queued=queued
		var label:String=str(row.get("number",1));record.node.text=label;record.node.set_meta("taskTarget",row.id);record.node.set_meta("taskNumber",label);record.node.set_meta("taskState","queued" if queued else "working");record.state="В очереди" if queued else "Выполняется";record.node.tooltip_text=str(row.get("memberName","Специалист"))+" · "+record.state+" · №"+label;record.target=target
	return seen

func update(delta:float=0)->void:
	if _disposed or not is_instance_valid(camera):return
	var step:float=maxf(0,delta) if is_finite(delta) else 0;_clock+=step;_shown=0;var next_check:Dictionary={};var viewport_size:Vector2=get_viewport_rect().size;var focus:Variant=_call("get_focus")
	for record:Dictionary in _records.values():
		if is_instance_valid(record.view):record.view.update(step)
		if _done(record.target):
			if is_instance_valid(record.view):record.view.set_target(null)
			_hide(record);continue
		var object:Node3D=record.object
		if not object.is_inside_tree() or not object.is_visible_in_tree() or viewport_size.x<=0 or viewport_size.y<=0:_hide(record);continue
		var point:Vector3=object.global_transform*record.anchor
		if record.target.get("kind","")=="vehicle":point.y+=.18
		if focus is Vector3 and point.distance_squared_to(focus)>10000:_hide(record);continue
		var depth:float=-camera.to_local(point).z;var pixel:Vector2=camera.unproject_position(point)
		if depth<camera.near or depth>camera.far or not pixel.is_finite() or pixel.x<0 or pixel.x>viewport_size.x or pixel.y<0 or pixel.y>viewport_size.y:_hide(record);continue
		record.worldPoint=point
		if _occlusion_enabled and (next_check.is_empty() or record.checkedAt<next_check.checkedAt):next_check=record
		record.node.size=record.node.get_combined_minimum_size();record.node.position=pixel-Vector2(record.node.size.x*.5,record.node.size.y);record.node.visible=not record.occluded
		if not record.occluded:_shown+=1
	if not next_check.is_empty() and _clock-_last_ray>=.05:
		_last_ray=_clock;var was_hidden:bool=next_check.occluded;next_check.checkedAt=_clock;var ignored:Array=[next_check.object]
		for actor:Variant in _call("get_actors",[],[]):
			var object:Variant=actor.get("object") if actor is Dictionary else actor
			if is_instance_valid(object) and object is Node3D and not ignored.has(object):ignored.append(object)
		_raycasts+=1;next_check.occluded=_call("occluded",[camera.global_position,next_check.worldPoint,ignored],true);next_check.node.visible=not next_check.occluded
		if was_hidden and not next_check.occluded:_shown+=1
		elif not was_hidden and next_check.occluded:_shown-=1

func clear()->void:sync()

func stats()->Dictionary:return {"active":_records.size(),"visible":_shown,"pooled":_pool.size(),"geometryBuilds":_builds,"cap":_cap,"raycasts":_raycasts}

func dispose()->void:
	if _disposed:return
	_disposed=true
	for record:Dictionary in _pool:
		if is_instance_valid(record.view):record.view.dispose();record.view.queue_free()
		if is_instance_valid(record.node):record.node.hide();record.node.queue_free()
	_records.clear();_pool.clear();_roof_anchors.clear();options.clear();camera=null;_scene=null;hide()

func _exit_tree()->void:dispose()
