extends Control
## Port of mercenary_action_menu.mjs. Providers retain all gameplay authority.
## The owning command UI calls update(delta) once per frame.
signal open_changed(opened:bool)
signal action_result(action_id:String, captured_target_id:String, receipt:Dictionary)

var _providers:Dictionary={}
var _configured=false
var _disposed=false
var _opened=false
var _pending=false
var _target_id=""
var _generation=0
var _elapsed=.2
var _cards:Dictionary={}
var _previous_focus:WeakRef
var panel:PanelContainer
var buttons:VBoxContainer
var status:Label

func _ready()->void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	z_index=8
	set_process(false)
	_build()

func configure(providers:Dictionary)->Dictionary:
	if _disposed or _configured:return {"ok":false,"reason":"ui_lifecycle"}
	for key:String in ["get_target","get_actions","on_choose"]:
		var callback:Variant=providers.get(key)
		if not callback is Callable or not callback.is_valid():return {"ok":false,"reason":"menu_provider:"+key}
	_providers=providers.duplicate()
	_configured=true
	return {"ok":true}

func _provider(key:String,args:Array=[],fallback:Variant=null)->Variant:
	var callback:Variant=_providers.get(key)
	return callback.callv(args) if callback is Callable and callback.is_valid() else fallback

func _transport_interaction()->bool:
	return _provider("is_transport_interaction",[],false)==true

func _style(background:String,border:String,padding:int,radius:int)->StyleBoxFlat:
	var box=StyleBoxFlat.new()
	box.bg_color=Color(background);box.border_color=Color(border)
	box.set_border_width_all(1);box.set_corner_radius_all(radius)
	box.content_margin_left=padding;box.content_margin_right=padding
	box.content_margin_top=padding;box.content_margin_bottom=padding
	return box

func _build()->void:
	var menu_theme=Theme.new()
	var font=SystemFont.new();font.font_names=PackedStringArray(["Segoe UI","sans-serif"])
	menu_theme.default_font=font;menu_theme.default_font_size=14
	menu_theme.set_color("font_color","Label",Color("f1e8d0"))
	menu_theme.set_color("font_color","Button",Color("ecf1dc"))
	menu_theme.set_stylebox("normal","Button",_style("284032","718e77",9,7))
	menu_theme.set_stylebox("hover","Button",_style("365440","b29c71",9,7))
	menu_theme.set_stylebox("focus","Button",_style("284032","edcf82",9,7))
	theme=menu_theme
	panel=PanelContainer.new();panel.name="MercenaryActionMenu"
	panel.mouse_filter=Control.MOUSE_FILTER_STOP
	panel.mouse_force_pass_scroll_events=false
	panel.add_theme_stylebox_override("panel",_style("17211ff2","b29c71",12,12))
	add_child(panel)
	var column=VBoxContainer.new();column.add_theme_constant_override("separation",7);panel.add_child(column)
	var heading=Label.new();heading.text="Выберите действие";heading.mouse_filter=Control.MOUSE_FILTER_IGNORE;column.add_child(heading)
	buttons=VBoxContainer.new();buttons.add_theme_constant_override("separation",6);column.add_child(buttons)
	status=Label.new();status.name="Status";status.add_theme_font_size_override("font_size",12)
	status.add_theme_color_override("font_color",Color("e7b59a"))
	status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;status.mouse_filter=Control.MOUSE_FILTER_IGNORE
	column.add_child(status)
	var cancel=Button.new();cancel.text="Отмена · Esc";cancel.alignment=HORIZONTAL_ALIGNMENT_LEFT
	cancel.add_theme_color_override("font_color",Color("b8c3b7"))
	cancel.add_theme_stylebox_override("normal",StyleBoxEmpty.new())
	cancel.pressed.connect(close);column.add_child(cancel)
	panel.hide();resized.connect(_layout);_layout()

func _layout()->void:
	if panel==null:return
	var viewport_size:Vector2=get_viewport_rect().size
	panel.size=Vector2(minf(320.0,maxf(210.0,viewport_size.x-24.0)),0)
	panel.position=Vector2((viewport_size.x-panel.size.x)*.5,viewport_size.y*.55)

func _eligible(value:Variant)->bool:
	if not value is Dictionary or value.is_empty():return false
	var valid:Variant=value.get("valid",true)
	return not (valid is bool and not valid) and not value.get("destroyed",false) and not value.get("wrecked",false) and not value.get("opened",false) and not value.get("cut",false) and not value.get("completed",false)

func _action_id(action:Dictionary)->String:
	var id:String=str(action.get("id",""))
	return id if id!="" else str(action.get("kind",""))

func _actions(target:Dictionary)->Array:
	var value:Variant=_provider("get_actions",[target],[])
	return value if value is Array else []

func _refresh()->void:
	if _disposed or not _opened:return
	var target:Variant=_provider("get_target",[_target_id])
	if not _eligible(target):close();return
	var seen:Dictionary={}
	for value:Variant in _actions(target):
		if not value is Dictionary:continue
		var id:String=_action_id(value)
		if id=="" or seen.has(id):continue
		seen[id]=true
		if not _cards.has(id):
			var button=Button.new();button.name="Action_"+id
			button.set_meta("action_id",id);button.alignment=HORIZONTAL_ALIGNMENT_LEFT
			button.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
			button.mouse_filter=Control.MOUSE_FILTER_STOP
			button.pressed.connect(choose.bind(id));buttons.add_child(button);_cards[id]=button
		var card:Button=_cards[id]
		card.text=("В очередь · " if value.get("willQueue",false) else "")+str(value.get("label",id))
		card.disabled=_pending;card.show()
	for id:String in _cards:
		if not seen.has(id):_cards[id].hide();_cards[id].disabled=true
	if seen.is_empty() and not _pending:status.text="Действия больше недоступны."
	_layout()

func open(target:Dictionary)->bool:
	if _disposed or not _configured or panel==null or _pending or not _eligible(target):return false
	if _transport_interaction():_interrupt_for_transport();return false
	if _provider("is_blocked",[],false)==true:return false
	var id:String=str(target.get("id",""))
	if id=="":return false
	if _opened:close()
	var focus:Control=get_viewport().gui_get_focus_owner()
	_previous_focus=weakref(focus) if focus!=null else null
	_target_id=id;_opened=true;_generation+=1;status.text="";panel.show()
	open_changed.emit(true);_provider("on_open_change",[true]);_refresh()
	if _opened:
		for card:Button in _cards.values():
			if card.visible and not card.disabled:card.grab_focus();break
	return _opened

func close()->void:
	if not _opened:return
	_opened=false;_target_id="";_generation+=1;panel.hide()
	open_changed.emit(false);_provider("on_open_change",[false])
	if _previous_focus!=null:
		var previous:Variant=_previous_focus.get_ref()
		if is_instance_valid(previous) and previous is Control and previous.is_visible_in_tree():previous.grab_focus()
	_previous_focus=null

func choose(id:String)->void:
	if _disposed or not _opened or _pending:return
	if _transport_interaction():_interrupt_for_transport();return
	var captured:String=_target_id
	var target:Variant=_provider("get_target",[captured])
	var available=false
	if _eligible(target):
		for value:Variant in _actions(target):
			if value is Dictionary and _action_id(value)==id:available=true;break
	if not available:
		status.text="Цель или специалист больше недоступны.";_refresh();return
	_pending=true;status.text="";_refresh()
	var generation:int=_generation
	var callback:Callable=_providers.on_choose
	var result:Variant=await callback.call(id,target)
	if _disposed:return
	# Match the source Promise microtask boundary for synchronous native hosts.
	await get_tree().process_frame
	if _disposed:return
	var receipt:Dictionary=result if result is Dictionary else {"ok":false,"reason":"invalid_host_receipt"}
	if _opened and generation==_generation and captured==_target_id:
		action_result.emit(id,captured,receipt)
		if receipt.get("ok") is bool and receipt.ok:close()
		else:status.text=_receipt_message(receipt)
	_pending=false;_refresh()

func _receipt_message(receipt:Dictionary)->String:
	for key:String in ["message","reason"]:
		var value:Variant=receipt.get(key)
		if value!=null and str(value)!="":return str(value)
	return "Приказ не принят."

func update(delta:float=0)->void:
	if _disposed:return
	if _transport_interaction():_interrupt_for_transport()
	_elapsed+=maxf(0,delta)
	if _elapsed>=.2:_elapsed=0;_refresh()

func is_open()->bool:
	return _opened

func target_id()->String:
	return _target_id

func blocks_world_input()->bool:
	return _opened and not _transport_interaction()

func hud_rects()->Array:
	return [panel.get_global_rect()] if panel!=null and _opened else []

func interrupt_for_transport()->void:
	# Parent calls this explicitly; no dependency on child input/process ordering.
	# Normal user close still restores focus, owner interruption never does.
	_interrupt_for_transport()

func _interrupt_for_transport()->void:
	if _disposed:return
	var focus:Control=get_viewport().gui_get_focus_owner()
	var owns_focus:bool=focus!=null and (focus==self or is_ancestor_of(focus))
	_previous_focus=null;close()
	if owns_focus and is_instance_valid(focus):focus.release_focus()

func _input(event:InputEvent)->void:
	if _disposed or not event is InputEventKey:return
	if _transport_interaction():_interrupt_for_transport();return
	if not _opened or not event.pressed or event.echo or get_viewport().is_input_handled():return
	if event.physical_keycode==KEY_X or event.keycode==KEY_X or event.keycode==KEY_ESCAPE:
		close();get_viewport().set_input_as_handled()

func dispose()->void:
	if _disposed:return
	close();_disposed=true;_generation+=1;_pending=false
	_providers.clear();_cards.clear();hide();set_process_input(false)

func _exit_tree()->void:
	dispose()
