Native gate belongs to the ONE shared BUILD freeze / QA run.

Use live host and the five existing bodies / original source IDs. Do not return ready-made ok results or duplicate target/inventory state for UI acceptance.

Check each of the eight actual actions through X aim/menu: approach, working, target effect acknowledgement, queue order/number, timer confirmation, denial/cancel/repeat/cooldown/resource rules supplied by the real owner. Reject a target deleted/completed or specialist unavailable after opening the captured-ID menu. Rejected/unconfirmed host responses must show actual reason and must not close as success.

Check V and X ground against actual host.follow/rally and physical movement: queues reset according to original policies, an already armed charge remains. The marker uses actual accepted point only. CharacterBody motion/effects remain BUILD/SERVICES/GAMEPLAY evidence.

Check management exact roster IDs, skill selection / max-level / hospital availability / host denied upgrade, real inventory weapon ID selection and dismissal, stable controls at 100ms. Existing R4 hire/conversation/nameplates remain byte-identical and observable in the same scene. Host replacement requires old consumer disposed before replacing callbacks.

Check accepted pending cancel followed by close/reopen or member/whole-squad switch: old receipt cannot close current panel. Start action menu with external control focus, interrupt under transport parent-first and child-first: clear saved restore target, release only menu-owned focus, do not restore or release foreign control. Check pending double X/V/click, menu close/reopen and transport interruption during replies, text/OptionButton input guards and E press/repeat/release/focus loss. E is never consumed by new modules; transport reservation remains the authoritative provider.

Observe genuine timer awaiting/working/approach/armed/safety/deadline text, max five works + five charges and ten pooled slots; actual same targets on real camera; marker cap ten/active before queued/stable tie ordering/aim reservation/real ignored-actor occlusion. Timer visible rectangles mask badges, transparent full marker layer does not. Dispose/scene exit frees only presentation nodes, no persistent outline left on live target.

Record native source pins, actual GUI/visual findings, and suitable update CPU/render/alloc observations honestly. Original JS14 and grammar5 do not accept the native implementation. No additional standalone engine job, physical-vehicle or city286 acceptance implied.
