// Actual source host/core replay. Movement/effect/providers are explicit fixture boundaries.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const repo=path.resolve(process.argv[2]), output=path.resolve(process.argv[3]);
const sourcePath=path.join(repo,'assets/maps/city_rebuild_v1/mercenary_world.js');
const corePath=path.join(repo,'assets/maps/city_rebuild_v1/mercenary_core.mjs');
const module=await import(pathToFileURL(corePath));
const source=fs.readFileSync(sourcePath,'utf8');
const script=source.replace("import(new URL('./mercenary_core.mjs',scriptUrl).href)",'Promise.resolve(module)');
assert.notEqual(script,source);
async function fixture(local=true){
 let clock=1000000; const storage=new Map();
 const ctx={module,URL,Promise,console,Date:{now:()=>clock*1000},performance:{now:()=>clock*1000},
  document:{documentElement:{dataset:{worldWalkReady:'first-populated-frame'}},currentScript:{src:'http://localhost/assets/maps/city_rebuild_v1/mercenary_world.js'}},
  location:{origin:'http://localhost'},window:{MAFIOZI_RENDERER_CONFIG:{worldScale:4.1}},
  localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
  _LOCAL_PREVIEW:local,_serverAuthoritativeAmmo:!local,_customGang:null,_myGang:[],
  NPCS:Array.from({length:8},(_,i)=>({id:'civilian'+i,r:10,c:10+i*.1,hp:80,max_hp:80,name:'NPC '+i,look:{hair:i}})),
  player:{r:10,c:10},myHp:100,myDead:false,GANG_MAX:5,_hiredBotIds:new Set(),
  _inventoryItems:[{id:'pistol',type:'weapon',qty:2},{id:'rifle',type:'weapon',qty:1}],
  currentWeapon:'pistol',QP:{cash:500},_syncMyWeaponsFromInventory(){},_saveCurrentWeaponChoice(){},renderWeaponHud(){},_saveGang(){},
  _npcBodyPassable:()=>true,_npcPathPassable:()=>true,_hospitalDoor:()=>({r:10,c:11})};
 ctx._dismissGangMember=id=>{const index=ctx._myGang.findIndex(m=>m.id===id);if(index<0)return false;ctx._myGang.splice(index,1);return true;};
 vm.createContext(ctx);vm.runInContext(script,ctx);await new Promise(resolve=>setImmediate(resolve));
 return {ctx,api:ctx.window.MafioziMercenaries,step(dt=.05){clock+=dt;ctx.window.MafioziMercenaries.tick(dt);}};
}

const f=await fixture();for(const c of f.api.getRoster().candidates)assert(f.api.recruit(c.id).ok);
const member=f.ctx._myGang.find(m=>f.api.getRoster().members.find(r=>r.id===m.id).profession==='engineer');
const targets=new Map([['fence:a',{id:'fence:a',kind:'fence',position:{x:60,y:0,z:41}}],['fence:b',{id:'fence:b',kind:'fence',position:{x:70,y:0,z:41}}]]);
f.api.bindTargets({get:id=>targets.get(id)||null,canMove:()=>true,groundHeight:()=>0,performEffect:()=>false});
assert(f.api.command('cut_fence',targets.get('fence:a')).ok);const queued=f.api.command('cut_fence',targets.get('fence:b'));assert(queued.ok&&queued.queued);
const expected=JSON.parse(JSON.stringify(f.api.getQueue(member.id)));assert.equal(expected.length,1);assert.equal(expected[0].targetId,'fence:b');
const aliases=[member.id,'npc:'+member.id,'crew_'+member.id,'npc_crew_'+member.id,'npc:crew_'+member.id,'npc:npc_crew_'+member.id];
const cases=aliases.map(alias=>{const actual=JSON.parse(JSON.stringify(f.api.getQueue(alias)));assert.deepEqual(actual,expected);return {alias,queue:actual};});
assert.deepEqual(JSON.parse(JSON.stringify(f.api.getQueue('npc:crew_missing'))),[]);
const result={status:'PASS_SOURCE_ONLY',cases,source_pins:Object.fromEntries([sourcePath,corePath].map(p=>[path.relative(repo,p).replaceAll('\\','/'),createHash('sha256').update(fs.readFileSync(p)).digest('hex')])),boundary:'Actual JS world/core queues; native samehost/core pending common QA, engine0'};
fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,cases:cases.length}));
