import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const [sourceArg,outputArg]=process.argv.slice(2);
if(!sourceArg||!outputArg)throw new Error('Usage: node catchup_distance_boundaries.mjs <original source directory> <output json>');
const file=path.resolve(sourceArg,'mercenary_catchup.mjs'),output=path.resolve(outputArg);
const source=await import(pathToFileURL(file));
const sha=value=>createHash('sha256').update(value).digest('hex');
const copy=value=>JSON.parse(JSON.stringify(value));
const cases=[];
const times=end=>Array.from({length:end/1000+1},(_,i)=>i*1000);
const member=(base,x)=>({id:'m',owned:true,status:'active',hp:100,order:'follow',position:{x:base+x,z:base}});
const hero=base=>({position:{x:base,z:base},alive:true,angle:0});
const update=(base,x,now)=>({op:'update',input:{now,hero:hero(base),members:[member(base,x)]}});
const sides=[['below',-1],['exact',0],['above',1]];
for(const base of [0,1000])for(const [side,sign]of sides){
 const suffix=side+'_base'+base;
 const far=65+sign*1e-6;
 cases.push({id:'far65_'+suffix,api:'catchup',boundary:{kind:'far',base,nominal:far,actual:Math.hypot((base+far)-base,0),expect_relocations:sign>0?1:0},steps:[...times(6000),6059,6060].map(now=>update(base,far,now))});
 const progress=1.25+sign*1e-8,initial=base+30,next=initial+progress;
 cases.push({id:'progress125_'+suffix,api:'catchup',boundary:{kind:'progress',base,nominal:progress,actual:Math.hypot(next-initial,0),expect_relocations:sign<0?1:0},steps:[...times(9000).map(now=>update(base,30,now)),... [10000,10060].map(now=>({op:'update',input:{now,hero:hero(base),members:[{...member(base,30),position:{x:next,z:base}}]}}))]});
 const candidate={x:base+Math.cos(Math.PI)*3.6,z:base+Math.sin(Math.PI)*3.6};
 const separation=1.6+sign*1e-8,occupied={id:'other',x:candidate.x+separation,z:candidate.z};
 cases.push({id:'occupied16_'+suffix,api:'drop',boundary:{kind:'occupied',base,nominal:separation,actual:Math.hypot(occupied.x-candidate.x,occupied.z-candidate.z),expect_first_attempt:sign<0?1:0},steps:[0,60].map(now=>({op:'call',input:{origin:{x:base,z:base},memberId:'m',now,occupied:[occupied]}}))});
 const lower=2.5+sign*1e-8,moved={x:candidate.x+lower,z:candidate.z};
 cases.push({id:'drop_min25_'+suffix,api:'drop',boundary:{kind:'drop_min',base,nominal:lower,actual:Math.hypot(moved.x-candidate.x,moved.z-candidate.z),expect_final:sign<0?'pending':'ready'},steps:[{op:'call',input:{origin:{x:base,z:base},memberId:'m',now:0}},{op:'call',input:{origin:moved,memberId:'m',now:60}}]});
}
// Both axes are individually representable float32 body coordinates. Their
// Float64 Euclidean norm still crosses a boundary collapsed by Vector2.length.
const norm32=(x,z)=>Math.fround(Math.sqrt(Math.fround(Math.fround(x*x)+Math.fround(z*z))));
const farPoint={x:Math.fround(65),z:Math.fround(.0005)};
assert(Math.hypot(farPoint.x,farPoint.z)>65&&norm32(farPoint.x,farPoint.z)===65);
cases.push({id:'far65_float32_axes_nonaxis_norm',api:'catchup',boundary:{kind:'far',actual:Math.hypot(farPoint.x,farPoint.z),float32_norm_model:norm32(farPoint.x,farPoint.z),coordinates_float32_representable:true,expect_relocations:1},steps:[...times(6000),6059,6060].map(now=>({op:'update',input:{now,hero:hero(0),members:[{...member(0,0),position:farPoint}]}}))});
const progressPoint={x:Math.fround(1.24999988),z:Math.fround(.0005)};
assert(Math.hypot(progressPoint.x,progressPoint.z)<1.25&&norm32(progressPoint.x,progressPoint.z)===1.25);
const progressHero={position:{x:-30,z:0},alive:true,angle:0};
cases.push({id:'progress125_float32_axes_nonaxis_norm',api:'catchup',boundary:{kind:'progress',actual:Math.hypot(progressPoint.x,progressPoint.z),float32_norm_model:norm32(progressPoint.x,progressPoint.z),coordinates_float32_representable:true,expect_relocations:1},steps:[...times(9000).map(now=>({op:'update',input:{now,hero:progressHero,members:[member(0,0)]}})),...[10000,10060].map(now=>({op:'update',input:{now,hero:progressHero,members:[{...member(0,0),position:progressPoint}]}}))]});
let checks=0;
const verify=(condition,label)=>{checks++;assert(condition,label);};
function run(c){
 const state={},calls=[],engine=c.api==='catchup'?source.createMercenaryCatchup({placement:{check:(p,m)=>validate(p,m)}}):null;
 function validate(point,member){const result={ok:true,point:{...point,y:0}};calls.push({provider:'placement.check',point:copy(point),member:copy(member),result:copy(result)});return result;}
 const steps=c.steps.map(step=>{
  const input=copy(step.input),cursor=calls.length;let result,inspection,stats=null;
  if(c.api==='catchup'){
   const before=JSON.stringify(input);result=engine.update(input);verify(before===JSON.stringify(input),c.id+' preserves host input');inspection=Object.fromEntries(input.members.map(m=>[m.id,engine.inspect(m.id)]));stats=copy(engine.stats);
  }else{result=source.advanceMercenarySafeDrop(state,{...input,validate});inspection=copy(state);}
  verify(result.checks<=4,c.id+' check limit');
  return {op:step.op,input,fixture_clock:0,expected:{result:copy(result),inspection:copy(inspection),stats,provider_calls:copy(calls.slice(cursor))}};
 });
 const b=c.boundary;
 if('expect_relocations'in b)verify(steps.reduce((n,s)=>n+s.expected.result.relocations.length,0)===b.expect_relocations,c.id+' exact source crossing');
 if('expect_first_attempt'in b)verify(steps[0].expected.inspection.attempt===b.expect_first_attempt,c.id+' occupied strict-less boundary');
 if('expect_final'in b)verify(steps.at(-1).expected.result.status===b.expect_final,c.id+' pending point minimum distance');
 return {...c,steps};
}
const observed=cases.map(run),stepCount=observed.reduce((n,c)=>n+c.steps.length,0);
const result={schema:'walk.movement.source_cases.v1',status:'SOURCE_ORACLE_EXECUTED_NATIVE_NOT_RUN',sources:[{name:'mercenary_catchup.mjs',sha256:sha(fs.readFileSync(file)),role:'executed_direct_import'}],supplement:{id:'catchup_distance_boundaries_v1',case_count:observed.length,step_count:stepCount,assertion_count:checks,oracle_sha256:sha(fs.readFileSync(new URL(import.meta.url))),native_status:'NOT_RUN',engine_jobs:0,immutable_original:'movement_stage01 83/488 cases not regenerated or edited',replay:'catchup_distance_boundary_checks.gd inherits unchanged replay and recursively exact comparator; numeric abs tolerance1e-9',purpose:'Distinguish Float64 Math.hypot threshold branches that Vector2 float32 may collapse. Boundary.actual records JS subtraction and Math.hypot, not nominal decimal assumption.'},provider_contract:{placement:'exact allow callback returns original point plus y=0 and records call order',clock:'explicit now milliseconds; <=1000ms between catchup samples, no accidental interrupted reset',comparison:'branch statuses/counts/state/provider ordering exact; float tolerance1e-9'},cases:observed};
fs.mkdirSync(path.dirname(output),{recursive:true});const json=JSON.stringify(result,null,2)+'\n';fs.writeFileSync(output,json);console.log(JSON.stringify({cases:observed.length,steps:stepCount,assertions:checks,sha256:sha(json),oracle_sha256:result.supplement.oracle_sha256}));
