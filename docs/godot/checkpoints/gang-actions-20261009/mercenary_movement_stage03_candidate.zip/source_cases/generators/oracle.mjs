import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

// node oracle.mjs <original source directory> <output directory>
// Direct imports only: no rewritten/extracted source, engine, or physical simulation.
const [sourceArg,outArg]=process.argv.slice(2);
if(!sourceArg||!outArg)throw new Error('Usage: node oracle.mjs <source directory> <output directory>');
const source=path.resolve(sourceArg),out=path.resolve(outArg);
const catchup=await import(pathToFileURL(path.join(source,'mercenary_catchup.mjs')));
const follow=await import(pathToFileURL(path.join(source,'mercenary_long_follow.mjs')));
const clone=x=>JSON.parse(JSON.stringify(x));
const hash=b=>createHash('sha256').update(b).digest('hex');
const member=(extra={})=>({id:'m',owned:true,status:'active',hp:100,order:'follow',position:{x:100,z:0},...extra});
const hero={position:{x:0,z:0},alive:true,angle:0};
const cases=[];
const add=(id,api,steps,extra={})=>cases.push({id,api,steps,...extra});
const times=end=>Array.from({length:Math.floor(end/1000)+1},(_,i)=>i*1000);
const updates=(ts,extra={})=>ts.map(now=>({op:'update',input:{now,hero:clone(hero),members:[member()],...clone(extra)}}));
for(const [label,value]of Object.entries({default:{},missing_order:{order:null},rally:{order:'rally'},hold:{order:'hold'},not_owned:{owned:false},downed:{status:'downed'},hospital:{status:'hospital'},returning:{status:'returning'},zero_hp:{hp:0},dead:{dead:true},action:{action:{}},queued:{queued:true},combat:{combat:true},carried:{carried:true},carrying:{carrying:true},seated:{seated:true},vehicleChase:{vehicleChase:true},interior:{interior:true},safeExit:{safeExit:true},conversation:{conversation:true},bad_position:{position:{x:0}}}))
 add('eligibility_'+label,'eligible',[{input:member(value)}]);
for(const x of [65,65.000001])add('far_distance_'+x,'catchup',updates([...times(6000),6059,6060],{members:[member({position:{x,z:0}})]}));
add('far_delay_and_confirmation','catchup',updates([...times(5000),5999,6000,6059,6060,6060,6061]));
for(const x of [12,12.000001,30])add('stuck_distance_'+x,'catchup',updates([...times(10000),10059,10060],{members:[member({position:{x,z:0}})]}));
for(const progress of [1.249999,1.25]){
 const steps=updates(times(9000),{members:[member({position:{x:30,z:0}})]});
 steps.push(...updates([10000,10060],{members:[member({position:{x:30+progress,z:0}})]}));
 add('progress_threshold_'+progress,'catchup',steps);
}
add('slow_progress_far_still_recovers','catchup',[...times(6000),6060].map(now=>({op:'update',input:{now,hero:clone(hero),members:[member({position:{x:100-now/1000*.25,z:0}})]}})));
for(const gap of [1000,1001])add('pause_gap_'+gap,'catchup',[...updates(times(5000)),...updates([5000+gap,5060+gap])]);
add('time_reversal_resets','catchup',[...updates(times(5000)),...updates([4000,5000,6000])]);
for(const [label,patch] of Object.entries({disabled:{enabled:false},hero_dead:{hero:{...hero,alive:false}},hero_vehicle:{hero:{...hero,inVehicle:true}},hero_interior:{hero:{...hero,interior:true}},member_dead:{members:[member({dead:true})]},order_rally:{members:[member({order:'rally'})]},task_active:{members:[member({action:{id:'a'}})]}}))
 add('interruption_'+label,'catchup',[...updates(times(5000)),...updates([6000],patch),...updates([7000,8000,9000,10000,11000,12000,12999,13000,13060])]);
add('clear_cancel_repeat','catchup',[...updates(times(5000)),{op:'clear'},...updates([6000,7000,8000,9000,10000,11000,12000,12060]),{op:'clear'},{op:'clear'}]);
add('roster_removed_and_readded','catchup',[...updates(times(5000)),...updates([6000],{members:[]}),...updates([7000,8000,9000,10000,11000,12000,13000,13060])]);
add('placement_unavailable','catchup',updates([...times(11000),11060]),{placement:'missing'});
add('unsafe_search_blocked_and_retry','catchup',updates([...times(6000),6100,6200,6300,6400,6500,6600,6700,7000,8000,8699,8700]),{placement:'deny'});
add('cooldown_exact_boundary_repeated_far_request','catchup',updates([...times(6000),6060,...Array.from({length:19},(_,i)=>7060+i*1000),26059,26060,26120]));
add('zero_budget','catchup',updates([...times(6000),6060],{maxChecks:0}));
add('bounded_five_member_roster_order','catchup',updates([...times(6000),6060,6120,6180,6240,6300],{members:['e','a','d','b','c'].map((id,i)=>member({id,position:{x:100+i*3,z:0}})),maxChecks:99}),{options:{maxChecksPerUpdate:99}});

const dropInput=now=>({origin:{x:0,z:0},memberId:'m',now});
add('drop_confirmation_boundary_repeated_ready','drop',[0,59,60,60,119,120].map(now=>({input:dropInput(now)})));
add('drop_blocked_retry_exact','drop',[0,50,100,150,200,250,300,350,2349,2350].map(now=>({input:dropInput(now)})),{placement:'deny'});
for(const y of [.08,.080001])add('drop_height_change_'+y,'drop',[{input:dropInput(0)},{input:dropInput(60),placementY:y}]);
for(const x of [2,2.000001])add('drop_origin_reset_'+x,'drop',[{input:dropInput(0)},{input:{...dropInput(60),origin:{x,z:0}}}]);
add('drop_zero_budget','drop',[{input:{...dropInput(0),maxChecks:0}},{input:{...dropInput(60),maxChecks:99}}]);
add('drop_occupied_candidate_skip','drop',[{input:{...dropInput(0),occupied:[{id:'other',x:-3.6,z:0}]}},{input:{...dropInput(60),occupied:[{id:'other',x:-3.6,z:0}]}}]);
add('drop_member_identity_reset','drop',[{input:dropInput(0)},{input:{...dropInput(60),memberId:'new'}}]);

for(const [id,provider]of Object.entries({valid:{},missing_resolver:{missing:'blocksVehicle'},not_ready:{ready:false},body_blocked:{bodyClear:false},solid:{blocked:true},water_at_limit:{depth:.025},water_over_limit:{depth:.025001},uneven_at_limit:{high:.28},uneven_over_limit:{high:.280001},building:{inside:true},vehicle:{vehicle:true}}))
 add('placement_'+id,'placement',[{input:{point:{x:2,z:3},member:member()}}],{provider});

const fstep=(now,extra={})=>({op:'advance',input:{now,from:{x:0,z:0},goal:{x:30,z:0},options:{},...extra}});
add('follow_budget_zero','follow',[fstep(0,{options:{budgetMs:0}}),fstep(50,{options:{maxExpanded:0}}),fstep(100)]);
add('follow_unreachable_fan_retry','follow',[0,50,100,150,200,250,2249,2250].map(now=>fstep(now)),{collision:'deny'});
for(const radius of [.6,.600001])add('follow_arrival_'+radius,'follow',[fstep(0,{goal:{x:radius,z:0}}),fstep(0,{goal:{x:radius,z:0}})]);
for(const [label,options]of Object.entries({inactive:{active:false},rally:{purpose:'rally'},action:{purpose:'plant_bomb'}}))add('follow_cancel_'+label,'follow',[fstep(0,{options:{maxExpanded:1}}),fstep(50,{options}),fstep(100,{options})]);
add('follow_explicit_cancel_repeat','follow',[fstep(0),{op:'cancel'},{op:'cancel'},fstep(50)]);
add('follow_host_blocked_500ms','follow',[fstep(0),{op:'blocked',now:50},fstep(549),fstep(550)]);
for(const drift of [12,12.000001])add('follow_large_retarget_'+drift,'follow',[fstep(0,{options:{maxExpanded:1}}),fstep(50,{goal:{x:30,z:drift},options:{maxExpanded:1}})]);
for(const [now,drift]of [[6000,.800001],[6001,.8],[6001,.800001]])add('follow_stale_retarget_'+now+'_'+drift,'follow',[fstep(0,{options:{maxExpanded:1}}),fstep(now,{goal:{x:30,z:drift},options:{maxExpanded:1}})]);
add('follow_stage_complete_then_final_arrival','follow',[...Array.from({length:15},(_,i)=>fstep(i*50)),fstep(750,{from:{x:24,z:0}}),...Array.from({length:5},(_,i)=>fstep(800+i*50,{from:{x:24,z:0}})),fstep(1100,{from:{x:30,z:0}}),fstep(1150,{from:{x:30,z:0}})]);
add('follow_small_moving_goal_preserves_work','follow',Array.from({length:10},(_,i)=>fstep(i*50,{goal:{x:30,z:i*.04},options:{maxExpanded:1}})));

let invariantChecks=0;
function verify(condition,message){invariantChecks++;assert(condition,message);}
function execute(c){
 const calls=[];let activeY=0,clock=0;
 const validate=(point,m)=>{const result=c.placement==='deny'?{ok:false,reason:'fixture_blocked'}:{ok:true,point:{...point,y:activeY}};calls.push({provider:'placement.check',point:clone(point),member:clone(m),result:clone(result)});return result;};
 const engine=c.api==='catchup'?catchup.createMercenaryCatchup({...c.options,placement:c.placement==='missing'?undefined:{check:validate}}):c.api==='follow'?follow.createMercenaryLongFollow({clock:()=>clock,groundHeight:()=>0,canMove:(from,to)=>{const result=c.collision!=='deny';calls.push({provider:'canMove',from:clone(from),to:clone(to),result});return result;}}):null;
 const state={},steps=[];
 for(const step of c.steps){
  const input=clone(step.input??{}),beforeCalls=calls.length;let result,inspection;
  if(step.placementY!==undefined)activeY=step.placementY;
  if(c.api==='eligible')result=catchup.mercenaryCatchupEligible(input);
  else if(c.api==='catchup'){
   if(step.op==='clear'){engine.clear();result=null;inspection=null;}
   else{const before=JSON.stringify(input);result=engine.update(input);verify(JSON.stringify(input)===before,c.id+': source must not mutate host inputs');verify(result.checks<=4,c.id+': check bound');verify(result.relocations.length<=1,c.id+': one relocation per update');inspection=Object.fromEntries(input.members.map(m=>[m.id,engine.inspect(m.id)]));}
  }else if(c.api==='drop'){
   result=catchup.advanceMercenarySafeDrop(state,{...input,validate});inspection=clone(state);verify(result.checks<=4,c.id+': drop check bound');
  }else if(c.api==='placement'){
   const p=c.provider||{},provider={worldScale:4.1,ready:()=>p.ready??true,bodyClear:()=>p.bodyClear??true,queryPoint:()=>({blocked:p.blocked??false,depth:p.depth??0}),groundHeight:(x)=>x>input.point.x?(p.high??0):0,isInsideBuilding:()=>p.inside??false,blocksVehicle:()=>p.vehicle??false};
   if(p.missing)delete provider[p.missing];
   for(const [name,fn]of Object.entries(provider))if(typeof fn==='function')provider[name]=(...args)=>{const value=fn(...args);calls.push({provider:name,args:clone(args),result:clone(value)});return value;};
   const resolver=catchup.createMercenarySafePlacement(provider);result=resolver.check(input.point,input.member);inspection={radius:resolver.radius,height:resolver.height};
  }else if(c.api==='follow'){
   clock=input.now??step.now??clock;const before=engine.stats.expanded;
   if(step.op==='cancel')result=engine.cancel();else if(step.op==='blocked'){engine.blocked();result=null;}else result=engine.advance(input.from,input.goal,input.options);
   inspection=engine.inspect();verify(engine.stats.expanded-before<=8,c.id+': follow expansion bound');
  }
  steps.push({op:step.op??'call',input,fixture_clock:clock,...(step.placementY!==undefined?{placement_y:step.placementY}:{}),expected:{result:clone(result),inspection:inspection===undefined?null:clone(inspection),stats:engine?clone(engine.stats):null,provider_calls:calls.slice(beforeCalls)}});
 }
 return {...c,steps};
}
const observed=cases.map(execute);
const by=id=>observed.find(c=>c.id===id);
const reloc=id=>by(id).steps.flatMap(s=>s.expected.result?.relocations??[]);
verify(reloc('far_distance_65').length===0,'65m is not far before stuck threshold');
verify(reloc('far_distance_65.000001').length===1,'strict far threshold');
verify(reloc('slow_progress_far_still_recovers').length===1,'progress does not suppress sustained far');
verify(reloc('pause_gap_1001').length===0,'pause resets grace');
verify(reloc('progress_threshold_1.25').length===0,'exact progress resets grace');
verify(reloc('progress_threshold_1.249999').length===1,'subthreshold progress does not reset grace');
verify(reloc('cooldown_exact_boundary_repeated_far_request').length===2,'cooldown allows next confirmed request at boundary plus60ms');
verify(by('cooldown_exact_boundary_repeated_far_request').steps.at(-3).expected.inspection.m.reason==='cooldown','cooldown remains active 1ms before boundary');
verify(by('drop_confirmation_boundary_repeated_ready').steps[1].expected.result.checks===0,'59ms waits');
verify(by('drop_confirmation_boundary_repeated_ready').steps[2].expected.result.status==='ready','60ms confirms');
verify(by('follow_stage_complete_then_final_arrival').steps.some(s=>s.expected.result?.status==='stage_complete'),'stage completion covered');
verify(by('follow_stage_complete_then_final_arrival').steps.at(-1).expected.result.status==='arrived','repeat completion remains arrived');
verify(by('follow_unreachable_fan_retry').steps[5].expected.result.status==='blocked','finite fan exhausted');

fs.mkdirSync(out,{recursive:true});
const files=['mercenary_catchup.mjs','mercenary_long_follow.mjs','mercenary_route.mjs','test_mercenary_catchup23.mjs','test_mercenary_long_follow23_candidate.mjs'];
const sources=files.map(name=>({name,sha256:hash(fs.readFileSync(path.join(source,name))),role:name.startsWith('test_')?'reference_read_only':'executed_direct_import'}));
const payload={schema:'walk.movement.source_cases.v1',status:'SOURCE_ORACLE_EXECUTED_NATIVE_NOT_RUN',sources,provider_contract:{placement:'allow returns supplied x/z plus y=0 unless step overrides; deny returns fixture_blocked; missing means no check provider',collision:'allow/deny deterministic injected predicate; no actual collision authority claimed',clock:'explicit per step milliseconds; constant within one follow call gives deterministic expansion budget, not CPU timing proof',coordinates:'source metres, horizontal x/z; same input values must be used by differential target',numeric_comparison:'exact booleans/status/ids/counts; float absolute tolerance 1e-9'},scope:{proven:'exported policy outputs/state/statistics given explicit providers and supplied positions',not_proven:['Godot parity','physical locomotion or NavMesh','full rally/order API','host death-to-active mapping','real safe ground/body/water/vehicle collision','CPU wall-clock budget','UI or effects'],ownership:'BUILD supplies physical motion/collision; SERVICES supplies effects. Source relocation is a request and never applied by this oracle.'},cases:observed};
const fixtureText=JSON.stringify(payload,null,2)+'\n';fs.writeFileSync(path.join(out,'movement_source_cases.json'),fixtureText);
const receipt={schema:'walk.movement.source_receipt.v1',status:'PASS_SOURCE_ONLY',node:process.version,case_count:observed.length,step_count:observed.reduce((n,c)=>n+c.steps.length,0),invariant_checks:invariantChecks,native_status:'NOT_RUN',engine_jobs:0,source_files:sources,oracle_sha256:hash(fs.readFileSync(new URL(import.meta.url))),fixture_sha256:hash(fixtureText),counts_by_api:Object.fromEntries([...new Set(cases.map(c=>c.api))].map(api=>[api,cases.filter(c=>c.api===api).length])),source_lines:{catchup:{safe_placement:[8,26],eligibility:[29,31],safe_drop:[34,57],controller:[60,93]},long_follow:{factory:[7,74],advance:[27,68]},route:{factory:[3,25]}},notes:['Repeated catchup requests deliberately retain caller positions to test cooldown; this is not host relocation simulation.','order:rally only proves catchup exclusion and long-follow cancellation; full rally must be independently exercised through host API.','Follow completion supplies explicit positions at source stage endpoint; it does not simulate or certify physics.','Fixtures are generated from unchanged source imports, never expected outputs reimplemented in the harness.']};
fs.writeFileSync(path.join(out,'SOURCE_ORACLE_RECEIPT.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
