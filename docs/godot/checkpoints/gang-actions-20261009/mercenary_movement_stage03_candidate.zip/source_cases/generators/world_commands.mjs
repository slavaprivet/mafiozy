import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const [sourceArg,outputArg]=process.argv.slice(2);
if(!sourceArg||!outputArg)throw new Error('Usage: node world_commands.mjs <source directory> <output json>');
const source=path.resolve(sourceArg),output=path.resolve(outputArg);
const read=name=>fs.readFileSync(path.join(source,name),'utf8');
const sha=x=>createHash('sha256').update(x).digest('hex');
const clean=value=>value===undefined?null:JSON.parse(JSON.stringify(value));
const module=await import(pathToFileURL(path.join(source,'mercenary_core.mjs')));
const original=read('mercenary_world.js');
const importExpression="import(new URL('./mercenary_core.mjs',scriptUrl).href)";
assert.equal(original.split(importExpression).length,2,'exact one fixture import substitution');
const script=original.replace(importExpression,'Promise.resolve(module)');
const fixtureText=read('test_mercenary_rally_actions.mjs');
const fixtureBody=fixtureText.slice(fixtureText.indexOf('async function fixture('),fixtureText.indexOf('\nfor(const [profession'));
assert(fixtureBody.startsWith('async function fixture('));
assert(fixtureBody.includes('clock+=dt;api.tick(.05);'),'preserve original elapsed fixture semantics');
const fixture=Function('vm','module','script','assert',fixtureBody+';return fixture;')(vm,module,script,assert);
const cases=[];let assertions=0;
const check=(condition,message)=>{assertions++;assert(condition,message);};

async function setup(id,profession){
 const f=await fixture({qa:true}),m=f.recruit(profession),calls=[],targets=new Map(),settlers=new Map(),steps=[];
 const policy={pending:false,canMove:true};
 const snapshot=()=>{
  const publicMember=f.api.getMember(m.id),roster=f.api.getRoster().members.find(r=>r.id===m.id);
  return clean({clock_ms:f.ctx.performance.now(),id:m.id,position:publicMember.position,posture:publicMember.posture,order:roster.order,status:roster.status,action:f.api.getAction(m.id),queue:f.api.getQueue(m.id),movement:publicMember.movement,safe_exit:m._mercenarySafeExit??null,rally:m._mercenaryRally??null,move:m._mercenaryMove??null,follow_speed:m._followSpeed??0,effect_count:calls.filter(c=>c.provider==='performEffect').length});
 };
 f.api.bindTargets({get:targetId=>targets.get(targetId),canMove:(from,to,memberId)=>{calls.push({provider:'canMove',from:clean(from),to:clean(to),memberId:memberId??null,result:policy.canMove});return policy.canMove;},groundHeight:()=>0,performEffect:e=>{
  calls.push({provider:'performEffect',event:clean(e),return_kind:policy.pending?'pending_promise':'receipt'});
  if(policy.pending)return new Promise(resolve=>settlers.set(e.targetId,resolve));
  const t=targets.get(e.targetId);if(t){if(e.kind==='disable_power')t.powered=false;else if(e.kind==='cut_fence')t.cut=true;else t.locked=false;}
  return {ok:true};
 }});
 const record=(operation,input,fn)=>{const cursor=calls.length,result=fn();steps.push({operation,input:clean(input),result:clean(result),snapshot:snapshot(),provider_calls:clean(calls.slice(cursor))});return result;};
 const configurePolicy=patch=>record('fixture_provider_policy',patch,()=>{Object.assign(policy,patch);});
 const placeMember=(c,r)=>record('fixture_member_position',{c,r},()=>{m.c=c;m.r=r;});
 const tick=(dt=.05)=>record('fixture.tick',{clock_increment_seconds:dt,api_tick_argument:.05},()=>f.tick(dt));
 const command=(kind,target)=>record('command',{kind,target:clean(target)},()=>f.api.command(kind,target));
 const order=kind=>record(kind,kind==='rally'?{point:{x:60,y:0,z:41}}:{},()=>kind==='rally'?f.api.rally({x:60,y:0,z:41}):f.api.follow());
 const settle=async(targetId,ok=true)=>{const cursor=calls.length,t=targets.get(targetId);if(t)t.locked=!ok;check(settlers.has(targetId),id+': pending resolver exists');settlers.get(targetId)({ok});await Promise.resolve();await Promise.resolve();steps.push({operation:'resolve_receipt',input:{targetId,ok},result:null,snapshot:snapshot(),provider_calls:clean(calls.slice(cursor))});};
 const add=(target)=>{targets.set(target.id,target);return target;};
 const effects=()=>calls.filter(c=>c.provider==='performEffect');
 const finish=notes=>{cases.push({id,fixture_options:{qa:true,clockStart:1000},profession,initial:{memberId:m.id,worldScale:4.1},notes,steps});};
 record('initial',{},()=>null);
 return {f,m,policy,configurePolicy,placeMember,record,tick,command,order,settle,add,effects,finish,steps};
}

for(const order of ['follow','rally']){
 const s=await setup(order+'_cancels_work_and_fifo','engineer');
 const panel=s.add({id:'panel',kind:'power_panel',powered:true,position:{x:41,y:0,z:41}}),fence=s.add({id:'fence',kind:'fence',position:{x:41,y:0,z:41}});
 check(s.command('disable_power',panel).ok,'start panel');s.tick();check(s.command('cut_fence',fence).queued,'queue fence');
 check(s.order(order).ok,'order accepted');check(!s.f.api.getAction(s.m.id)&&s.f.api.getQueue(s.m.id).length===0,'unfinished work and FIFO cleared');
 s.order(order);for(let i=0;i<60;i++)s.tick(.2);check(s.effects().length===0,'cancelled effects never called');
 s.record('cancelCommand',{memberId:s.m.id},()=>s.f.api.cancelCommand(s.m.id));
 s.finish('Repeated explicit order remains usable. Unfinished action and future queue cancel; no effect is submitted.');
}

for(const order of ['follow','rally']){
 const s=await setup(order+'_defers_armed_bomb','demolitions'),origin=clean(s.f.api.getMember(s.m.id).position);
 const car=s.add({id:'car',kind:'vehicle',valid:true,position:origin,center:origin});
 check(s.command('plant_bomb',car).ok,'bomb begins');s.tick();s.tick(4);check(s.f.api.getAction(s.m.id)?.armed,'source armed');
 const result=s.order(order);check(result.ok,'deferred order accepted');if(order==='rally')check(result.deferred===1,'rally reports deferred');
 check(s.f.api.getAction(s.m.id)?.armed,'armed action retained');s.tick(6);check(s.effects().length===0,'timer alone cannot bypass retreat');
 check(s.f.api.getAction(s.m.id)?.waitingForSafety,'waits for actual operator clearance');
 for(let i=0;i<160&&s.effects().length===0;i++)s.tick(.05);
 check(s.effects().length===1,'one effect after source retreat');check(!s.f.api.getAction(s.m.id),'armed task completes');
 for(let i=0;i<10;i++)s.tick(.2);check(s.effects().length===1,'effect not repeated');
 s.finish('Armed task takes precedence over new order until safe retreat and one effect receipt. Supplied canMove=true is a fixture predicate, not native collision proof.');
}

for(const order of ['follow','rally']){
 const s=await setup(order+'_defers_pending_receipt','safecracker');s.configurePolicy({pending:true});
 const safe=s.add({id:'safe',kind:'safe',valid:true,locked:true,position:clean(s.f.api.getMember(s.m.id).position)});
 check(s.command('unlock_safe',safe).ok,'safe begins');s.tick();s.tick(8);check(s.f.api.getAction(s.m.id)?.phase==='awaiting','source awaiting');
 s.order(order);s.tick(5);check(s.effects().length===1&&s.f.api.getAction(s.m.id)?.phase==='awaiting','pending keeps one effect');
 await s.settle(safe.id);s.tick();check(s.effects().length===1&&!s.f.api.getAction(s.m.id),'resume after receipt');
 for(let i=0;i<8;i++)s.tick(.2);
 s.finish('Source follow returns ordinary success/message; rally additionally reports deferred count. Promise receipt resolves once and action then releases movement.');
}

async function startSafe(id){
 const s=await setup(id,'safecracker');s.configurePolicy({pending:true});s.placeMember(10,10);
 s.record('set_player_position',{c:43.5/4.1,r:42.3/4.1},()=>{s.f.ctx.player.c=43.5/4.1;s.f.ctx.player.r=42.3/4.1;});
 const safe=s.add({id:'safe:exit',kind:'safe',valid:true,locked:true,position:{x:41,y:0,z:41},workPoint:{x:41,y:.88,z:40.16},workNormal:{x:0,y:0,z:1},workRange:.08});
 check(s.command('unlock_safe',safe).ok,'safe-exit task starts');return {s,safe};
}

{
 const {s,safe}=await startSafe('safe_exit_blocks_fifo_then_resumes');
 const first=s.add({id:'door:first',kind:'door',valid:true,locked:true,lockpickable:true,position:{x:43,y:0,z:42}}),second=s.add({id:'door:second',kind:'door',valid:true,locked:true,lockpickable:true,position:{x:45,y:0,z:42}});
 check(s.command('unlock_door',first).queued,'first queued door');check(s.command('unlock_door',second).queued,'second queued door');
 for(let i=0;i<60&&!s.effects().length;i++)s.tick(.2);
 check(s.f.api.getAction(s.m.id)?.phase==='awaiting','safe pending');await s.settle(safe.id);
 check(!!s.m._mercenarySafeExit,'safe clearance scheduled');s.configurePolicy({pending:false});
 let observedGate=false;
 for(let i=0;i<150&&s.effects().length<3;i++){
  const beforeExit=!!s.m._mercenarySafeExit;s.tick(.2);
  if(beforeExit){check(!s.f.api.getAction(s.m.id),'queued work cannot start while safe exit existed at update start');observedGate=true;}
 }
 check(observedGate,'safe exit queue gate observed');check(JSON.stringify(s.effects().map(e=>e.event.targetId))===JSON.stringify([safe.id,first.id,second.id]),'source FIFO effect order');
 check(!s.m._mercenarySafeExit&&!s.f.api.getAction(s.m.id)&&s.f.api.getQueue(s.m.id).length===0,'exit and FIFO complete');
 for(let i=0;i<4;i++)s.tick(.2);
 s.finish('canStartQueued is false while raw _mercenarySafeExit exists. OnAction completed schedules clearance; source physical advancement clears it, then queued doors start FIFO with their normal cooldowns.');
}

for(const order of ['follow','rally']){
 const {s,safe}=await startSafe(order+'_replaces_safe_exit');
 for(let i=0;i<60&&!s.effects().length;i++)s.tick(.2);await s.settle(safe.id);check(!!s.m._mercenarySafeExit,'exit scheduled');
 s.order(order);check(!s.m._mercenarySafeExit,'explicit order clears safe exit immediately');s.tick(.2);check(s.m._mercenaryMove?.phase!=='safe_exit','new movement owns goal');
 s.finish('Explicit follow/rally calls clearFocus, which clears _mercenarySafeExit, unlike implicit continuation of queued specialist jobs.');
}

{
 const s=await setup('elapsed_pause_hidden_reset_backlog','engineer');s.placeMember(10,10);
 s.record('rally',{point:{x:47,y:0,z:41}},()=>s.f.api.rally({x:47,y:0,z:41}));
 s.record('api.tick',{dt:0},()=>s.f.api.tick(0));s.tick(.2);const moved=s.m.c;check(Math.abs((moved-10)*4.1-.6)<1e-6,'ordinary 200ms advances0.6m');
 s.tick(20);check(s.m.c===moved&&s.f.api.getMember(s.m.id).movement.clock.paused,'20s pause discarded');s.tick(.2);
 s.record('document.hidden',{value:true},()=>s.f.ctx.document.hidden=true);const hidden=s.m.c;s.tick(.2);check(s.m.c===hidden,'hidden freezes movement');
 s.record('document.hidden',{value:false},()=>s.f.ctx.document.hidden=false);s.record('resetMovementClock',{},()=>s.f.api.resetMovementClock());const reset=s.m.c;s.tick(.2);check((s.m.c-reset)*4.1<=.151,'reset first tick bounded .05');
 const beforeBacklog=s.m.c;s.tick(.6);const clock=s.f.api.getMember(s.m.id).movement.clock;check(clock.substeps===6&&clock.used===.3&&clock.dropped>.29,'six slices max and discard backlog');check((s.m.c-beforeBacklog)*4.1<=.901,'backlog bounded movement');
 const afterBacklog=s.m.c;s.tick(.05);check((s.m.c-afterBacklog)*4.1<=.151,'discarded time not replayed');
 s.finish('Exact fixture.tick increments Date/performance clock by requested dt while passing .05 to api.tick. MovementElapsed uses clock; no dt-wrapper substitution.');
}

const sourceFiles=['mercenary_world.js','mercenary_core.mjs','mercenary_route.mjs','mercenary_long_follow.mjs','mercenary_catchup.mjs','test_mercenary_rally_actions.mjs','test_mercenary_elapsed.mjs','test_mercenary_safe_exit18.mjs','test_mercenary_queue18.mjs'].map(name=>({name,sha256:sha(fs.readFileSync(path.join(source,name)))}));
const result={schema:'walk.movement.world_commands_source.v1',status:'PASS_SOURCE_ONLY',native_status:'NOT_RUN',engine_jobs:0,case_count:cases.length,step_count:cases.reduce((n,c)=>n+c.steps.length,0),assertions,node:process.version,source_files:sourceFiles,oracle_sha256:sha(fs.readFileSync(new URL(import.meta.url))),fixture_extraction:{source:'test_mercenary_rally_actions.mjs',lines:[7,12],sha256:sha(fixtureBody),world_substitution:{exact:importExpression,replacement:'Promise.resolve(module)',reason:'Existing source test harness injects the real imported core into VM; all world behavior otherwise unchanged.'}},contract:{time:'fixture Date/performance milliseconds, core durations seconds; fixture.tick(dt) advances clock by dt and invokes api.tick(.05)',callbacks:'get(id), canMove(from,to,memberId), groundHeight(x,z), performEffect(event)->{ok:true} or deferred Promise resolving {ok}; exact effect payload and canMove ordering saved per step',observations:'Public member.position/movement/posture, roster.order/status, getAction/getQueue; additionally raw _mercenarySafeExit/_mercenaryRally/_mercenaryMove/_followSpeed explicitly diagnostic',scope:'VM source host command/movement policy with permissive collision fixtures. Not native physics, Godot, browser, real scene/effects, or THREE proof.',numeric_tolerance:1e-8},source_lines:{world:{elapsed:[36,40],safe_exit_creation:[289,311],cancel:[395,398],rally:[400,418],follow:[420,420],safe_exit_gate:[779,779],core_queue_binding:[794,794]}},cases};
fs.mkdirSync(path.dirname(output),{recursive:true});const json=JSON.stringify(result,null,2)+'\n';fs.writeFileSync(output,json);
console.log(JSON.stringify({status:result.status,cases:result.case_count,steps:result.step_count,assertions,sha256:sha(json),oracle_sha256:result.oracle_sha256}));
