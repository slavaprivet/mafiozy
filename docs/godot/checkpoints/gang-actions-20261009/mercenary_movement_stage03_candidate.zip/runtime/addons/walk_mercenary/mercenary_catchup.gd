extends RefCounted
## Source: assets/maps/city_rebuild_v1/mercenary_catchup.mjs.
## Milliseconds and native metres. Produces relocation proposals, never moves bodies.
## BUILD owns every geometry callback and must commit/revalidate proposals itself.

const OFFSETS: Array = [[0, 0], [-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
const RADII: Array = [3.6, 5.0, 6.4, 8.0]

class SafePlacement extends RefCounted:
	var radius: float
	var height: float = 1.9
	var _options: Dictionary

	func _init(options: Dictionary = {}) -> void:
		_options = options.duplicate()
		radius = 0.18 * float(options.get("worldScale", 4.1))

	func check(point: Variant, member: Variant) -> Dictionary:
		if not _finite_point(point) or not _callback("ready").is_valid():
			return {"ok": false, "reason": "resolver_unavailable"}
		if not _strict_bool(_callback("ready").call(), true):
			return {"ok": false, "reason": "resolver_unavailable"}
		for key: String in ["queryPoint", "bodyClear", "groundHeight", "isInsideBuilding", "blocksVehicle"]:
			if not _callback(key).is_valid():
				return {"ok": false, "reason": "resolver_unavailable"}
		if not _strict_bool(_callback("bodyClear").call(point, member), true):
			return {"ok": false, "reason": "body_blocked"}
		var low: float = INF
		var high: float = -INF
		var ground: float = 0.0
		for offset: Array in OFFSETS:
			var x: float = float(point.x) + float(offset[0]) * radius
			var z: float = float(point.z) + float(offset[1]) * radius
			var y: Variant = _callback("groundHeight").call(x, z)
			var query: Variant = _callback("queryPoint").call({"x": x, "z": z})
			if not _finite_number(y) or not query is Dictionary or not _strict_bool(query.get("blocked"), false) or not _finite_number(query.get("depth")):
				return {"ok": false, "reason": "unsupported_or_solid"}
			if float(query.depth) > 0.025:
				return {"ok": false, "reason": "water"}
			if not _strict_bool(_callback("isInsideBuilding").call({"x": x, "y": float(y) + 0.9, "z": z}), false):
				return {"ok": false, "reason": "building"}
			if offset[0] == 0 and offset[1] == 0:
				ground = float(y)
			low = minf(low, float(y))
			high = maxf(high, float(y))
		if high - low > 0.28:
			return {"ok": false, "reason": "uneven_ground"}
		if not _strict_bool(_callback("blocksVehicle").call({"x": point.x, "y": ground, "z": point.z}, {"radius": radius * sqrt(2.0), "height": height}), false):
			return {"ok": false, "reason": "vehicle"}
		return {"ok": true, "point": {"x": point.x, "y": ground, "z": point.z}}

	func _callback(key: String) -> Callable:
		var value: Variant = _options.get(key)
		return value if value is Callable else Callable()

	static func _strict_bool(value: Variant, expected: bool) -> bool:
		return value is bool and value == expected

	static func _finite_number(value: Variant) -> bool:
		return (value is float or value is int) and is_finite(float(value))

	static func _finite_point(value: Variant) -> bool:
		return value is Dictionary and _finite_number(value.get("x")) and _finite_number(value.get("z"))

var stats: Dictionary = {"checks": 0, "refused": 0, "placed": 0, "waiting": 0, "maxChecksPerUpdate": 0}
var _states: Dictionary = {}
var _cursor: int = 0
var _last_update: Variant = null
var _placement: Variant
var _far_distance: float
var _far_delay_ms: float
var _no_progress_ms: float
var _cooldown_ms: float
var _max_checks_per_update: float
var _defer_relocation_commit: bool = false
var _pending_relocations: Dictionary = {}

func _init(options: Dictionary = {}) -> void:
	_placement = options.get("placement")
	_far_distance = float(options.get("farDistance", 65))
	_far_delay_ms = float(options.get("farDelayMs", 6000))
	_no_progress_ms = float(options.get("noProgressMs", 10000))
	_cooldown_ms = float(options.get("cooldownMs", 20000))
	_max_checks_per_update = float(options.get("maxChecksPerUpdate", 4))
	_defer_relocation_commit = SafePlacement._strict_bool(options.get("deferRelocationCommit", false), true)

static func create_safe_placement(options: Dictionary = {}) -> SafePlacement:
	return SafePlacement.new(options)

static func eligible(row: Variant) -> bool:
	if not row is Dictionary or not SafePlacement._strict_bool(row.get("owned"), true):
		return false
	if row.get("status") != "active" or not (_number(row.get("hp")) > 0.0) or _truthy(row.get("dead")):
		return false
	var order: Variant = row.get("order")
	if (order if _truthy(order) else "follow") != "follow":
		return false
	for key: String in ["action", "queued", "combat", "carried", "carrying", "seated", "vehicleChase", "interior", "safeExit", "conversation"]:
		if _truthy(row.get(key)):
			return false
	return SafePlacement._finite_point(row.get("position"))

static func advance_safe_drop(state: Variant, options: Dictionary = {}) -> Dictionary:
	var origin: Variant = options.get("origin")
	var now: Variant = options.get("now")
	var validate: Variant = options.get("validate")
	if not state is Dictionary or not SafePlacement._finite_point(origin) or not SafePlacement._finite_number(now) or not validate is Callable or not validate.is_valid():
		return _empty("unavailable")
	var member_id: Variant = options.get("memberId")
	var yaw: float = float(options.get("yaw", 0))
	if not _truthy(state.get("origin")) or state.get("memberId") != member_id or _distance(state.origin, origin) > 2.0 or state.get("status") == "ready":
		state.merge({"origin": origin.duplicate(), "yaw": yaw, "memberId": member_id, "slot": options.get("slot", 0), "attempt": 0, "pending": null, "retryAt": 0, "status": "pending"}, true)
	if state.get("status") == "blocked":
		if float(now) < float(state.retryAt):
			return _empty("blocked")
		state.merge({"origin": origin.duplicate(), "yaw": yaw, "attempt": 0, "pending": null, "status": "pending"}, true)
	var checks: int = 0
	var refused: int = 0
	var limit: float = minf(4.0, maxf(0.0, float(options.get("maxChecks", 4))))
	var occupied: Array = options.get("occupied", [])
	while checks < limit and int(state.attempt) < 32:
		var pending: Variant = state.get("pending")
		if _truthy(pending) and float(now) - float(pending.at) < 60.0:
			break
		var point: Dictionary
		if _truthy(pending):
			point = pending.point
		else:
			var ring: int = int(floor(float(state.attempt) / 8.0))
			var turn: float = fmod(float(int(state.attempt) % 8) + float(state.slot) * 2.0, 8.0)
			var angle: float = float(state.yaw) + PI + turn * PI / 4.0 + float(ring % 2) * PI / 8.0
			var radius: float = RADII[ring]
			point = {"x": float(state.origin.x) + cos(angle) * radius, "z": float(state.origin.z) + sin(angle) * radius}
		var distance: float = _distance(point, origin)
		var collision: bool = false
		for other: Variant in occupied:
			if other is Dictionary and other.get("id") != member_id and SafePlacement._finite_point(other) and _distance(other, point) < 1.6:
				collision = true
				break
		if distance < 2.5 or distance > 10.0 or collision:
			state.attempt = int(state.attempt) + 1
			state.pending = null
			continue
		checks += 1
		var result: Variant = validate.call(point, member_id)
		if not result is Dictionary or not _truthy(result.get("ok")) or not SafePlacement._finite_point(result.get("point")) or not SafePlacement._finite_number(result.point.get("y")):
			refused += 1
			state.attempt = int(state.attempt) + 1
			state.pending = null
			continue
		if not _truthy(pending):
			state.pending = {"point": result.point, "at": now}
			break
		if absf(float(result.point.y) - float(pending.point.y)) > 0.08:
			refused += 1
			state.attempt = int(state.attempt) + 1
			state.pending = null
			continue
		state.status = "ready"
		state.point = result.point.duplicate()
		return {"status": "ready", "point": state.point, "checks": checks, "refused": refused}
	if int(state.attempt) >= 32:
		state.status = "blocked"
		state.retryAt = float(now) + 2000.0
		state.pending = null
	return _empty(str(state.status), checks, refused)

func clear() -> void:
	_states.clear()
	_pending_relocations.clear()
	_cursor = 0
	_last_update = null
	# Source deliberately retains cumulative stats.

func update(data: Dictionary = {}) -> Dictionary:
	var now: Variant = data.get("now")
	if not SafePlacement._finite_number(now):
		return {"relocations": [], "checks": 0}
	var members: Array = data.get("members", [])
	var roster: Array = []
	var ids: Dictionary = {}
	for member: Variant in members:
		if member is Dictionary and member.get("id") != null:
			roster.append(member)
			ids[member.id] = true
	roster.sort_custom(_id_before)
	for id: Variant in _states.keys():
		if not ids.has(id):
			_states.erase(id)
			_pending_relocations.erase(id)
	var interrupted: bool = _last_update != null and (float(now) < float(_last_update) or float(now) - float(_last_update) > 1000.0)
	_last_update = now
	# BUILD synchronously resolves one proposal. Until then no further proposal or
	# observed-progress reset may obscure the physical owner's outstanding result.
	if _defer_relocation_commit and not _pending_relocations.is_empty():
		return {"relocations": [], "checks": 0}
	var hero: Variant = data.get("hero")
	var checker: Callable = _placement_checker()
	var can_run: bool = SafePlacement._strict_bool(data.get("enabled", true), true) and hero is Dictionary and not SafePlacement._strict_bool(hero.get("alive"), false) and not _truthy(hero.get("interior")) and not _truthy(hero.get("inVehicle")) and SafePlacement._finite_point(hero.get("position")) and checker.is_valid()
	var relocations: Array = []
	var limit: float = minf(4.0, minf(maxf(0.0, _max_checks_per_update), maxf(0.0, float(data.get("maxChecks", 4)))))
	var checks: int = 0
	var occupied: Array = []
	for member: Dictionary in roster:
		if member.get("status") != "hospital" and not _truthy(member.get("seated")) and SafePlacement._finite_point(member.get("position")):
			occupied.append({"id": member.id, "x": member.position.x, "z": member.position.z})
	for offset: int in range(roster.size()):
		var index: int = (_cursor + offset) % roster.size()
		var member: Dictionary = roster[index]
		var state: Dictionary
		if not _states.has(member.id):
			state = {"cooldownUntil": 0, "lastReason": "observing"}
			_reset(state, member, float(now))
			_states[member.id] = state
		else:
			state = _states[member.id]
		if not can_run or interrupted or not eligible(member):
			_reset(state, member, float(now))
			state.lastReason = "ineligible"
			continue
		var distance: float = _distance(member.position, hero.position)
		if _distance(member.position, state.progressPoint) >= 1.25:
			state.progressPoint = member.position.duplicate()
			state.progressAt = now
		if distance > _far_distance:
			if state.farAt == null:
				state.farAt = now
		else:
			state.farAt = null
		if distance <= 12.0:
			state.progressAt = now
			state.search = null
			state.lastReason = "near_leader"
			continue
		if float(now) < float(state.cooldownUntil):
			state.lastReason = "cooldown"
			continue
		var far: bool = state.farAt != null and float(now) - float(state.farAt) >= _far_delay_ms
		var stuck: bool = float(now) - float(state.progressAt) >= _no_progress_ms
		if not far and not stuck:
			state.lastReason = "observing"
			continue
		if not _truthy(state.search):
			state.search = {}
		var previous_status: Variant = state.search.get("status")
		var angle: float = _number(hero.get("angle"))
		if not _truthy(angle):
			angle = 0.0
		var validate: Callable = func(point: Dictionary, _member_id: Variant) -> Variant: return checker.call(point, member)
		var result: Dictionary = advance_safe_drop(state.search, {"origin": hero.position, "yaw": angle, "memberId": member.id, "slot": index, "occupied": occupied, "validate": validate, "now": now, "maxChecks": limit - checks})
		checks += int(result.checks)
		stats.checks = int(stats.checks) + int(result.checks)
		stats.refused = int(stats.refused) + int(result.refused)
		state.lastReason = "no_safe_point" if result.status == "blocked" else "confirm_ground"
		if result.status == "blocked" and previous_status != "blocked":
			stats.waiting = int(stats.waiting) + 1
		if _truthy(result.point):
			relocations.append({"id": member.id, "point": result.point, "reason": "far" if far else "stuck"})
			if _defer_relocation_commit:
				_pending_relocations[member.id] = {"point": result.point.duplicate(), "at": now}
				state.lastReason = "pending_commit"
			else:
				stats.placed = int(stats.placed) + 1
				state.cooldownUntil = float(now) + _cooldown_ms
				_reset(state, {"position": result.point}, float(now))
				state.lastReason = "placed"
		if not relocations.is_empty() or checks >= limit:
			break
	if not roster.is_empty():
		_cursor = (_cursor + 1) % roster.size()
	stats.maxChecksPerUpdate = maxi(int(stats.maxChecksPerUpdate), checks)
	return {"relocations": relocations, "checks": checks}

## Optional native-owner acknowledgement; default source mode never needs this.
## A failed acknowledgement leaves the proposal pending for explicit rejection.
func commit_relocation(id: Variant, actual_point: Variant, now_ms: float) -> bool:
	if not _defer_relocation_commit or not _pending_relocations.has(id) or not _states.has(id):
		return false
	if not is_finite(now_ms) or not SafePlacement._finite_point(actual_point) or not SafePlacement._finite_number(actual_point.get("y")):
		return false
	var proposal: Dictionary = _pending_relocations[id]
	if now_ms < float(proposal.at):
		return false
	for axis: String in ["x", "y", "z"]:
		var expected_coordinate: float = float(proposal.point[axis])
		# Match parent: 1 mm or conservative two-ULP float32 allowance.
		# BUILD still owns live geometry revalidation.
		var tolerance: float = maxf(0.001, absf(expected_coordinate) * pow(2.0, -22.0))
		if not is_finite(expected_coordinate) or absf(float(actual_point[axis]) - expected_coordinate) > tolerance:
			return false
	var state: Dictionary = _states[id]
	_pending_relocations.erase(id)
	stats.placed = int(stats.placed) + 1
	state.cooldownUntil = now_ms + _cooldown_ms
	_reset(state, {"position": actual_point}, now_ms)
	state.lastReason = "placed"
	return true

## Retry the resolver after two seconds; rejection is not a successful recovery.
func reject_relocation(id: Variant, now_ms: float) -> void:
	if not _defer_relocation_commit or not _pending_relocations.has(id) or not is_finite(now_ms):
		return
	_pending_relocations.erase(id)
	if not _states.has(id):
		return
	var state: Dictionary = _states[id]
	var search: Dictionary = state.search if state.search is Dictionary else {}
	search.status = "blocked"
	search.retryAt = now_ms + 2000.0
	search.pending = null
	state.search = search
	state.lastReason = "owner_rejected"
	# Keep progressPoint/progressAt/farAt/cooldownUntil from observed real motion.

func inspect(id: Variant) -> Variant:
	if not _states.has(id):
		return null
	var state: Dictionary = _states[id]
	var search: Dictionary = state.search if state.search is Dictionary else {}
	return {"reason": state.lastReason, "attempt": search.get("attempt", 0), "pending": _truthy(search.get("pending")), "cooldownUntil": state.cooldownUntil, "nextTry": search.get("retryAt", 0)}

func get_stats() -> Dictionary:
	return stats.duplicate()

func _placement_checker() -> Callable:
	if _placement is Object and is_instance_valid(_placement) and _placement.has_method("check"):
		return Callable(_placement, "check")
	if _placement is Dictionary and _placement.get("check") is Callable:
		return _placement.check
	return Callable()

static func _reset(state: Dictionary, member: Dictionary, now: float) -> void:
	state.progressAt = now
	var position: Variant = member.get("position")
	state.progressPoint = position.duplicate() if position is Dictionary else {}
	state.farAt = null
	state.search = null
	state.nextTry = now

static func _empty(status: String, checks: int = 0, refused: int = 0) -> Dictionary:
	return {"status": status, "point": null, "checks": checks, "refused": refused}

static func _distance(a: Dictionary, b: Dictionary) -> float:
	# Scalar floats preserve source thresholds; Vector2 rounds to float32.
	# World distances are bounded metres; this is not Math.hypot's overflow-
	# resistant algorithm for arbitrarily large finite coordinates.
	var dx: float = float(a.get("x", NAN)) - float(b.get("x", NAN))
	var dz: float = float(a.get("z", NAN)) - float(b.get("z", NAN))
	return sqrt(dx * dx + dz * dz)

static func _truthy(value: Variant) -> bool:
	if value == null: return false
	if value is bool: return value
	if value is int or value is float: return float(value) != 0.0 and not is_nan(float(value))
	if value is String: return not value.is_empty()
	return true # JS arrays and objects, including empty ones, are truthy.

static func _number(value: Variant) -> float:
	if value == null: return 0.0
	if value is bool: return 1.0 if value else 0.0
	if value is int or value is float: return float(value)
	if value is String:
		var clean: String = value.strip_edges()
		if clean.is_empty(): return 0.0
		if clean.is_valid_float(): return clean.to_float()
	return NAN

static func _id_before(a: Dictionary, b: Dictionary) -> bool:
	# Canonical source IDs are ASCII. JS default ICU locale collation for arbitrary
	# user-supplied Unicode IDs is not provided by Godot; do not rename identities.
	var left: String = str(a.id)
	var right: String = str(b.id)
	var comparison: int = left.nocasecmp_to(right)
	if comparison != 0: return comparison < 0
	return left > right # ICU's default lower-case-first tie for canonical Latin IDs.
