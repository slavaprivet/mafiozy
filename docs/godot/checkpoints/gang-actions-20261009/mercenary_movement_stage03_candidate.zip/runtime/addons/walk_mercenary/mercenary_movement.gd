extends RefCounted
## mercenary_world.js policy in native metres; body movement belongs to BUILD.
## Every position is reread from the authoritative owner; no row.position/r/c writes.

const Route = preload("mercenary_route.gd")
const Catchup = preload("mercenary_catchup.gd")
const FORMATION = [[-2.5, -1.3], [-2.5, 1.3], [-4.8, -2.2], [-4.8, 0.0], [-4.8, 2.2]]
const FORMATION_TURNS = [PI/4, -PI/4, PI/2, -PI/2, 3*PI/4, -3*PI/4, PI]

var _core: RefCounted
var _host: RefCounted
var _options: Dictionary
var _disposed: bool = false
var _clock_at: Variant = null
var _follow_angle: Variant = null
var _route_deadline: float = 0.0
var _frame_offset: int = 0
var _last_save: float = 0.0
var _statuses: Dictionary = {}
var _placement: RefCounted
var _catchup: RefCounted
var _clock_report: Dictionary = {"elapsed":0.0,"used":0.0,"dropped":0.0,"paused":false}
var _catchup_report: Dictionary = {}
var _drop_crowd: Variant = null

func _init(core: RefCounted, host: RefCounted, options: Dictionary = {}) -> void:
	_core = core
	_host = host
	_options = options.duplicate()
	_placement = Catchup.create_safe_placement({
		"ready": _callback("placement_ready"), "queryPoint": _callback("placement_query_point"),
		"bodyClear": _callback("placement_body_clear"), "groundHeight": _callback("ground_height"),
		"isInsideBuilding": _callback("placement_inside_building"),
		"blocksVehicle": _callback("placement_blocks_vehicle"), "worldScale": 4.1})
	_catchup = Catchup.new({"placement": {"check": _check_placement},"deferRelocationCommit":true})

func _callback(key: String) -> Callable:
	var value: Variant = _options.get(key)
	return value if value is Callable else Callable()

func _call(key: String, args: Array = [], fallback: Variant = null) -> Variant:
	var callback: Callable = _callback(key)
	return callback.callv(args) if callback.is_valid() else fallback

func _ready() -> bool:
	return not _disposed and _core != null and _host != null and _call("is_ready", [], false) == true and _call("is_local", [], false) == true

func _now() -> float:
	return float(_call("now", [], Time.get_ticks_msec()/1000.0))

func _performance_ms() -> float:
	return float(_call("performance_now_ms", [], Time.get_ticks_usec()/1000.0))

func _row(id: String) -> Dictionary:
	return _host.member_row(_member_key(id)) if not _disposed and _host != null else {}

static func _member_key(id: String) -> String:
	var key: String = id.trim_prefix("npc:")
	if key.begins_with("npc_crew_"): return key.substr(9)
	if key.begins_with("crew_"): return key.substr(5)
	return key

func _position(id: String) -> Variant:
	var point: Variant = _call("get_member_position", [_member_key(id)])
	return point.duplicate() if _finite_point(point) and _finite_number(point.get("y")) else null

func _hero() -> Dictionary:
	var value: Variant = _call("get_player_state")
	return value if value is Dictionary else {}

static func _finite_number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

static func _finite_point(value: Variant) -> bool:
	return value is Dictionary and _finite_number(value.get("x")) and _finite_number(value.get("z"))

static func _distance(a: Dictionary, b: Dictionary) -> float:
	var dx: float = float(a.x)-float(b.x)
	var dz: float = float(a.z)-float(b.z)
	return sqrt(dx*dx+dz*dz)

static func _same_native_point(actual: Dictionary, expected: Dictionary) -> bool:
	# Body transforms are float32. Accept <=1mm or two coordinate ULPs, not
	# double equality; the physical owner still revalidates live support/collision.
	for axis: String in ["x","y","z"]:
		if not _finite_number(actual.get(axis)) or not _finite_number(expected.get(axis)): return false
		var tolerance: float = maxf(0.001,absf(float(expected[axis]))*pow(2.0,-22))
		if absf(float(actual[axis])-float(expected[axis]))>tolerance: return false
	return true

static func _truth(value: Variant) -> bool:
	if value == null: return false
	if value is bool: return value
	if value is int or value is float: return value != 0 and not is_nan(float(value))
	if value is String: return not value.is_empty()
	return true # JS objects and empty arrays are truthy.

func _ground(x: float, z: float) -> Variant:
	var value: Variant = _call("ground_height", [x,z])
	return float(value) if _finite_number(value) else null

func _persist() -> void:
	_call("persist")
	_last_save = _now()

func _clear_focus(id: String) -> void:
	var member: Dictionary = _row(id)
	for field: String in ["_mercenarySafeExit","_mercenaryConversation","_mercenaryGreetingUntil"]: member.erase(field)
	_call("clear_focus", [id])

func _failure(message: String) -> Dictionary:
	return {"ok": false, "message": message}

func follow() -> Dictionary:
	if not _ready(): return _failure("Приказ недоступен.")
	var completing: int = 0
	for record: Dictionary in _core.get_roster():
		var id: String = str(record.id)
		var member: Dictionary = _row(id)
		if member.is_empty(): continue
		_clear_focus(id)
		_core.clear_queue(id)
		var action: Variant = _core.get_action(id)
		if action is Dictionary:
			if _truth(action.get("armed")) or action.get("phase") == "awaiting": completing += 1
			else: _core.cancel(id)
		_clear_staged(member)
		member._mercenaryOrder = "follow"
		member._mercenaryRally = null
		member._mercenaryFollowAt = 0.0
	_persist()
	return {"ok": true, "message": "Отряд следует за вами. Занятые бойцы завершат безопасный отход или подтверждение действия." if completing > 0 else "Отряд следует за вами."}

func rally(point: Dictionary) -> Dictionary:
	var hero: Dictionary = _hero()
	if not _ready() or not _finite_point(point) or not _finite_point(hero.get("position")) or not _callback("native_can_move").is_valid():
		return _failure("Место сбора недоступно.")
	if _distance(point,hero.position) > 80.0: return _failure("Выберите место ближе 80 м.")
	var positions: Array = []
	var blocked: Array = []
	var count: int = 0
	var cancelled: int = 0
	var deferred: int = 0
	for record: Dictionary in _core.get_roster():
		var id: String = str(record.id)
		var member: Dictionary = _row(id)
		if member.is_empty() or float(member.get("hp",0)) <= 0 or _truth(member.get("_mercenaryHospital")):
			blocked.append(id)
			continue
		var chosen: Variant = null
		for radius: float in [0.0,2.4,4.8,7.2]:
			for index: int in range(16 if radius > 0 else 1):
				var x: float = float(point.x)+cos(index*PI/8)*radius
				var z: float = float(point.z)+sin(index*PI/8)*radius
				var candidate: Dictionary = {"x":x,"z":z}
				var occupied: bool = false
				for used: Dictionary in positions:
					if _distance(used,candidate) < 2.1: occupied = true; break
				if occupied: continue
				var y: Variant = _ground(x,z)
				if y == null: continue # Actual floor owner is mandatory in native integration.
				candidate.y = y
				if _call("body_passable",[candidate,id],false) != true: continue
				if _call("native_can_move",[candidate,candidate,id],false) != true: continue
				chosen = candidate
				break
			if chosen != null: break
		if chosen == null:
			blocked.append(id)
			continue
		_core.clear_queue(id)
		var action: Variant = _core.get_action(id)
		if action is Dictionary:
			if _truth(action.get("armed")) or action.get("phase") == "awaiting": deferred += 1
			elif _core.cancel(id).get("ok") == true: cancelled += 1
		_clear_focus(id)
		_clear_staged(member)
		positions.append(chosen)
		member._mercenaryOrder = "rally"
		member._mercenaryRally = chosen
		member._mercenaryReturnMove = false
		count += 1
	if count > 0: _persist()
	return {"ok":count>0,"count":count,"cancelled":cancelled,"deferred":deferred,"blocked":blocked,"positions":positions,
		"message":("Отряд идёт к месту сбора. Занятые бойцы присоединятся после безопасного отхода или подтверждения действия." if deferred>0 else "Отряд идёт к месту сбора.") if count>0 else "Рядом нет свободных мест."}

func cancel_command(id: String = "") -> Dictionary:
	if not _ready(): return _failure("Приказ недоступен.")
	var cancelled: int = 0
	var blocked: Array = []
	for record: Dictionary in _core.get_roster():
		var key: String = str(record.id)
		if not id.is_empty() and key != _member_key(id): continue
		if _core.get_action(key) == null and _core.get_queue(key).is_empty() and not _truth(record.get("resumeWork")): continue
		var receipt: Dictionary = _core.cancel(key)
		if receipt.get("ok") == true or _truth(receipt.get("queuedCleared")): cancelled += 1
		else: blocked.append({"memberId":key,"reason":receipt.get("reason")})
	if cancelled > 0: _persist()
	return {"ok":cancelled>0,"cancelled":cancelled,"blocked":blocked,"message":"Приказ отменён." if cancelled>0 else ("Заряд установлен или действие уже ожидает подтверждения." if not blocked.is_empty() else "Активного приказа нет.")}

func _clear_staged(member: Dictionary) -> void:
	var route: Variant = member.get("_mercenaryPath")
	if route is Dictionary and route.get("stagedFollow") != null: member._mercenaryPath = null

func on_move_request(id: String, target: Variant, _request_options: Dictionary) -> void:
	# Host has already written the original _mercenaryMove metadata on this same row.
	if target == null:
		# Preserve source last-step diagnostics; the actual locomotion owner stops.
		_call("stop_body",[id,"idle"])

func on_action(id: String, action: Dictionary) -> void:
	var member: Dictionary = _row(id)
	if member.is_empty(): return
	if action.get("phase") in ["completed","cancelled"]:
		member._mercenaryLastAction = {"kind":action.get("kind"),"targetId":action.get("targetId"),"phase":action.get("phase"),"reason":action.get("reason"),"at":_now()}
		member._mercenaryMoveReason = "idle"
		_queue_safe_exit(id,member,action)
		if action.get("reason") == "damaged":
			member._mercenaryOrder = "rally"
			member._mercenaryRally = _position(id)
	if action.get("phase") == "working":
		var point: Variant = action.get("workPoint")
		if not _finite_point(point):
			var target: Variant = _host.get_target(str(action.get("targetId","")))
			if target is Dictionary: point = target.get("center",target.get("position"))
		var from: Variant = _position(id)
		if _finite_point(point) and from != null:
			member.ang = atan2(float(point.z)-float(from.z),float(point.x)-float(from.x))
			_call("face_body",[id,member.ang,"stand"])

func _queue_safe_exit(id: String, member: Dictionary, action: Dictionary) -> void:
	if action.get("phase") != "completed" or action.get("kind") != "unlock_safe" or float(member.get("hp",0)) <= 0 or _truth(member.get("_mercenaryHospital")): return
	var target: Variant = _host.get_target(str(action.get("targetId","")))
	var previous: Variant = member.get("_mercenaryAction")
	var normal: Variant = target.get("workNormal") if target is Dictionary else null
	if normal == null and previous is Dictionary: normal = previous.get("workNormal")
	var from: Variant = _position(id)
	if not _finite_point(normal) or from == null: return
	var length: float = sqrt(float(normal.x)*float(normal.x)+float(normal.z)*float(normal.z))
	if length < 0.01: return
	var nx: float = float(normal.x)/length
	var nz: float = float(normal.z)/length
	for side: float in [0.0,0.55,-0.55]:
		var point: Dictionary = {"x":float(from.x)+nx*1.2-nz*side,"y":from.get("y",0),"z":float(from.z)+nz*1.2+nx*side}
		if not can_move_member(id,point,point): continue
		member._mercenarySafeExit = {"position":point,"stopDistance":0.08,"phase":"safe_exit","targetId":action.get("targetId"),"expires":_now()+12.0}
		member._mercenaryPath = null
		break

func can_start_queued(id: String) -> bool:
	return not _truth(_row(id).get("_mercenarySafeExit"))

func can_auto_revive(id: String) -> bool:
	var member: Dictionary = _row(id)
	return member.get("_mercenaryOrder") != "rally" and not _truth(member.get("_mercenaryFocus"))

func can_move_member(id: String, from: Dictionary, to: Dictionary) -> bool:
	id = _member_key(id)
	var member: Dictionary = _row(id)
	if not _ready() or member.is_empty() or float(member.get("hp",0))<=0 or _truth(member.get("dead")) or _truth(member.get("_mercenaryHospital")) or not _finite_point(from) or not _finite_point(to): return false
	# Source world clear(a,b) converts to r/c, then toWorld resolves floor Y.
	# A target/contact may be elevated; keep its metadata for core work range,
	# but geometry always tests the actor's feet on the actual ground owner.
	var from_y: Variant = _ground(float(from.x),float(from.z))
	var to_y: Variant = _ground(float(to.x),float(to.z))
	if from_y == null or to_y == null: return false
	var ground_from: Dictionary = {"x":from.x,"y":from_y,"z":from.z}
	var ground_to: Dictionary = {"x":to.x,"y":to_y,"z":to.z}
	return _call("source_path_passable",[ground_from,ground_to,id],false) == true and _call("native_can_move",[ground_from,ground_to,id],false) == true

func _posture(member: Dictionary) -> String:
	var action: Variant = member.get("_mercenaryAction")
	if float(member.get("hp",0)) <= 0 or _truth(member.get("_mercenaryHospital")) or (action is Dictionary and action.get("phase") in ["working","awaiting"]): return "stand"
	var stance: String = str(_hero().get("stance","stand"))
	return stance if stance in ["crouch","prone"] else "stand"

func get_member_motion(id: String) -> Dictionary:
	var member: Dictionary = _row(id)
	var route: Variant = member.get("_mercenaryPath")
	var from: Variant = _position(id)
	var hero: Variant = _hero().get("position")
	return {"posture":_posture(member),"approachMoving":route is Dictionary and _truth(route.get("path")) and float(member.get("_followSpeed",0))>0,
		"approachSearching":route is Dictionary and _truth(route.get("search")) and _now()-float(route.get("lastSearchProgressAt",0))<2,
		"followArrived":from!=null and _finite_point(hero) and _distance(from,hero)<7,
		"reason":member.get("_mercenaryMoveReason","idle"),"speed":member.get("_followSpeed",0),"substeps":member.get("_mercenaryMoveSubsteps",0)}

func reset_movement_clock() -> void:
	_clock_at = null

func _elapsed(dt: float) -> float:
	var stamp: float = _performance_ms()
	var first_dt: float = dt if is_finite(dt) else 0.0
	var elapsed: float = minf(0.05,maxf(0,first_dt)) if _clock_at == null else maxf(0,(stamp-float(_clock_at))/1000.0)
	_clock_at = stamp
	var paused: bool = _call("is_hidden",[],false) == true or not is_finite(elapsed) or elapsed>0.75
	var used: float = 0.0 if paused else minf(0.3,elapsed)
	_clock_report = {"elapsed":elapsed,"used":used,"dropped":maxf(0,elapsed-used),"paused":paused}
	return used

func _members() -> Array:
	var result: Array = []
	for record: Dictionary in _core.get_roster():
		var id: String = str(record.id)
		var row: Dictionary = _row(id)
		var position: Variant = _position(id)
		if not row.is_empty() and position != null: result.append({"id":id,"row":row,"position":position})
	return result

func _formation_point(origin: Dictionary, offset: Array, angle: float, factor: float) -> Variant:
	var x: float = float(origin.x)+(cos(angle)*float(offset[0])-sin(angle)*float(offset[1]))*factor
	var z: float = float(origin.z)+(sin(angle)*float(offset[0])+cos(angle)*float(offset[1]))*factor
	var y: Variant = _ground(x,z)
	return {"x":x,"y":y,"z":z} if y != null else null

func _formation_free(id: String, point: Variant, origin: Dictionary) -> bool:
	if not _finite_point(point) or _distance(point,origin)>7 or not can_move_member(id,origin,point): return false
	for other: Dictionary in _members():
		var row: Dictionary = other.row
		var goal: Variant = row.get("_mercenaryFollowGoal")
		if other.id != id and float(row.get("hp",0))>0 and not _truth(row.get("_mercenaryHospital")) and row.get("_mercenaryOrder") != "rally" and goal is Dictionary and _distance(point,goal.position)<1.4: return false
	return true

func _peaceful_goal(id: String, member: Dictionary, index: int) -> Variant:
	if member.get("_mercenaryOrder") == "rally" and _finite_point(member.get("_mercenaryRally")): return {"position":member._mercenaryRally,"stopDistance":0.35}
	if _now()<float(member.get("_mercenaryFollowAt",0)) and member.get("_mercenaryFollowGoal") is Dictionary: return member._mercenaryFollowGoal
	var origin: Variant = _hero().get("position")
	if not _finite_point(origin): return null
	var offset: Array = FORMATION[index%5]
	var angle: float = float(_follow_angle) if _follow_angle != null else float(_hero().get("angle",0))
	var point: Variant = _formation_point(origin,offset,angle,1)
	if not _formation_free(id,point,origin):
		var previous: Variant = member.get("_mercenaryFollowGoal")
		point = previous.position if previous is Dictionary and _formation_free(id,previous.position,origin) else null
		if point == null:
			for factor: float in [1.0,0.65]:
				for turn: float in FORMATION_TURNS:
					var candidate: Variant = _formation_point(origin,offset,angle+turn,factor)
					if _formation_free(id,candidate,origin): point = candidate; break
				if point != null: break
		if point == null: point = _position(id)
	if point == null: return null
	member._mercenaryFollowAt = _now()+0.4
	member._mercenaryFollowGoal = {"position":point,"stopDistance":0.6}
	return member._mercenaryFollowGoal

func _clear_segment(id: String, a: Dictionary, b: Dictionary) -> bool:
	if not can_move_member(id,a,b): return false
	var dx: float = float(b.x)-float(a.x)
	var dz: float = float(b.z)-float(a.z)
	var length2: float = dx*dx+dz*dz
	for other: Dictionary in _members():
		var row: Dictionary = other.row
		if other.id == id or float(row.get("hp",0))<=0 or _truth(row.get("_mercenaryHospital")): continue
		var x: float = float(other.position.x)-float(a.x)
		var z: float = float(other.position.z)-float(a.z)
		var projection: float = (x*dx+z*dz)/length2 if length2>0 else 0.0
		if sqrt(x*x+z*z)<1.1 and projection<=0: continue
		var t: float = clampf(projection,0,1)
		if sqrt(pow(x-dx*t,2)+pow(z-dz*t,2))<1.1: return false
	return true

func _approach_waypoint(id: String, member: Dictionary, from: Dictionary, goal: Dictionary) -> Variant:
	var route: Variant = member.get("_mercenaryPath")
	var purpose: String = str(goal.get("phase",member.get("_mercenaryOrder","follow")))+":"+str(goal.get("targetId",""))
	var following: bool = not _truth(goal.get("phase")) and member.get("_mercenaryOrder") != "rally"
	var tracking: bool = following or goal.get("tracksMovingTarget") == true
	var threshold: float = 0.35 if _truth(goal.get("phase")) else 0.8
	var drift: float = _distance(route.goal,goal.position) if route is Dictionary else 0.0
	var staged: bool = route is Dictionary and route.get("stagedFollow") != null
	if route is Dictionary and (route.purpose != purpose or staged and (not following or _truth(member.get("_mercenaryVehicleChase"))) or not staged and drift>threshold and (not tracking or _truth(route.get("direct")) or drift>12 or _truth(route.get("search")) and _now()-float(route.createdAt)>6 or _truth(route.get("path")) and _distance(from,route.goal)<=float(goal.stopDistance)+0.1)):
		route = null
		member._mercenaryPath = null
	var clear: Callable = func(a: Dictionary,b: Dictionary) -> bool: return _clear_segment(id,a,b)
	var budget: float = minf(0.75,_route_deadline-_performance_ms())
	if following and not _truth(member.get("_mercenaryVehicleChase")) and (staged and route != null or _distance(from,goal.position)>32):
		if route == null or route.get("stagedFollow") == null:
			route = {"purpose":purpose,"goal":goal.position.duplicate(),"blockedAt":0.0,"stagedFollow":Route.create_long_follow({"canMove":clear,"groundHeight":_ground,"clock":_performance_ms})}
			member._mercenaryPath = route
		var result: Dictionary = route.stagedFollow.advance(from,goal.position,{"arrivalRadius":goal.stopDistance,"maxExpanded":8,"budgetMs":budget})
		route.goal = goal.position.duplicate()
		route.stats = route.stagedFollow.stats
		if result.status == "arrived": member._mercenaryPath = null; return _routed(goal,false)
		if _finite_point(result.get("waypoint")): return {"position":result.waypoint,"stopDistance":result.stopDistance,"routed":true}
		member._mercenaryMoveReason = "no_route" if result.status == "blocked" else ("search_budget" if result.status == "budget" else "search_pending")
		return null
	if route == null:
		route = {"purpose":purpose,"createdAt":_now(),"goal":goal.position.duplicate(),"path":null,"index":0,"blockedAt":0.0,"direct":clear.call(from,goal.position),"search":null,"retryAt":0.0,"lastSearchProgressAt":_now()}
		member._mercenaryPath = route
		if not route.direct: route.search = Route.new({"canMove":clear,"groundHeight":_ground,"clock":_performance_ms}).start(from,goal.position,{"arrivalRadius":goal.stopDistance})
	if tracking and not route.direct and drift>threshold and _now()>=float(route.get("nextGoalCheckAt",0)):
		route.nextGoalCheckAt = _now()+0.5
		if clear.call(from,goal.position): route.goal = goal.position.duplicate(); route.direct = true; route.search = null; route.path = null
	if route.direct: return _routed(goal,true)
	if route.search != null:
		member._mercenaryMoveReason = "search_pending"
		budget = minf(0.75,_route_deadline-_performance_ms())
		if budget<=0: member._mercenaryMoveReason = "search_budget"; return null
		var before: int = int(route.search.stats.expanded)
		route.search.advance({"maxExpanded":8,"budgetMs":budget})
		if int(route.search.stats.expanded)>before: route.lastSearchProgressAt = _now()
		if not route.search.done: return null
		route.path = route.search.path
		route.stats = route.search.stats
		route.search = null
		route.retryAt = _now()+2
	if route.path == null or route.path.is_empty():
		member._mercenaryMoveReason = "no_route"
		if _now()>=float(route.retryAt): member._mercenaryPath = null
		return null
	while int(route.index)<route.path.size()-1 and _distance(from,route.path[int(route.index)])<0.09: route.index = int(route.index)+1
	if _now()>=float(route.get("nextShortcutAt",0)):
		route.nextShortcutAt = _now()+0.5
		var ahead: int = mini(route.path.size()-1,int(route.index)+6)
		if ahead>int(route.index) and clear.call(from,route.path[ahead]): route.index = ahead
	var exact: bool = int(route.index)==route.path.size()-1 and _distance(route.path[int(route.index)],route.goal)<0.000001
	return {"position":(route.goal if tracking else goal.position) if exact else route.path[int(route.index)],"stopDistance":goal.stopDistance if exact else 0.04,"routed":true}

func _routed(goal: Dictionary, routed: bool) -> Dictionary:
	var result: Dictionary = goal.duplicate()
	result.routed = routed
	return result

func _stop(id: String, member: Dictionary, reason: String) -> void:
	member._followSpeed = 0.0
	member.walkPhase = 0.0
	member._mercenaryMoveReason = reason
	_call("stop_body",[id,reason])

func _advance(id: String, member: Dictionary, elapsed: float) -> void:
	member._mercenaryMoveSubsteps = 0
	if elapsed<=0:
		member._followSpeed = 0.0
		_call("stop_body",[id,"paused"])
		return
	var remaining: float = elapsed
	for index: int in range(6):
		if remaining<=0.000001: break
		var seconds: float = minf(0.05,remaining)
		_move(id,member,seconds)
		member._mercenaryMoveSubsteps = int(member._mercenaryMoveSubsteps)+1
		remaining -= seconds
		if not _truth(member.get("_mercenaryMove")) or float(member.get("_followSpeed",0))<=0: break

func _move(id: String, member: Dictionary, seconds: float) -> void:
	if float(member.get("hp",0))<=0 or _truth(member.get("dead")) or _truth(member.get("_mercenaryHospital")):
		member._mercenaryPath = null
		member._mercenaryMove = null
		member._mercenaryReturnMove = false
		_stop(id,member,"hospital" if _truth(member.get("_mercenaryHospital")) else "downed")
		return
	var goal: Variant = member.get("_mercenaryMove")
	if not goal is Dictionary: return
	var from: Variant = _position(id)
	if from == null: _stop(id,member,"body_unavailable"); return
	var water: Variant = _call("advance_water_escape",[id,seconds])
	if water is Dictionary and water.get("owned") == true:
		member._mercenaryPath = null
		var after_water: Variant = _position(id)
		member._followSpeed = _distance(from,after_water)/seconds if after_water!=null and seconds>0 else 0.0
		member._mercenaryMoveReason = "water_egress" if float(member._followSpeed)>0 else "water_egress_pending"
		return
	if _truth(member.get("_waterEscaping")):
		_stop(id,member,"water_owner_unavailable")
		return
	from = _position(id)
	if from == null: _stop(id,member,"body_unavailable"); return
	goal = _approach_waypoint(id,member,from,goal)
	if goal == null: _stop(id,member,str(member.get("_mercenaryMoveReason","search_pending"))); return
	var dx: float = float(goal.position.x)-float(from.x)
	var dz: float = float(goal.position.z)-float(from.z)
	var distance: float = sqrt(dx*dx+dz*dz)
	var posture: String = _posture(member)
	var speed: float = 0.65 if posture=="prone" else (1.5 if posture=="crouch" else (5.5 if distance>8 else 3.0))
	if _truth(member.get("_mercenaryVehicleChase")): speed = 8.0 if distance>12 else 6.0
	var step: float = minf(maxf(0,distance-float(goal.stopDistance)),speed*minf(0.05,maxf(0,seconds)))
	if step<=0.000001: _stop(id,member,"arrived"); return
	var heading: float = atan2(dz,dx)
	var detouring: bool = _now()<float(member.get("_mercenaryDetourUntil",0))
	var turns: Array = [0.0] if goal.get("routed") == true else [0.0,0.65,-0.65,1.25,-1.25,1.8,-1.8,2.4,-2.4]
	if detouring and goal.get("routed") != true: turns.push_front(float(member.get("_mercenaryDetourTurn",0)))
	for turn: float in turns:
		var angle: float = heading+turn
		var point: Dictionary = {"x":float(from.x)+cos(angle)*step,"y":from.get("y",0),"z":float(from.z)+sin(angle)*step}
		var ground: Variant = _ground(float(point.x),float(point.z))
		if ground == null: member._mercenaryMoveReason = "ground_unavailable"; continue
		point.y = ground
		if _call("source_path_passable",[from,point,id],false) != true: member._mercenaryMoveReason = "source_blocked"; continue
		var occupied: bool = false
		for other: Dictionary in _members():
			if other.id != id and float(other.row.get("hp",0))>0 and not _truth(other.row.get("_mercenaryHospital")) and _distance(other.position,point)<1.1 and _distance(other.position,point)<=_distance(other.position,from): occupied = true; break
		if occupied: member._mercenaryMoveReason = "crew_blocked"; continue
		if _call("native_can_move",[from,point,id],false) != true: member._mercenaryMoveReason = "native_blocked"; continue
		var reason: String = "route_moving" if goal.get("routed") == true else "moving"
		var accepted: Variant = _call("apply_motion",[id,{"position":point,"displacement":{"x":float(point.x)-float(from.x),"y":0.0,"z":float(point.z)-float(from.z)},"seconds":seconds,"heading":angle,"speed":speed,"posture":posture,"reason":reason}],false)
		var after: Variant = _position(id)
		var travelled: float = _distance(from,after) if after!=null else 0.0
		# A rejected callback may have moved partially. Never attempt a second body step.
		if travelled>0.000001:
			if turn!=0 and not detouring: member._mercenaryDetourTurn = turn; member._mercenaryDetourUntil = _now()+0.5
			member.ang = angle
			member.walkPhase = float(member.get("walkPhase",0))+travelled*2.4
			member._followSpeed = speed if accepted == true and absf(travelled-step)<=0.000001 else travelled/seconds
			member._mercenaryMoveReason = reason if accepted == true else "owner_partial"
			_call("face_body",[id,angle,posture])
			var route: Variant = member.get("_mercenaryPath")
			if goal.get("routed") == true and route is Dictionary: route.blockedAt = 0.0
			return
		member._mercenaryMoveReason = "owner_no_motion" if accepted == true else "owner_rejected"
		break
	_stop(id,member,str(member.get("_mercenaryMoveReason","blocked")))
	if goal.get("routed") == true:
		var route: Variant = member.get("_mercenaryPath")
		if route is Dictionary:
			if not _truth(route.get("blockedAt")): route.blockedAt = _now()
			if _now()-float(route.blockedAt)>0.5:
				if route.get("stagedFollow") != null: route.stagedFollow.blocked(); route.blockedAt = 0.0
				else: member._mercenaryPath = null

func _face_player(id: String, member: Dictionary, elapsed: float) -> void:
	var hero: Variant = _hero().get("position")
	var from: Variant = _position(id)
	if from == null or not _finite_point(hero): return
	var desired: float = atan2(float(hero.z)-float(from.z),float(hero.x)-float(from.x))
	var angle: float = float(member.get("ang",0))
	var delta: float = atan2(sin(desired-angle),cos(desired-angle))
	member.ang = angle+clampf(delta,-elapsed*5,elapsed*5)
	member._mercenaryMove = null
	_stop(id,member,str(member.get("_mercenaryMoveReason","idle")))
	_call("face_body",[id,member.ang,_posture(member)])

func _check_placement(point: Dictionary, member: Dictionary) -> Dictionary:
	var id: String = str(member.get("id",""))
	var hero: Variant = _hero().get("position")
	if _finite_point(hero) and _distance(hero,point)<1.6: return {"ok":false,"reason":"occupied"}
	for other: Dictionary in _members():
		if other.id != id and not _truth(other.row.get("_mercenaryHospital")) and not _truth(other.row.get("_mercenaryVehicleSeat")) and _distance(other.position,point)<1.6: return {"ok":false,"reason":"occupied"}
	if _drop_crowd == null:
		var source: Variant = _call("get_crowd")
		if not source is Array: return {"ok":false,"reason":"resolver_unavailable"}
		if source.size()>1024: return {"ok":false,"reason":"occupied"}
		_drop_crowd = []
		for row: Dictionary in source:
			if _truth(row.get("dead")) or float(row.get("hp",100))<=0 or _truth(row.get("_civilianSeat")) or _truth(row.get("_inVehicle")) or _truth(row.get("_inCar")): continue
			var position: Variant = row.get("position")
			if _finite_point(position): _drop_crowd.append({"id":str(row.get("id","")),"position":position.duplicate()})
	for other: Dictionary in _drop_crowd:
		if other.id != id and _distance(other.position,point)<1.6: return {"ok":false,"reason":"occupied"}
	return _placement.check(point,member)

func _recover(roster: Array) -> void:
	var stamp: float = _performance_ms()
	var members: Array = []
	for record: Dictionary in roster:
		var id: String = str(record.id)
		var row: Dictionary = _row(id)
		var position: Variant = _position(id)
		if row.is_empty() or position==null: continue
		var state: Dictionary = {"id":id,"owned":true,"status":record.status,"hp":row.get("hp",0),"dead":_truth(row.get("dead")),"position":position,"order":row.get("_mercenaryOrder","follow"),"action":_core.get_action(id),"queued":not _core.get_queue(id).is_empty(),"vehicleChase":_truth(row.get("_mercenaryVehicleChase")),"safeExit":_truth(row.get("_mercenarySafeExit"))}
		var groups: Dictionary = {"combat":["_mercenaryDefending","_mercenaryFocus","targetKind","targetId","_fighting","_fightingMelee","_hostile"],"carried":["_carriedByAmbulance","_ambulanceInTransit","_ambulanceLoading","_evacuated","_carriedBy"],"carrying":["carrying","_carrying","_carriedNpc"],"seated":["_mercenaryVehicleSeat","_inVehicle","_inCar","vehicleId","vehicle_id","_civilianSeat"],"interior":["_residentIndoors","_insideBuilding","_interiorId","interior_id"],"conversation":["_mercenaryConversation","_playerConversationOpen"]}
		for key: String in groups:
			state[key] = false
			for field: String in groups[key]:
				if _truth(row.get(field)): state[key] = true; break
		state.combat = state.combat or float(row.get("_threatUntil",0))>stamp or float(row.get("_shotAt",0))>0 and stamp-float(row._shotAt)<500
		state.conversation = state.conversation or float(row.get("_mercenaryGreetingUntil",0))>_now()
		members.append(state)
	var hero: Dictionary = _hero()
	_catchup_report = _catchup.update({"now":stamp,"enabled":_ready() and _call("is_hidden",[],false)!=true,"hero":hero,"members":members,"maxChecks":4})
	_catchup_report.applied = []
	_catchup_report.rejected = []
	for relocation: Dictionary in _catchup_report.relocations:
		var id: String = str(relocation.id)
		var before: Variant = _position(id)
		var accepted: Variant = _call("relocate_body",[id,relocation.point,{"reason":relocation.reason,"at":stamp}],false)
		var after: Variant = _position(id)
		if accepted != true or before==null or after==null or not _same_native_point(after,relocation.point):
			_catchup.reject_relocation(id,stamp)
			_catchup_report.rejected.append(id)
			continue
		if not _catchup.commit_relocation(id,after,stamp):
			_catchup.reject_relocation(id,stamp)
			_catchup_report.rejected.append(id)
			continue
		var row: Dictionary = _row(id)
		row._mercenaryPath = null
		row._mercenaryMove = null
		row._mercenaryFollowGoal = null
		row._mercenaryFollowAt = 0.0
		row._mercenaryDetourUntil = 0.0
		row.walking = false
		row._waterEscaping = false
		row._waterEscapeTarget = null
		row._waterEscapeSearch = null
		row._waterEscapeRetryAt = 0.0
		row._mercenaryCatchup = {"at":stamp,"reason":relocation.reason,"fromR":float(before.z)/4.1,"fromC":float(before.x)/4.1,"r":float(after.z)/4.1,"c":float(after.x)/4.1}
		_stop(id,row,"catchup_"+str(relocation.reason))
		_catchup_report.applied.append(id)

func tick(dt: float) -> Dictionary:
	if not _ready(): reset_movement_clock(); return {"ready":false}
	_drop_crowd = null
	var elapsed: float = _elapsed(dt)
	var hero: Dictionary = _hero()
	var wanted: float = float(hero.get("angle",0))
	if _follow_angle == null: _follow_angle = wanted
	else:
		var delta: float = atan2(sin(wanted-float(_follow_angle)),cos(wanted-float(_follow_angle)))
		_follow_angle = float(_follow_angle)+clampf(delta,-1.45*minf(0.05,elapsed),1.45*minf(0.05,elapsed))
	for record: Dictionary in _core.get_roster():
		var row: Dictionary = _row(str(record.id))
		if row.is_empty(): continue
		if float(row.get("hp",0))<=0 and not _truth(row.get("_mercenaryDownAt")): row._mercenaryDownAt = _performance_ms()
		elif float(row.get("hp",0))>0: row._mercenaryDownAt = 0.0
	if _callback("update_core").is_valid(): _call("update_core")
	else: _core.update()
	var roster: Array = _core.get_roster()
	_recover(roster)
	_route_deadline = _performance_ms()+1.5
	_frame_offset = (_frame_offset+1)%maxi(1,roster.size())
	var lifecycle_changed: bool = false
	for offset: int in range(roster.size()):
		var index: int = (offset+_frame_offset)%roster.size()
		var record: Dictionary = roster[index]
		var id: String = str(record.id)
		if _statuses.get(id) != record.status: _statuses[id] = record.status; lifecycle_changed = true
		var row: Dictionary = _row(id)
		if row.is_empty(): continue
		row.level = record.level
		row.fighterXp = record.xp
		var action: Variant = _core.get_action(id)
		if action!=null or record.status in ["hospital","downed"] or _truth(row.get("_mercenaryVehicleSeat")) or _truth(row.get("_mercenaryVehicleChase")): _clear_staged(row)
		if _truth(row.get("_mercenaryVehicleSeat")): row._mercenaryMove = null; _stop(id,row,"seated"); continue
		if _truth(row.get("_mercenaryVehicleChase")) and row.get("_mercenaryVehicleMove") is Dictionary: row._mercenaryMove = row._mercenaryVehicleMove; _advance(id,row,elapsed); continue
		if action==null and not record.status in ["hospital","downed"]:
			var defense: Variant = _call("defend_member",[id],false)
			if _truth(defense):
				if defense=="approach": _advance(id,row,elapsed)
				else: _stop(id,row,"defending")
				continue
		if action==null and row.get("_mercenarySafeExit") is Dictionary:
			var exit: Dictionary = row._mercenarySafeExit
			var position: Variant = _position(id)
			var arrived: bool = position!=null and _distance(position,exit.position)<=float(exit.stopDistance)+0.000001
			if arrived and not _truth(exit.get("arrivedAt")): exit.arrivedAt = _now()
			if record.status=="active" and _now()<float(exit.expires) and (not arrived or _now()-float(exit.arrivedAt)<1): row._mercenaryMove = exit; _advance(id,row,elapsed); continue
			row.erase("_mercenarySafeExit")
			row._mercenaryPath = null
		var position: Variant = _position(id)
		var nearby: float = _distance(position,hero.position) if position!=null and _finite_point(hero.get("position")) else INF
		if action==null and _truth(row.get("_mercenaryGreetingUntil")):
			if _now()<float(row._mercenaryGreetingUntil) and float(row.get("hp",0))>0 and not _truth(row.get("_mercenaryHospital")) and nearby<=3.5: _face_player(id,row,elapsed); continue
			row.erase("_mercenaryGreetingUntil")
		if action==null and _truth(row.get("_mercenaryConversation")):
			if nearby<=2.5: _face_player(id,row,elapsed); continue
			row.erase("_mercenaryConversation")
		if record.status=="returning" and action==null:
			row._mercenaryReturnMove = true
			row._mercenaryMove = {"position":hero.get("position"),"stopDistance":5.0} if _finite_point(hero.get("position")) else null
		elif _truth(row.get("_mercenaryReturnMove")): row._mercenaryMove = null; row._mercenaryReturnMove = false; _stop(id,row,"idle")
		if action==null and record.status=="active" and not _core.get_queue(id).is_empty(): row._mercenaryMove = null; _stop(id,row,"queued"); continue
		if action==null and record.status=="active": row._mercenaryMove = _peaceful_goal(id,row,index)
		_advance(id,row,elapsed)
	if lifecycle_changed or _now()-_last_save>=2: _persist()
	return {"ready":true,"clock":_clock_report.duplicate(),"catchup":_catchup_report.duplicate(),"members":roster.size(),"routeBudgetMs":1.5}

func dispose() -> void:
	if _disposed: return
	for record: Dictionary in _core.get_roster():
		var id: String = str(record.id)
		var row: Dictionary = _row(id)
		if not row.is_empty(): row._mercenaryPath = null; row._mercenaryMove = null; _stop(id,row,"disposed")
	_catchup.clear()
	_disposed = true
	_options.clear()
	_core = null
	_host = null
