extends RefCounted
## Source mercenary_route.mjs and mercenary_long_follow.mjs.
## Coordinates are metre dictionaries. Collision and terrain remain host callbacks.
## Search.path is null until a route completes, and remains null on exhaustion.

var _options: Dictionary = {}

func _init(options: Dictionary = {}) -> void:
	_options = options.duplicate()

func start(from: Dictionary, to: Dictionary, options: Dictionary = {}) -> Search:
	return Search.new(from, to, options, _options)

static func create_long_follow(options: Dictionary = {}) -> LongFollow:
	return LongFollow.new(options)


class Values:
	extends RefCounted

	static func distance(a: Dictionary, b: Dictionary) -> float:
		# Keep scalar doubles: native Vector2 components may round to float32.
		var dx: float = float(a.x) - float(b.x)
		var dz: float = float(a.z) - float(b.z)
		return sqrt(dx * dx + dz * dz)

	static func valid(point: Variant) -> bool:
		if not point is Dictionary:
			return false
		var x: Variant = point.get("x")
		var z: Variant = point.get("z")
		return (x is float or x is int) and (z is float or z is int) and is_finite(float(x)) and is_finite(float(z))

	static func now(options: Dictionary) -> float:
		var callback: Variant = options.get("clock")
		if callback is Callable and callback.is_valid():
			return float(callback.call())
		return float(Time.get_ticks_usec()) / 1000.0

	static func height(options: Dictionary, x: float, z: float) -> Variant:
		var callback: Variant = options.get("groundHeight")
		if callback is Callable and callback.is_valid():
			return callback.call(x, z)
		return 0.0

	static func clear(options: Dictionary, a: Dictionary, b: Dictionary) -> bool:
		var callback: Variant = options.get("canMove")
		if not callback is Callable or not callback.is_valid():
			return false
		var result: Variant = callback.call(a, b)
		return result is bool and result == true


class Search:
	extends RefCounted

	var stats: Dictionary = {"expanded": 0, "checks": 0, "slices": 0}
	var done: bool = false
	var path: Variant = null
	var _origin: Dictionary
	var _goal: Dictionary
	var _options: Dictionary
	var _step: float
	var _max_nodes: float
	var _max_distance: float
	var _arrival_radius: float
	var _nodes: Dictionary = {}
	var _heap: Array[Dictionary] = []

	func _init(from: Dictionary, to: Dictionary, search_options: Dictionary, planner_options: Dictionary) -> void:
		_origin = from.duplicate()
		_goal = to.duplicate()
		_options = planner_options.duplicate()
		_step = float(_options.get("step", 0.65))
		_max_nodes = float(_options.get("maxNodes", 2400))
		_max_distance = float(_options.get("maxDistance", 48))
		_arrival_radius = float(search_options.get("arrivalRadius", 0))
		var heuristic: float = _heuristic(_origin)
		var first: Dictionary = {"x": 0, "z": 0, "p": _origin, "g": 0.0, "h": heuristic, "f": heuristic, "parent": null}
		_nodes["0,0"] = first
		_push(first)

	func _point(x: int, z: int) -> Dictionary:
		var px: float = float(_origin.x) + x * _step
		var pz: float = float(_origin.z) + z * _step
		return {"x": px, "y": Values.height(_options, px, pz), "z": pz}

	func _heuristic(point: Dictionary) -> float:
		return maxf(0.0, absf(float(point.x) - float(_goal.x)) + absf(float(point.z) - float(_goal.z)) - sqrt(2.0) * maxf(_step * 1.5, _arrival_radius))

	func _less(a: Dictionary, b: Dictionary) -> bool:
		return a.f < b.f or (a.f == b.f and a.h < b.h)

	func _push(node: Dictionary) -> void:
		_heap.append(node)
		var index: int = _heap.size() - 1
		while index != 0:
			var parent: int = (index - 1) >> 1
			if not _less(node, _heap[parent]):
				break
			_heap[index] = _heap[parent]
			index = parent
		_heap[index] = node

	func _pop() -> Dictionary:
		var first: Dictionary = _heap[0]
		var last: Dictionary = _heap.pop_back()
		if not _heap.is_empty():
			var index: int = 0
			while index * 2 + 1 < _heap.size():
				var child: int = index * 2 + 1
				if child + 1 < _heap.size() and _less(_heap[child + 1], _heap[child]):
					child += 1
				if not _less(_heap[child], last):
					break
				_heap[index] = _heap[child]
				index = child
			_heap[index] = last
		return first

	func _clear(a: Dictionary, b: Dictionary) -> bool:
		stats.checks += 1
		return Values.clear(_options, a, b)

	func _finish(node: Dictionary, exact: bool = true) -> void:
		var endpoint: Dictionary = _goal if exact else node.p
		var points: Array = [_goal] if exact else []
		var cursor: Variant = node
		while cursor != null:
			points.append(cursor.p)
			cursor = cursor.parent
		points.reverse()
		var compact: Array = [points[0]]
		for index: int in range(1, points.size() - 1):
			var a: Dictionary = compact[-1]
			var b: Dictionary = points[index]
			var c: Dictionary = points[index + 1]
			if absf((float(b.x) - float(a.x)) * (float(c.z) - float(b.z)) - (float(b.z) - float(a.z)) * (float(c.x) - float(b.x))) > 0.0000001:
				compact.append(b)
		compact.append(endpoint)
		done = true
		path = compact.slice(1)

	func advance(options: Dictionary = {}) -> Variant:
		if done:
			return path
		stats.slices += 1
		var deadline: float = Values.now(_options) + float(options.get("budgetMs", 1))
		var expanded: int = 0
		var max_expanded: float = float(options.get("maxExpanded", 12))
		while not _heap.is_empty() and _nodes.size() < _max_nodes and expanded < max_expanded and (expanded == 0 or Values.now(_options) < deadline):
			var current: Dictionary = _pop()
			if current.get("closed", false):
				continue
			current.closed = true
			expanded += 1
			stats.expanded += 1
			if Values.distance(current.p, _goal) <= _arrival_radius:
				_finish(current, false)
				return path
			if Values.distance(current.p, _goal) <= _step * 1.5 and _clear(current.p, _goal):
				_finish(current)
				return path
			for direction: Vector2i in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var x: int = int(current.x) + direction.x
				var z: int = int(current.z) + direction.y
				var key: String = str(x) + "," + str(z)
				if _nodes.has(key):
					continue
				var point: Dictionary = _point(x, z)
				var cost: float = float(current.g) + _step
				var heuristic: float = _heuristic(point)
				if cost + Values.distance(point, _goal) > _max_distance or not _clear(current.p, point):
					continue
				var next: Dictionary = {"x": x, "z": z, "p": point, "g": cost, "h": heuristic, "f": cost + heuristic, "parent": current}
				_nodes[key] = next
				_push(next)
		if _heap.is_empty() or _nodes.size() >= _max_nodes:
			done = true
			path = null
		return path


class LongFollow:
	extends RefCounted

	var stats: Dictionary = {"searches": 0, "expanded": 0, "checks": 0, "completedStages": 0, "retargets": 0, "cancellations": 0, "maxSearchExpanded": 0}
	var _options: Dictionary = {}
	var _route: Variant = null
	var _blocked_until: float = 0.0

	func _init(options: Dictionary = {}) -> void:
		# Source long-follow passes only these providers to its default planner.
		for key: String in ["canMove", "groundHeight", "clock"]:
			if options.has(key):
				_options[key] = options[key]

	func _clear() -> void:
		_route = null
		_blocked_until = 0.0

	func cancel() -> Dictionary:
		_clear()
		stats.cancellations += 1
		return {"status": "cancelled", "waypoint": null}

	func _reply(status: String) -> Dictionary:
		return {"status": status, "waypoint": null}

	func _begin(from: Dictionary, goal: Dictionary, arrival_radius: float, stamp: float) -> void:
		var distance: float = Values.distance(from, goal)
		var length: float = minf(24.0, distance)
		var heading: float = atan2(float(goal.z) - float(from.z), float(goal.x) - float(from.x))
		var candidates: Array = []
		var angles: Array = [0.0] if distance <= 24.0 else [0.0, PI / 6.0, -PI / 6.0, PI / 3.0, -PI / 3.0]
		for angle: float in angles:
			var point: Dictionary = goal.duplicate() if distance <= 24.0 else {"x": float(from.x) + cos(heading + angle) * length, "z": float(from.z) + sin(heading + angle) * length}
			if distance > 24.0 and distance - Values.distance(point, goal) < 1.0:
				continue
			point.y = Values.height(_options, point.x, point.z)
			candidates.append({"point": point, "arrivalRadius": arrival_radius if distance <= 24.0 else 0.04})
		_route = {"origin": from.duplicate(), "goal": goal.duplicate(), "createdAt": stamp, "candidates": candidates, "candidateIndex": 0, "search": null, "path": null, "index": 0}

	func advance(from: Variant, goal: Variant, options: Dictionary = {}) -> Dictionary:
		# JS !active: ordinary boolean gates plus JS-falsey optional values.
		var active: Variant = options.get("active", true)
		var enabled: bool = not (active == null or (active is bool and active == false) or ((active is int or active is float) and (float(active) == 0.0 or is_nan(float(active)))) or (active is String and active.is_empty()))
		var purpose: Variant = options.get("purpose", "follow")
		if not enabled or not (purpose is String and purpose == "follow") or not Values.valid(from) or not Values.valid(goal):
			return cancel()
		var stamp: float = Values.now(_options)
		var distance: float = Values.distance(from, goal)
		var arrival_radius: float = float(options.get("arrivalRadius", 0.6))
		var max_expanded: float = float(options.get("maxExpanded", 8))
		var budget_ms: float = float(options.get("budgetMs", 0.75))
		if distance <= arrival_radius:
			_clear()
			return _reply("arrived")
		if _route != null:
			var drift: float = Values.distance(_route.goal, goal)
			if drift > 12.0 or (_route.search != null and stamp - float(_route.createdAt) > 6000.0 and drift > 0.8):
				_clear()
				stats.retargets += 1
		if stamp < _blocked_until:
			return _reply("blocked")
		if _route == null:
			_begin(from, goal, arrival_radius, stamp)
		if _route.path != null:
			while int(_route.index) < _route.path.size() and Values.distance(from, _route.path[_route.index]) <= 0.06:
				_route.index += 1
			if int(_route.index) >= _route.path.size():
				stats.completedStages += 1
				_clear()
				return _reply("stage_complete")
			return {"status": "moving", "waypoint": _route.path[_route.index].duplicate(), "stopDistance": 0.04}
		if not (budget_ms > 0.0) or not (max_expanded > 0.0):
			return _reply("budget")
		var deadline: float = stamp + minf(0.75, budget_ms)
		if _route.search == null:
			var index: int = int(_route.candidateIndex)
			if index >= _route.candidates.size():
				_route = null
				_blocked_until = stamp + 2000.0
				return _reply("blocked")
			var candidate: Dictionary = _route.candidates[index]
			stats.checks += 1
			if not Values.clear(_options, candidate.point, candidate.point):
				_route.candidateIndex += 1
				return _reply("candidate_failed")
			_route.search = Search.new(_route.origin, candidate.point, {"arrivalRadius": candidate.arrivalRadius}, _options)
			stats.searches += 1
		if Values.now(_options) >= deadline:
			return _reply("budget")
		var search: Search = _route.search
		var before_expanded: int = int(search.stats.expanded)
		var before_checks: int = int(search.stats.checks)
		search.advance({"maxExpanded": minf(8.0, floor(max_expanded)), "budgetMs": deadline - Values.now(_options)})
		stats.expanded += int(search.stats.expanded) - before_expanded
		stats.checks += int(search.stats.checks) - before_checks
		stats.maxSearchExpanded = maxi(int(stats.maxSearchExpanded), int(search.stats.expanded))
		if not search.done:
			return _reply("searching")
		_route.search = null
		# An empty JavaScript Array is truthy; only null means no path.
		if search.path == null:
			_route.candidateIndex += 1
			return _reply("candidate_failed")
		_route.path = search.path
		_route.index = 0
		return _reply("path_ready")

	func blocked() -> void:
		_clear()
		_blocked_until = Values.now(_options) + 500.0

	func inspect() -> Variant:
		if _route == null:
			return null
		return {"goal": _route.goal.duplicate(), "candidateIndex": _route.candidateIndex, "searching": _route.search != null, "pathLength": _route.path.size() if _route.path != null else 0}
