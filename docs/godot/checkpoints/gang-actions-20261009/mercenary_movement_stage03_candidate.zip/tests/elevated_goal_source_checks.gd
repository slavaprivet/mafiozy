extends "movement_world_source_checks.gd"
## Stage03 supplemental wrapper. Frozen stage02 files remain unchanged.
## Author-origin simulated-owner utility; native execution NOT_RUN.
const DriverBase = preload("movement_world_source_checks.gd")

class ElevatedBridge extends DriverBase.WorldBridge:
	func native_can_move(from_point: Dictionary, to_point: Dictionary, id: String) -> bool:
		# Deliberately enforce the oracle's geometry predicate; never ground an
		# incoming point in the fixture itself, which would hide the runtime defect.
		var accepted: bool = from_point.get("y") == 0 and to_point.get("y") == 0
		calls.append({"provider": "canMove", "from": from_point.duplicate(true),
			"to": to_point.duplicate(true), "memberId": id, "result": accepted})
		return accepted

func run(CoreScript: Variant, MovementScript: Variant, oracle: Dictionary) -> Dictionary:
	_failures = []
	_comparisons = 0
	var cases: Array = oracle.get("cases", [])
	var trace: Array = []
	var passed: Array = []
	var count: int = 0
	_compare("walk.movement.world_commands_source.v1", oracle.get("schema"), "oracle.schema")
	_compare("elevated_goal_footprint_grounding_v1", oracle.get("supplement", {}).get("id"), "oracle.supplement")
	_compare(1, cases.size(), "oracle.case_count")
	for value: Variant in cases:
		var item: Dictionary = value
		var before: int = _failures.size()
		var bridge: ElevatedBridge = ElevatedBridge.new()
		bridge.configure(CoreScript, MovementScript, item)
		var records: Array = []
		var steps: Array = item.steps
		for step_value: Variant in steps:
			var step: Dictionary = step_value
			var input: Dictionary = step.input.duplicate(true)
			var cursor: int = bridge.calls.size()
			var owner_cursor: int = bridge.owner_commits.size()
			var result: Variant = bridge.replay(str(step.operation), input)
			var snapshot: Dictionary = bridge.snapshot()
			var calls: Array = bridge.calls.slice(cursor).duplicate(true)
			var location: String = "%s.steps[%d]" % [item.id, records.size()]
			_compare(step.result, result, location + ".result")
			_compare(step.snapshot, snapshot, location + ".snapshot")
			_compare(step.provider_calls, calls, location + ".provider_calls")
			for forbidden: String in ["position", "r", "c"]:
				_compare(false, bridge.row.has(forbidden), location + ".policy_wrote_row_" + forbidden)
			records.append({"operation": step.operation, "input": input, "result": DriverBase.WorldBridge.copied(result),
				"snapshot": snapshot, "provider_calls": calls,
				"simulated_owner_commits": bridge.owner_commits.slice(owner_cursor).duplicate(true)})
			count += 1
		_compare([], bridge.bridge_errors, str(item.id) + ".bridge_errors")
		if before == _failures.size(): passed.append(item.id)
		trace.append({"case_id": item.id, "steps": records})
		bridge.movement.dispose()
		bridge.movement = null
		bridge.core = null
		bridge.pending_objects.clear()
	_compare(125, count, "oracle.step_count")
	return {"schema": "walk.movement.elevated_goal_native.v1", "status": "PASS" if _failures.is_empty() else "FAIL",
		"author_validation": "NOT_RUN", "utility_origin": "author-origin; inherited simulated owner, not real physics",
		"case_count": cases.size(), "step_count": count, "comparisons": _comparisons,
		"completed_cases": passed, "failures": _failures.duplicate(true), "trace": trace,
		"provider_contract": "Both y components must already equal floor0 at native_can_move entry; fixture never repairs runtime coordinates"}
