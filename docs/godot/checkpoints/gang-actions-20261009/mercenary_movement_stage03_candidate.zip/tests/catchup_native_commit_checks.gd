extends RefCounted
## Author-origin adapter checks; physical-body acceptance remains BUILD/QA.
## Engine and grammar validation NOT_RUN by author; parent/QA executes run().
const AUTHOR_VALIDATION: String = "NOT_RUN"
const MEMBER_ID: String = "merc_1"
var _failures: Array = []
var _checks: int = 0

func run(CatchupScript: Variant) -> Dictionary:
	_failures = []
	_checks = 0
	_check_rejection(CatchupScript)
	_check_commit(CatchupScript)
	_check_clear_pending(CatchupScript)
	_check_default(CatchupScript)
	return {"schema": "walk.catchup.native_commit_checks.v1", "author_validation": AUTHOR_VALIDATION, "checks": _checks, "differences": _failures.size(), "failures": _failures.duplicate(true), "ok": _failures.is_empty(), "physical_body_acceptance": "NOT_RUN"}

func _new_catchup(CatchupScript: Variant, deferred: bool) -> RefCounted:
	var options: Dictionary = {"placement": {"check": _safe_point}}
	if deferred:
		options.deferRelocationCommit = true
	return CatchupScript.new(options)

func _safe_point(point: Dictionary, _member: Variant) -> Dictionary:
	return {"ok": true, "point": {"x": point.x, "y": 0.0, "z": point.z}}

func _data(now_ms: float) -> Dictionary:
	return {"now": now_ms, "hero": {"position": {"x": 100.0, "y": 0.0, "z": 100.0}, "angle": PI / 4.0, "alive": true}, "members": [{"id": MEMBER_ID, "owned": true, "status": "active", "hp": 80, "position": {"x": 0.0, "y": 0.0, "z": 0.0}, "order": "follow"}], "maxChecks": 4}

func _state(catchup: RefCounted) -> Dictionary:
	var states: Dictionary = catchup.get("_states")
	return states.get(MEMBER_ID, {}).duplicate(true)

func _prime(catchup: RefCounted, label: String) -> Dictionary:
	# Continuous updates; a gap >1000 ms deliberately resets source timers.
	for second: int in range(7):
		var early: Dictionary = catchup.update(_data(float(second) * 1000.0))
		_expect(early.relocations.is_empty(), label + ".no_early_relocation_%d" % second)
	var before: Dictionary = _state(catchup)
	var result: Dictionary = catchup.update(_data(6060.0))
	_expect(result.relocations.size() == 1, label + ".one_confirmed_candidate")
	return {"before": before, "result": result}

func _check_rejection(CatchupScript: Variant) -> void:
	var catchup: RefCounted = _new_catchup(CatchupScript, true)
	var primed: Dictionary = _prime(catchup, "deferred")
	if primed.result.relocations.size() != 1:
		return
	var point: Dictionary = primed.result.relocations[0].point
	var state: Dictionary = _state(catchup)
	_expect(int(catchup.stats.placed) == 0, "deferred.proposal_not_placed")
	_expect(float(state.cooldownUntil) == 0.0, "deferred.proposal_no_cooldown")
	_expect(state.progressPoint == primed.before.progressPoint and state.progressAt == primed.before.progressAt and state.farAt == primed.before.farAt, "deferred.proposal_preserves_observed_progress")
	var again: Dictionary = catchup.update(_data(6070.0))
	_expect(again.relocations.is_empty() and int(again.checks) == 0 and int(catchup.stats.placed) == 0, "deferred.no_ack_no_second_proposal")
	_expect(not catchup.commit_relocation("missing_member", point, 6070.0), "deferred.unrequested_ack_rejected")
	var wrong_height: Dictionary = point.duplicate()
	wrong_height.y = float(point.y) + 100.0
	_expect(not catchup.commit_relocation(MEMBER_ID, wrong_height, 6070.0), "deferred.wrong_y_rejected")
	wrong_height.y = NAN
	_expect(not catchup.commit_relocation(MEMBER_ID, wrong_height, 6070.0), "deferred.nonfinite_y_rejected")
	var missing_height: Dictionary = point.duplicate()
	missing_height.erase("y")
	_expect(not catchup.commit_relocation(MEMBER_ID, missing_height, 6070.0), "deferred.missing_y_rejected")
	_expect(int(catchup.stats.placed) == 0 and float(_state(catchup).cooldownUntil) == 0.0, "deferred.failed_acks_not_placed")
	catchup.reject_relocation(MEMBER_ID, 6080.0)
	state = _state(catchup)
	_expect(state.lastReason == "owner_rejected" and state.search.status == "blocked" and float(state.search.retryAt) == 8080.0, "rejection.retry_two_seconds")
	_expect(state.search.pending == null, "rejection.confirmation_cleared")
	_expect(state.progressPoint == primed.before.progressPoint and state.progressAt == primed.before.progressAt and state.farAt == primed.before.farAt and float(state.cooldownUntil) == 0.0, "rejection.keeps_observed_progress_far_and_cooldown")
	_expect(not catchup.commit_relocation(MEMBER_ID, point, 6081.0), "rejection.pending_removed")
	var retry: Dictionary = catchup.update(_data(7000.0))
	_expect(retry.relocations.is_empty() and int(retry.checks) == 0, "rejection.no_early_resolver_retry")
	_expect(int(catchup.stats.placed) == 0, "rejection.not_placed")

func _check_commit(CatchupScript: Variant) -> void:
	var catchup: RefCounted = _new_catchup(CatchupScript, true)
	var primed: Dictionary = _prime(catchup, "commit")
	if primed.result.relocations.size() != 1:
		return
	var point: Dictionary = primed.result.relocations[0].point
	_expect(absf(float(point.x) - 97.4544155877) < 0.0000001, "commit.source_fractional_candidate")
	# Standard Godot Vector3 storage rounds this source point to float32.
	# The same test also remains valid on double-precision Godot builds.
	var native: Vector3 = Vector3(float(point.x), float(point.y), float(point.z))
	var actual: Dictionary = {"x": native.x, "y": native.y, "z": native.z}
	_expect(not catchup.commit_relocation(MEMBER_ID, actual, 6059.0), "commit.stale_time_rejected")
	_expect(catchup.commit_relocation(MEMBER_ID, actual, 6060.0), "commit.native_quantization_accepted")
	var state: Dictionary = _state(catchup)
	_expect(int(catchup.stats.placed) == 1 and state.lastReason == "placed", "commit.placed_once")
	_expect(float(state.cooldownUntil) == 26060.0, "commit.cooldown_twenty_seconds")
	_expect(state.progressPoint == actual and float(state.progressAt) == 6060.0 and state.farAt == null and state.search == null, "commit.progress_uses_actual_position")
	_expect(not catchup.commit_relocation(MEMBER_ID, actual, 6061.0) and int(catchup.stats.placed) == 1, "commit.duplicate_ack_no_double_count")
	var statistics: Dictionary = catchup.get_stats()
	catchup.clear()
	_expect(catchup.inspect(MEMBER_ID) == null and catchup.get_stats() == statistics, "commit.clear_retains_statistics")

func _check_clear_pending(CatchupScript: Variant) -> void:
	var catchup: RefCounted = _new_catchup(CatchupScript, true)
	var primed: Dictionary = _prime(catchup, "clear_pending")
	if primed.result.relocations.size() != 1:
		return
	var point: Dictionary = primed.result.relocations[0].point
	var statistics: Dictionary = catchup.get_stats()
	catchup.clear()
	_expect(not catchup.commit_relocation(MEMBER_ID, point, 6060.0), "clear_pending.cannot_commit_cleared_proposal")
	_expect(catchup.inspect(MEMBER_ID) == null and catchup.get_stats() == statistics, "clear_pending.state_cleared_stats_retained")

func _check_default(CatchupScript: Variant) -> void:
	var catchup: RefCounted = _new_catchup(CatchupScript, false)
	var primed: Dictionary = _prime(catchup, "source_default")
	if primed.result.relocations.size() != 1:
		return
	var point: Dictionary = primed.result.relocations[0].point
	var state: Dictionary = _state(catchup)
	_expect(catchup.get_stats() == {"checks": 2, "refused": 0, "placed": 1, "waiting": 0, "maxChecksPerUpdate": 1}, "source_default.original_statistics")
	_expect(float(state.cooldownUntil) == 26060.0 and state.progressPoint == point and float(state.progressAt) == 6060.0 and state.search == null and state.farAt == null and state.lastReason == "placed", "source_default.immediate_original_commit")
	_expect(not catchup.commit_relocation(MEMBER_ID, point, 6060.0), "source_default.no_native_ack_required")
	var before: Dictionary = _state(catchup)
	catchup.reject_relocation(MEMBER_ID, 6060.0)
	_expect(_state(catchup) == before, "source_default.native_reject_no_effect")
	var statistics: Dictionary = catchup.get_stats()
	catchup.clear()
	_expect(catchup.get_stats() == statistics and catchup.inspect(MEMBER_ID) == null, "source_default.clear_keeps_statistics")

func _expect(condition: bool, label: String) -> void:
	_checks += 1
	if not condition:
		_failures.append({"check": label})
