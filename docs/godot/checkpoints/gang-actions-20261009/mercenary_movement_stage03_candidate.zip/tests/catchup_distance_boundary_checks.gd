extends "movement_policy_source_checks.gd"
## Supplemental wrapper only. Inherited source-case replay/comparator unchanged.
## Author-origin utility. Native/compile execution NOT_RUN.

func run(RouteScript: Variant, CatchupScript: Variant, oracle: Dictionary) -> Dictionary:
	_failures = []
	_comparisons = 0
	var trace: Array = []
	var passed_cases: Array = []
	var cases: Array = oracle.get("cases", [])
	var supplement: Dictionary = oracle.get("supplement", {})
	_compare("walk.movement.source_cases.v1", oracle.get("schema"), "oracle.schema")
	_compare("catchup_distance_boundaries_v1", supplement.get("id"), "oracle.supplement")
	_compare(26, cases.size(), "oracle.case_count")
	var count: int = 0
	for value: Variant in cases:
		var item: Dictionary = value
		var before: int = _failures.size()
		var actual: Array = _replay_case(RouteScript, CatchupScript, item)
		var expected: Array = item.steps
		_compare(expected.size(), actual.size(), str(item.id) + ".step_count")
		for index: int in range(mini(expected.size(), actual.size())):
			_compare(expected[index].expected, actual[index].actual, "%s.steps[%d]" % [item.id, index])
		count += actual.size()
		trace.append({"case_id": item.id, "boundary": item.boundary, "steps": actual})
		if _failures.size() == before: passed_cases.append(item.id)
	_compare(171, count, "oracle.step_count")
	return {"schema": "walk.movement.catchup_distance_native.v1", "status": "PASS" if _failures.is_empty() else "FAIL",
		"utility_origin": "author-origin supplemental Float64 boundary comparison", "author_validation": "NOT_RUN",
		"case_count": cases.size(), "step_count": count, "comparisons": _comparisons,
		"completed_cases": passed_cases, "failures": _failures.duplicate(true), "trace": trace,
		"scope": "Pure catchup policy only; no physical relocation or Godot-run claim"}
