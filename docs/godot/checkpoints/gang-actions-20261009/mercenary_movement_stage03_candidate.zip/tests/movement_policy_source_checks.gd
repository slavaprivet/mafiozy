extends RefCounted
## Author-origin comparison utility. Author validation: NOT_RUN (no Godot job).
## QA loads movement_source_cases.json and passes its parsed Dictionary to run().
## Replays source policy calls only; does not claim physical movement or full rally.
const AUTHOR_VALIDATION: String = "NOT_RUN"
const ORACLE_SCHEMA: String = "walk.movement.source_cases.v1"
const EXPECTED_CASES: int = 83
const EXPECTED_STEPS: int = 488
const NUMBER_TOLERANCE: float = 1.0e-9

var _failures: Array = []
var _comparisons: int = 0

func run(RouteScript: Variant, CatchupScript: Variant, oracle: Dictionary) -> Dictionary:
	_failures = []
	_comparisons = 0
	var trace: Array = []
	var completed_cases: Array = []
	var cases: Array = oracle.get("cases", [])
	_compare(ORACLE_SCHEMA, oracle.get("schema"), "oracle.schema")
	_compare(EXPECTED_CASES, cases.size(), "oracle.case_count")
	var total_steps: int = 0
	for case_value: Variant in cases:
		var case_data: Dictionary = case_value
		var case_id: String = str(case_data.get("id", ""))
		var before_failures: int = _failures.size()
		var actual_steps: Array = _replay_case(RouteScript, CatchupScript, case_data)
		var expected_steps: Array = case_data.get("steps", [])
		_compare(expected_steps.size(), actual_steps.size(), case_id + ".step_count")
		for index: int in range(mini(expected_steps.size(), actual_steps.size())):
			var expected_step: Dictionary = expected_steps[index]
			var actual_step: Dictionary = actual_steps[index]
			_compare(expected_step.get("expected"), actual_step.get("actual"), "%s.steps[%d]" % [case_id, index])
		total_steps += actual_steps.size()
		trace.append({"case_id": case_id, "api": case_data.get("api"), "steps": actual_steps})
		if _failures.size() == before_failures:
			completed_cases.append(case_id)
	_compare(EXPECTED_STEPS, total_steps, "oracle.total_steps")
	return {
		"schema": "walk.movement.native_comparison.v1",
		"utility_origin": "Gameplay author-origin utility; independent QA execution required",
		"author_validation": AUTHOR_VALIDATION,
		"status": "PASS" if _failures.is_empty() else "FAIL",
		"scope": "Exported policy differential only; host movement, complete rally, physics and effects excluded",
		"case_count": cases.size(), "step_count": total_steps,
		"comparisons": _comparisons, "completed_cases": completed_cases,
		"failures": _failures.duplicate(true), "trace": trace,
		"source_files": _copy(oracle.get("sources", [])),
		"numeric_absolute_tolerance": NUMBER_TOLERANCE,
	}

func _replay_case(RouteScript: Variant, CatchupScript: Variant, case_data: Dictionary) -> Array:
	var api: String = str(case_data.get("api", ""))
	var calls: Array = []
	var context: Dictionary = {"now": 0.0, "placement_y": 0.0}
	var engine: Variant = null
	var state: Dictionary = {}
	var rows: Array = []
	var placement_mode: String = str(case_data.get("placement", "allow"))
	var validate: Callable = func(point: Variant, member: Variant) -> Dictionary:
		var result: Dictionary
		if placement_mode == "deny":
			result = {"ok": false, "reason": "fixture_blocked"}
		else:
			var resolved: Dictionary = _copy(point)
			resolved["y"] = context["placement_y"]
			result = {"ok": true, "point": resolved}
		calls.append({"provider": "placement.check", "point": _copy(point), "member": _copy(member), "result": _copy(result)})
		return result
	if api == "catchup":
		var options: Dictionary = _copy(case_data.get("options", {}))
		if placement_mode != "missing":
			options["placement"] = {"check": validate}
		engine = CatchupScript.new(options)
	elif api == "follow":
		var can_move: Callable = func(from_point: Variant, to_point: Variant) -> bool:
			var result: bool = case_data.get("collision", "allow") != "deny"
			calls.append({"provider": "canMove", "from": _copy(from_point), "to": _copy(to_point), "result": result})
			return result
		var now_clock: Callable = func() -> float: return float(context["now"])
		var ground: Callable = func(_x: Variant, _z: Variant) -> float: return 0.0
		engine = RouteScript.create_long_follow({"clock": now_clock, "groundHeight": ground, "canMove": can_move})
	var steps: Array = case_data.get("steps", [])
	for step_value: Variant in steps:
		var step: Dictionary = step_value
		var input: Dictionary = _copy(step.get("input", {}))
		var pristine_input: Dictionary = input.duplicate(true)
		var operation: String = str(step.get("op", "call"))
		var before_calls: int = calls.size()
		var result: Variant = null
		var inspection: Variant = null
		var statistics: Variant = null
		context["now"] = step.get("fixture_clock", 0.0)
		if step.has("placement_y"):
			context["placement_y"] = step["placement_y"]
		match api:
			"eligible":
				result = CatchupScript.eligible(input)
			"catchup":
				if operation == "clear":
					engine.clear()
				else:
					result = engine.update(input)
					inspection = {}
					var members: Array = input.get("members", [])
					for member_value: Variant in members:
						var member: Dictionary = member_value
						inspection[str(member["id"])] = _copy(engine.inspect(member["id"]))
					_compare(pristine_input, input, str(case_data["id"]) + ".input_immutability[%d]" % rows.size())
				statistics = _copy(engine.stats)
			"drop":
				var options: Dictionary = input.duplicate(true)
				options["validate"] = validate
				result = CatchupScript.advance_safe_drop(state, options)
				inspection = state.duplicate(true)
			"placement":
				var providers: Dictionary = _placement_providers(case_data.get("provider", {}), input["point"], calls)
				var resolver: Variant = CatchupScript.create_safe_placement(providers)
				result = resolver.check(input["point"], input["member"])
				inspection = {"radius": resolver.radius, "height": resolver.height}
			"follow":
				if operation == "cancel":
					result = engine.cancel()
				elif operation == "blocked":
					engine.blocked()
				else:
					result = engine.advance(input["from"], input["goal"], input.get("options", {}))
				inspection = _copy(engine.inspect())
				statistics = _copy(engine.stats)
			_:
				_failures.append({"path": str(case_data.get("id")) + ".api", "reason": "unsupported_api", "actual": api})
		var step_calls: Array = []
		for index: int in range(before_calls, calls.size()):
			step_calls.append(_copy(calls[index]))
		rows.append({"op": operation, "input": pristine_input, "fixture_clock": context["now"], "actual": {"result": _copy(result), "inspection": _copy(inspection), "stats": statistics, "provider_calls": step_calls}})
	return rows

func _placement_providers(settings: Dictionary, point: Dictionary, calls: Array) -> Dictionary:
	var providers: Dictionary = {"worldScale": 4.1}
	providers["ready"] = func() -> bool:
		var value: bool = settings.get("ready", true)
		calls.append({"provider": "ready", "args": [], "result": value})
		return value
	providers["bodyClear"] = func(body_point: Variant, member: Variant) -> bool:
		var value: bool = settings.get("bodyClear", true)
		calls.append({"provider": "bodyClear", "args": [_copy(body_point), _copy(member)], "result": value})
		return value
	providers["queryPoint"] = func(query: Variant) -> Dictionary:
		var value: Dictionary = {"blocked": settings.get("blocked", false), "depth": settings.get("depth", 0)}
		calls.append({"provider": "queryPoint", "args": [_copy(query)], "result": value.duplicate(true)})
		return value
	providers["groundHeight"] = func(x: Variant, z: Variant) -> float:
		var value: float = float(settings.get("high", 0)) if float(x) > float(point["x"]) else 0.0
		calls.append({"provider": "groundHeight", "args": [x, z], "result": value})
		return value
	providers["isInsideBuilding"] = func(query: Variant) -> bool:
		var value: bool = settings.get("inside", false)
		calls.append({"provider": "isInsideBuilding", "args": [_copy(query)], "result": value})
		return value
	providers["blocksVehicle"] = func(query: Variant, dimensions: Variant) -> bool:
		var value: bool = settings.get("vehicle", false)
		calls.append({"provider": "blocksVehicle", "args": [_copy(query), _copy(dimensions)], "result": value})
		return value
	if settings.has("missing"):
		providers.erase(settings["missing"])
	return providers

func _copy(value: Variant) -> Variant:
	if value is Dictionary or value is Array:
		return value.duplicate(true)
	return value

func _compare(expected: Variant, actual: Variant, location: String) -> void:
	_comparisons += 1
	if (expected is int or expected is float) and (actual is int or actual is float):
		if not is_finite(float(expected)) or not is_finite(float(actual)) or absf(float(expected) - float(actual)) > NUMBER_TOLERANCE:
			_mismatch(location, expected, actual, "numeric_value")
		return
	if typeof(expected) != typeof(actual):
		_mismatch(location, expected, actual, "type")
		return
	if expected is Dictionary:
		var expected_keys: Array = expected.keys()
		var actual_keys: Array = actual.keys()
		expected_keys.sort()
		actual_keys.sort()
		_compare(expected_keys, actual_keys, location + ".keys")
		for key: Variant in expected_keys:
			if actual.has(key):
				_compare(expected[key], actual[key], location + "." + str(key))
	elif expected is Array:
		if expected.size() != actual.size():
			_mismatch(location + ".length", expected.size(), actual.size(), "array_length")
		for index: int in range(mini(expected.size(), actual.size())):
			_compare(expected[index], actual[index], "%s[%d]" % [location, index])
	elif expected != actual:
		_mismatch(location, expected, actual, "value")

func _mismatch(location: String, expected: Variant, actual: Variant, reason: String) -> void:
	_failures.append({"path": location, "reason": reason, "expected": _copy(expected), "actual": _copy(actual)})
