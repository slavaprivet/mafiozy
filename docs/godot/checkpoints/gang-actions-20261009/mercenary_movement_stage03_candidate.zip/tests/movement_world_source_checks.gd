extends RefCounted
## Author-origin utility; native execution NOT_RUN. Simulated owner, NOT physics.
## QA calls run(CoreScript, MovementScript, parsed world_commands_oracle.json).
## The expected trace never drives an ongoing position, phase, queue or provider reply.
const AUTHOR_VALIDATION: String = "NOT_RUN"
const TOLERANCE: float = 1.0e-8
var _failures: Array = []
var _comparisons: int = 0

class WorldBridge extends RefCounted:
	var core: Variant
	var movement: Variant
	var core_script: Variant
	var member_id: String
	var profession: String
	var row: Dictionary = {}
	# Separate simulated physical owner. No row.position/r/c is exposed to policy.
	var owner: Dictionary = {}
	var hero: Dictionary = {"position": {"x": 41.0, "y": 0.0, "z": 41.0}, "angle": 0.0, "stance": "stand", "alive": true}
	var seconds: float = 1000.0
	var hidden: bool = false
	var provider_policy: Dictionary = {"pending": false, "canMove": true}
	var targets: Dictionary = {}
	var pending_by_target: Dictionary = {}
	var pending_objects: Array = []
	var calls: Array = []
	var owner_commits: Array = []
	var effect_count: int = 0
	var bridge_errors: Array = []

	func configure(CoreScript: Variant, MovementScript: Variant, case_data: Dictionary) -> void:
		core_script = CoreScript
		profession = str(case_data["profession"])
		member_id = str(case_data["initial"]["memberId"])
		seconds = float(case_data.get("fixture_options", {}).get("clockStart", 1000))
		# One-time source fixture initial state is input, never a later expected frame.
		var initial: Dictionary = case_data["steps"][0]["snapshot"]["position"]
		owner = {"c": float(initial.x)/4.1, "r": float(initial.z)/4.1, "y": float(initial.y)}
		var hp: float = 88.0 if profession == "demolitions" else 80.0
		row = {"id": member_id, "hp": hp, "max_hp": hp, "dead": false, "_mercenaryOrder": "follow"}
		core = CoreScript.new({"now": now_seconds, "getMember": get_member, "getTarget": get_target,
			"moveMember": move_member, "onAction": on_action, "performEffect": perform_effect,
			"canStartQueued": can_start_queued, "canAutoRevive": can_auto_revive,
			"scanReviveTargets": func() -> Array: return []})
		var recruited: Dictionary = core.recruit({"id": member_id, "profession": profession, "name": "fixture member"})
		if recruited.get("ok") != true:
			bridge_errors.append({"kind": "fixture_recruit_failed", "result": recruited})
		movement = MovementScript.new(core, self, {
			"now": now_seconds, "performance_now_ms": now_ms,
			"is_ready": func() -> bool: return true, "is_local": func() -> bool: return true,
			"is_hidden": func() -> bool: return hidden,
			"get_member_position": get_member_position, "get_player_state": get_player_state,
			"source_path_passable": func(_a: Dictionary, _b: Dictionary, _id: String) -> bool: return true,
			"body_passable": func(_p: Dictionary, _id: String) -> bool: return true,
			"native_can_move": native_can_move,
			"ground_height": func(_x: float, _z: float) -> float: return 0.0,
			"apply_motion": apply_motion,
			"stop_body": func(_id: String, _reason: String) -> void: pass,
			"face_body": func(_id: String, _angle: float, _posture: String) -> void: pass,
			"persist": func() -> void: pass,
			"clear_focus": func(_id: String) -> void: pass,
			"update_core": func() -> void: core.update()})

	func now_seconds() -> float:
		# Source now() is Date.now()/1000; fixture Date.now() is clock*1000.
		return (seconds * 1000.0) / 1000.0

	func now_ms() -> float:
		return seconds * 1000.0

	func member_row(id: String) -> Dictionary:
		return row if id == member_id else {}

	func get_member_position(id: String) -> Variant:
		return {"x": float(owner.c)*4.1, "y": owner.y, "z": float(owner.r)*4.1} if id == member_id else null

	func get_player_state() -> Dictionary:
		return hero.duplicate(true)

	func movement_snapshot() -> Dictionary:
		var route: Variant = row.get("_mercenaryPath")
		var goal: Variant = row.get("_mercenaryMove")
		var clock_report: Dictionary = {"elapsed": 0, "used": 0, "dropped": 0, "paused": false}
		if movement != null:
			var current: Variant = movement.get("_clock_report")
			if current is Dictionary and not current.is_empty(): clock_report = current.duplicate(true)
		clock_report["substeps"] = row.get("_mercenaryMoveSubsteps", 0)
		var search: Variant = null
		var path_length: int = 0
		var path_index: int = 0
		var route_goal: Variant = null
		if route is Dictionary:
			var active_search: Variant = route.get("search")
			if active_search != null: search = copied(active_search.stats)
			elif route.get("stats") is Dictionary: search = copied(route.stats)
			if route.get("path") is Array: path_length = route.path.size()
			path_index = int(route.get("index", 0))
			route_goal = copied(route.get("goal"))
		var reason: String = str(row.get("_mercenaryMoveReason", "idle" if goal == null else "moving"))
		if row.get("_mercenaryHospital", false): reason = "hospital"
		elif float(row.hp) <= 0: reason = "downed"
		return {"reason": reason, "clock": clock_report, "search": search,
			"pathLength": path_length, "pathIndex": path_index,
			"goal": copied(goal.get("position")) if goal is Dictionary else null,
			"routeGoal": route_goal, "lastAction": copied(row.get("_mercenaryLastAction"))}

	func get_member(id: Variant) -> Variant:
		if str(id) != member_id: return null
		var record: Variant = core.get_record(member_id) if core != null else null
		var status: Variant = record.get("status") if record is Dictionary else null
		var route: Variant = row.get("_mercenaryPath")
		var moving: bool = route is Dictionary and route.get("path") is Array and float(row.get("_followSpeed", 0)) > 0
		var searching: bool = route is Dictionary and route.get("search") != null and now_seconds()-float(route.get("lastSearchProgressAt", 0)) < 2
		var posture: String = "stand"
		if movement != null: posture = str(movement.get_member_motion(member_id).get("posture", "stand"))
		var position: Dictionary = get_member_position(member_id)
		var dx: float = float(position.x)-float(hero.position.x)
		var dz: float = float(position.z)-float(hero.position.z)
		return {"id": member_id, "kind": "npc", "queued": copied(record.get("queued", [])) if record is Dictionary else [],
			"posture": posture, "revivable": status != "hospital", "approachMoving": moving, "approachSearching": searching,
			"movement": movement_snapshot(), "qaRescueUntil": 0, "intimidatable": false,
			"position": position, "hp": row.hp, "dead": false, "downed": float(row.hp) <= 0,
			"available": status != "hospital", "followArrived": sqrt(dx*dx+dz*dz) < 7}

	func get_target(id: Variant) -> Variant:
		if str(id) == member_id: return get_member(id)
		if str(id) in ["player", "npc_player"]:
			return {"id": "player", "kind": "player", "position": copied(hero.position), "hp": 100, "downed": false, "revivable": false}
		return targets.get(id)

	func move_member(id: Variant, target: Variant, options: Dictionary) -> void:
		if str(id) != member_id: return
		row["_mercenaryReturnMove"] = false
		var previous: Variant = row.get("_mercenaryMove")
		if target == null or not previous is Dictionary or previous.get("targetId") != target.get("id") or previous.get("phase") != options.get("phase"):
			row["_mercenaryPath"] = null
			row["_mercenaryDetourUntil"] = 0
		if target == null:
			row["_mercenaryMove"] = null
		else:
			var active: Variant = core.get_action(member_id)
			row["_mercenaryMove"] = {"targetId": target.get("id"), "phase": options.get("phase"),
				"tracksMovingTarget": options.get("phase") == "approach" and target.get("kind") == "vehicle" and active is Dictionary and active.get("kind") == "plant_bomb",
				"position": copied(target.position), "stopDistance": options.get("stopDistance", 0)}
		if movement != null: movement.on_move_request(member_id, target, options)

	func on_action(id: Variant, action: Dictionary) -> void:
		if str(id) != member_id: return
		# Previous _mercenaryAction must remain visible while safe-exit normal is resolved.
		if movement != null: movement.on_action(member_id, action)
		row["_mercenaryAction"] = action.duplicate(true)

	func can_start_queued(id: Variant) -> bool:
		return movement.can_start_queued(str(id)) if movement != null else true

	func can_auto_revive(id: Variant) -> bool:
		return movement.can_auto_revive(str(id)) if movement != null else true

	func native_can_move(from_point: Dictionary, to_point: Dictionary, id: String) -> bool:
		var result: bool = provider_policy.get("canMove", true)
		calls.append({"provider": "canMove", "from": from_point.duplicate(true), "to": to_point.duplicate(true), "memberId": id, "result": result})
		return result

	func apply_motion(id: String, request: Dictionary) -> bool:
		if id != member_id: return false
		var before: Dictionary = get_member_position(id)
		# Test owner commits requested body displacement. This is NOT physical validation.
		owner.c = float(owner.c)+float(request.displacement.x)/4.1
		owner.r = float(owner.r)+float(request.displacement.z)/4.1
		owner.y = request.position.y
		owner_commits.append({"memberId": id, "before": before, "request": request.duplicate(true), "after": get_member_position(id)})
		return true

	func perform_effect(event: Dictionary) -> Variant:
		var pending: bool = provider_policy.get("pending", false)
		calls.append({"provider": "performEffect", "event": event.duplicate(true), "return_kind": "pending_promise" if pending else "receipt"})
		effect_count += 1
		if pending:
			pending_by_target[event.targetId] = event.requestId
			# Current source core PendingEffect has no constructor parameters; requestId is
			# captured separately by its _apply/subscribe path and by this replay bridge.
			var receipt: Variant = core_script.PendingEffect.new()
			pending_objects.append(receipt)
			return receipt
		var target: Variant = targets.get(event.targetId)
		if target is Dictionary:
			if event.kind == "disable_power": target.powered = false
			elif event.kind == "cut_fence": target.cut = true
			else: target.locked = false
		return {"ok": true}

	func snapshot() -> Dictionary:
		var member: Dictionary = get_member(member_id)
		var record: Dictionary = core.get_record(member_id)
		return {"clock_ms": now_ms(), "id": member_id, "position": member.position,
			"posture": member.posture, "order": row.get("_mercenaryOrder", "follow"), "status": record.status,
			"action": copied(core.get_action(member_id)), "queue": copied(core.get_queue(member_id)),
			"movement": movement_snapshot(), "safe_exit": copied(row.get("_mercenarySafeExit")),
			"rally": copied(row.get("_mercenaryRally")), "move": copied(row.get("_mercenaryMove")),
			"follow_speed": row.get("_followSpeed", 0), "effect_count": effect_count}

	func replay(operation: String, input: Dictionary) -> Variant:
		match operation:
			"initial": pass
			"fixture_provider_policy": provider_policy.merge(input, true)
			"fixture_member_position": owner.c = input.c; owner.r = input.r
			"set_player_position": hero.position = {"x": float(input.c)*4.1, "y": 0, "z": float(input.r)*4.1}
			"document.hidden": hidden = input.value; return input.value
			"resetMovementClock": movement.reset_movement_clock()
			"fixture.tick":
				seconds += float(input.clock_increment_seconds)
				movement.tick(float(input.api_tick_argument))
			"api.tick": movement.tick(float(input.dt))
			"follow": return movement.follow()
			"rally": return movement.rally(input.point)
			"cancelCommand": return movement.cancel_command(str(input.memberId))
			"command":
				targets[input.target.id] = input.target.duplicate(true)
				var result: Dictionary = core.command(member_id, input.kind, input.target.id)
				# Exact source wrapper success strings; never copy expected status or receipt.
				if result.get("ok") == true:
					result.message = "Задача добавлена в очередь · %s" % str(result.get("queuePosition")) if result.get("queued", false) else "Приказ принят."
				return result
			"resolve_receipt":
				var target: Variant = targets.get(input.targetId)
				if target is Dictionary: target.locked = not input.ok
				if not pending_by_target.has(input.targetId):
					bridge_errors.append({"kind": "missing_pending_request", "targetId": input.targetId})
				else:
					# Source fixture snapshots after two Promise microtasks. The supplied core
					# public resolver represents that same completed-delivery boundary here.
					var receipt: Dictionary = core.resolve_pending(pending_by_target[input.targetId], {"ok": input.ok})
					if receipt.get("reason") == "unknown_request": bridge_errors.append({"kind": "unknown_request", "receipt": receipt})
					pending_by_target.erase(input.targetId)
			_:
				bridge_errors.append({"kind": "unsupported_operation", "operation": operation})
		return null

	static func copied(value: Variant) -> Variant:
		return value.duplicate(true) if value is Dictionary or value is Array else value

func run(CoreScript: Variant, MovementScript: Variant, oracle: Dictionary) -> Dictionary:
	_failures = []
	_comparisons = 0
	var trace: Array = []
	var completed_cases: Array = []
	var total_steps: int = 0
	var cases: Array = oracle.get("cases", [])
	_compare("walk.movement.world_commands_source.v1", oracle.get("schema"), "oracle.schema")
	_compare(10, cases.size(), "oracle.case_count")
	for case_value: Variant in cases:
		var case_data: Dictionary = case_value
		var case_id: String = str(case_data.id)
		var before_failures: int = _failures.size()
		var bridge: WorldBridge = WorldBridge.new()
		bridge.configure(CoreScript, MovementScript, case_data)
		var rows: Array = []
		var steps: Array = case_data.steps
		for step_value: Variant in steps:
			var step: Dictionary = step_value
			var input: Dictionary = step.input.duplicate(true)
			var cursor: int = bridge.calls.size()
			var owner_cursor: int = bridge.owner_commits.size()
			var result: Variant = bridge.replay(str(step.operation), input)
			var snapshot: Dictionary = bridge.snapshot()
			var calls: Array = bridge.calls.slice(cursor).duplicate(true)
			var location: String = "%s.steps[%d]" % [case_id, rows.size()]
			_compare(step.result, result, location + ".result")
			_compare(step.snapshot, snapshot, location + ".snapshot")
			_compare(step.provider_calls, calls, location + ".provider_calls")
			for forbidden: String in ["position", "r", "c"]:
				_compare(false, bridge.row.has(forbidden), location + ".policy_wrote_row_" + forbidden)
			rows.append({"operation": step.operation, "input": input, "result": WorldBridge.copied(result),
				"snapshot": snapshot, "provider_calls": calls,
				"simulated_owner_commits": bridge.owner_commits.slice(owner_cursor).duplicate(true)})
			total_steps += 1
		_compare([], bridge.bridge_errors, case_id + ".bridge_errors")
		if before_failures == _failures.size(): completed_cases.append(case_id)
		trace.append({"case_id": case_id, "steps": rows})
		bridge.movement.dispose()
		bridge.movement = null
		bridge.core = null
		bridge.pending_objects.clear()
	_compare(546, total_steps, "oracle.total_steps")
	return {"schema": "walk.movement.world_native_comparison.v1", "status": "PASS" if _failures.is_empty() else "FAIL",
		"utility_origin": "Gameplay author-origin diagnostic utility", "author_validation": AUTHOR_VALIDATION,
		"owner_kind": "simulated owner; NOT actual physics or production host validation",
		"scope": "10 source VM command/movement cases; supplied native core/policy under deterministic owner callbacks",
		"case_count": cases.size(), "step_count": total_steps, "comparisons": _comparisons,
		"completed_cases": completed_cases, "failures": _failures.duplicate(true), "trace": trace,
		"source_files": WorldBridge.copied(oracle.get("source_files", [])), "numeric_absolute_tolerance": TOLERANCE}

func _compare(expected: Variant, actual: Variant, location: String) -> void:
	_comparisons += 1
	if (expected is int or expected is float) and (actual is int or actual is float):
		if not is_finite(float(expected)) or not is_finite(float(actual)) or absf(float(expected)-float(actual)) > TOLERANCE:
			_mismatch(location, expected, actual, "number")
		return
	if typeof(expected) != typeof(actual):
		_mismatch(location, expected, actual, "type")
		return
	if expected is Dictionary:
		var expected_keys: Array = expected.keys()
		var actual_keys: Array = actual.keys()
		expected_keys.sort(); actual_keys.sort()
		_compare(expected_keys, actual_keys, location + ".keys")
		for key: Variant in expected_keys:
			if actual.has(key): _compare(expected[key], actual[key], location + "." + str(key))
	elif expected is Array:
		if expected.size() != actual.size(): _mismatch(location + ".length", expected.size(), actual.size(), "array_length")
		for index: int in range(mini(expected.size(), actual.size())):
			_compare(expected[index], actual[index], "%s[%d]" % [location, index])
	elif expected != actual:
		_mismatch(location, expected, actual, "value")

func _mismatch(location: String, expected: Variant, actual: Variant, reason: String) -> void:
	_failures.append({"path": location, "reason": reason, "expected": WorldBridge.copied(expected), "actual": WorldBridge.copied(actual)})
