extends RefCounted
## Lease adapter for the actual controlled-scene movement owner and actual
## imported model AnimationMixers. No dummy process/scheduler or actor clone.
const IDENTITY_FIELDS := ["session_id","source_id","render_id","bridge_id",
	"descriptor_sha256","placement_mode","life_generation","rig_epoch",
	"body_instance_id","body_rid","rig_instance_id"]
var _world: Node3D
var _movement: RefCounted
var _current: Callable
var _configured := false
var _disposed := false
var _busy := false
var _serial := 0
var _leases: Dictionary = {}

func configure(world: Node3D, movement: RefCounted, physical_life_current: Callable) -> bool:
	if _configured or _disposed or not Thread.is_main_thread() or not is_instance_valid(world) \
		or not world.is_inside_tree() or movement == null or not physical_life_current.is_valid(): return false
	for method: String in ["source_body","model_metadata","is_local"]:
		if not world.has_method(method): return false
	for method: String in ["acquire_writer_lease","writer_lease_current","release_writer_lease"]:
		if not movement.has_method(method): return false
	_world = world
	_movement = movement
	_current = physical_life_current
	_configured = true
	return true

func providers() -> Dictionary:
	return {"acquire_writers":Callable(self,"acquire_writers"),
		"writers_current":Callable(self,"writers_current"),"release_writers":Callable(self,"release_writers")}

func _ready() -> bool:
	return _configured and not _disposed and Thread.is_main_thread() and is_instance_valid(_world) \
		and _world.is_inside_tree() and _world.is_local() and is_instance_valid(_movement) and _current.is_valid()

func _same_binding(a: Dictionary, b: Dictionary) -> bool:
	for key: String in IDENTITY_FIELDS:
		if not a.has(key) or not b.has(key) or typeof(a[key]) != typeof(b[key]) or a[key] != b[key]: return false
	return true

func _actor(binding: Dictionary) -> Dictionary:
	if not _ready() or _current.call(binding.duplicate()) != true: return {}
	var source_id: Variant = binding.get("source_id")
	if not source_id is String: return {}
	var body: Variant = _world.player if source_id == "player" else _world.source_body(source_id)
	if not body is CharacterBody3D or not is_instance_valid(body) or not body.is_inside_tree() \
		or body.is_queued_for_deletion() or body.get_instance_id() != binding.get("body_instance_id") \
		or body.get_rid() != binding.get("body_rid"): return {}
	var metadata: Dictionary = _world.model_metadata(source_id)
	var model: Variant = metadata.get("model")
	var rig: Variant = metadata.get("skeleton")
	if not model is Node3D or not is_instance_valid(model) or not model.is_inside_tree() \
		or not rig is Skeleton3D or not is_instance_valid(rig) or not rig.is_inside_tree() \
		or not body.is_ancestor_of(model) or not model.is_ancestor_of(rig) \
		or rig.get_instance_id() != binding.get("rig_instance_id"): return {}
	# No such modifier is present in the verified imported hero. Do not silently
	# claim suspension if a future external bone writer appears in that model.
	for modifier: Node in model.find_children("*","SkeletonModifier3D",true,false):
		if modifier.get("active") != false: return {}
	return {"body":body,"model":model,"rig":rig}

func acquire_writers(binding: Dictionary) -> Dictionary:
	if _busy: return {"ok":false,"reason":"writer_bridge_busy"}
	_busy = true
	var actor := _actor(binding)
	if actor.is_empty(): _busy = false; return {"ok":false,"reason":"actual_binding_required"}
	var key := str(actor.body.get_instance_id())
	if _leases.has(key): _busy = false; return {"ok":false,"reason":"body_already_leased"}
	var mixers: Array = []
	for node: Node in actor.model.find_children("*","AnimationMixer",true,false):
		var active: Variant = node.get("active")
		if not active is bool: _busy = false; return {"ok":false,"reason":"unknown_animation_writer"}
		mixers.append({"node":node,"active":active})
	_serial += 1
	var lease_id := "physical-writers:%s:%s" % [get_instance_id(),_serial]
	if not _movement.acquire_writer_lease(actor.body,lease_id):
		_busy = false; return {"ok":false,"reason":"actual_movement_lease_rejected"}
	var lease := {"binding":binding.duplicate(),"body":actor.body,"model":actor.model,"rig":actor.rig,
		"rid":actor.body.get_rid(),"lease_id":lease_id,"mixers":mixers}
	_leases[key] = lease
	for mixer: Dictionary in mixers: mixer.node.set("active",false)
	var valid := _lease_current(lease,binding,lease_id)
	if not valid:
		_cleanup(lease,"acquire_rolled_back")
	_busy = false
	return {"ok":true,"binding":binding.duplicate(),"lease_id":lease_id} if valid \
		else {"ok":false,"reason":"writer_suspension_not_current"}

func _lease_current(lease: Dictionary, binding: Dictionary, lease_id: String) -> bool:
	if lease.get("lease_id") != lease_id or not _same_binding(lease.binding,binding): return false
	var actor := _actor(binding)
	if actor.is_empty() or not is_same(actor.body,lease.body) or not is_same(actor.model,lease.model) \
		or not is_same(actor.rig,lease.rig) or not _movement.writer_lease_current(lease.body,lease_id): return false
	var current_mixers: Array[Node] = actor.model.find_children("*","AnimationMixer",true,false)
	if current_mixers.size() != lease.mixers.size(): return false
	for index: int in current_mixers.size():
		var saved: Dictionary = lease.mixers[index]
		if not is_instance_valid(saved.node) or not is_same(current_mixers[index],saved.node) \
			or saved.node.get("active") != false: return false
	return true

func writers_current(binding: Dictionary, lease_id: String) -> bool:
	if not _ready() or _busy: return false
	var key := str(binding.get("body_instance_id",0))
	if not _leases.has(key): return false
	_busy = true
	var result := _lease_current(_leases[key],binding,lease_id)
	_busy = false
	return result

func release_writers(binding: Dictionary, lease_id: String, reason: String) -> bool:
	if not _ready() or _busy: return false
	var key := str(binding.get("body_instance_id",0))
	if not _leases.has(key): return false
	_busy = true
	var lease: Dictionary = _leases[key]
	var result := _lease_current(lease,binding,lease_id) and _cleanup(lease,reason)
	_busy = false
	return result

func _cleanup(lease: Dictionary, reason: String) -> bool:
	# Called only for this saved lease. Even stale-life teardown cannot touch a
	# replacement body/RID or a replacement model's animation writers.
	var body: Variant = lease.body
	if not is_instance_valid(body) or body.get_rid() != lease.rid: return false
	if not _movement.release_writer_lease(body,lease.lease_id,reason): return false
	for saved: Dictionary in lease.mixers:
		var node: Variant = saved.node
		if is_instance_valid(node) and is_instance_valid(lease.model) and is_instance_valid(lease.rig) \
			and body.is_ancestor_of(lease.model) and lease.model.is_ancestor_of(lease.rig) \
			and lease.model.is_ancestor_of(node) and node.get("active") == false:
			node.set("active",saved.active)
	_leases.erase(str(body.get_instance_id()))
	return true

func dispose(reason: String = "source_retired") -> Dictionary:
	if _disposed: return {"ok":true}
	if _busy or not Thread.is_main_thread(): return {"ok":false,"reason":"writer_bridge_busy"}
	# Life authority must be revoked and pose manager disposed first. A live
	# ragdoll cannot lose its actual movement/animation suspension silently.
	for lease: Dictionary in _leases.values():
		if _current.is_valid() and _current.call(lease.binding.duplicate()) == true:
			return {"ok":false,"reason":"live_physical_lease_requires_retirement"}
	_busy = true
	for key: Variant in _leases.keys():
		if not _cleanup(_leases[key],reason):
			_busy = false; return {"ok":false,"reason":"original_lease_cleanup_failed"}
	_disposed = true
	_configured = false
	_world = null
	_movement = null
	_current = Callable()
	_busy = false
	return {"ok":true}

func evidence() -> Dictionary:
	var leases: Array = []
	for lease: Dictionary in _leases.values():
		leases.append({"binding":lease.binding.duplicate(),"lease_id":lease.lease_id,
			"body_instance_id":lease.binding.body_instance_id,"animation_writers":lease.mixers.size(),
			"current":writers_current(lease.binding,lease.lease_id)})
	return {"configured":_configured,"disposed":_disposed,"leases":leases,"native_validation":"NOT_RUN"}
