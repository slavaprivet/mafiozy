extends Node3D
## Single BUILD-owned composition of original core, actual ownership host,
## source UI/badges and transactional persistence. Controlled hiring fixture
## only; no replacement of original286, production motion or shared boarding.
const World = preload("res://scripts/gang/fixture_world.gd")
const Squad = preload("res://addons/walk_mercenary/mercenary_squad.gd")
const Host = preload("res://addons/walk_mercenary_host/mercenary_host.gd")
const RecruitUI = preload("res://scripts/gang/ui/mercenary_recruit_ui.gd")
const RecruitmentHostView = preload("res://scripts/gang/recruitment_host_view.gd")
const InteractionContext = preload("res://scripts/gang/interaction_context.gd")
const Badges = preload("res://scripts/gang/ui/mercenary_badges.gd")
const RenderOcclusion = preload("res://scripts/gang/ui/render_occlusion.gd")
const PersistenceOwner = preload("res://scripts/gang/persistence_owner.gd")
const SourceHero = preload("res://assets/hero.glb")
const CommitmentCheckpoint = preload("res://scripts/gang/commitment_checkpoint.gd")
const Movement = preload("res://addons/walk_mercenary/mercenary_movement.gd")
const PhysicalMovement = preload("res://scripts/gang/physical_movement_owner.gd")
const PhysicalTargets = preload("res://scripts/gang/physical_targets_owner.gd")
const PhysicalLife = preload("res://scripts/gang/physical_life_owner.gd")
const PhysicalWriterBridge = preload("res://scripts/gang/physical_writer_bridge.gd")
const PhysicalPoseManager = preload("res://scripts/gang/gang_pose_manager.gd")
const CommandUI = preload("res://scripts/gang/ui/mercenary_command_ui.gd")
const Selection = preload("res://scripts/gang/ui/mercenary_selection_view.gd")
const TaskMarkers = preload("res://scripts/gang/ui/mercenary_task_markers.gd")
const ActionTimers = preload("res://scripts/gang/ui/mercenary_action_timers.gd")

var world: Node3D
var core: RefCounted
var host: RefCounted
var persistence: RefCounted
var camera: Camera3D
var recruitment_ui: Control
var recruitment_host_view: RefCounted
var badges: Control
var occlusion: RefCounted
var hud: CanvasLayer
var toolbar: HBoxContainer
var status_label: Label
var stage_geometry: Node3D
var checkpoint := CommitmentCheckpoint.new()
var physical := PhysicalMovement.new()
var movement: RefCounted
var targets: Node3D
var life: RefCounted
var pose_manager: RefCounted
var writer_bridge: RefCounted
var pose_last_receipt: Dictionary = {}
var _qa_patient_event := ""
var _qa_patient_sequence := 0
var command_ui: Control
var selection: Node
var task_markers: Control
var action_timers: Control
var _pressed: Dictionary = {}
var _camera_yaw := 0.0
var _reconcile_pending := false
var _reconcile_clock := 0.0
var interaction_context := InteractionContext.new()
var _talk_clock := 0.2
var _talk_target: Dictionary = {}
var _owned := false
var ready_for_acceptance := false
var setup_error := ""

func _ready() -> void:
	get_window().focus_exited.connect(release_transport_controls)
	_build_stage()
	world = World.new()
	world.name = "PhysicalRegistry"
	add_child(world)
	var positions: Array = [Vector3(-1.7,0,-0.8),Vector3(0,0,-0.8),Vector3(1.7,0,-0.8),
		Vector3(-1.7,0,-2),Vector3(0,0,-2),Vector3(1.7,0,-2)]
	if not world.setup(SourceHero,Vector3.ZERO,positions,4.1,_fixture_resident_ids()):
		_fail_setup(world.last_error)
		return
	_owned = true
	if not physical.configure(world,Callable(self,"_current_host")):
		_fail_setup("physical owner configure failed")
		return
	occlusion = RenderOcclusion.new()
	occlusion.set_roots([stage_geometry,world])
	persistence = PersistenceOwner.new()
	if not checkpoint.configure(Callable(self,"_current_core"),Callable(self,"_current_host"),
		Callable(self,"_save_checkpoint")):
		_fail_setup("checkpoint configure failed")
		return
	var options: Dictionary = world.provider_options()
	options.persist = Callable(checkpoint,"persist")
	options.merge({"get_target":Callable(self,"_get_physical_target"),
		"get_npc":Callable(self,"_get_npc"),"get_player_target":Callable(self,"_get_player_target"),
		"perform_effect":Callable(self,"_perform_effect"),
		"move_member":Callable(self,"_move_member"),"on_action":Callable(self,"_member_action"),
		"get_member_motion":Callable(self,"_member_motion"),
		"can_start_queued":Callable(self,"_can_start_queued"),
		"can_auto_revive":Callable(self,"_can_auto_revive"),
		"order_follow":Callable(self,"_order_follow"),"order_rally":Callable(self,"_order_rally"),
		"order_cancel":Callable(self,"_order_cancel"),"clear_focus":Callable(self,"_clear_focus"),
		"hospitalize_member":Callable(self,"_hospitalize_member"),
		"discharge_member":Callable(self,"_discharge_member"),
		"revive_member":Callable(self,"_revive_member"),"revive_player":Callable(self,"_revive_player"),
		"is_revive_blocked":Callable(self,"_is_revive_blocked"),
		"intimidate_npc":Callable(self,"_intimidate_npc")},true)
	host = Host.new(options)
	core = Squad.new(host.core_options())
	if not host.bind_core(core):
		_fail_setup("host bind failed")
		return
	life = PhysicalLife.new()
	if not life.configure(world,Callable(self,"_current_host"),Callable(self,"_current_core"),physical):
		_fail_setup("physical life configure failed")
		return
	var initial_health: Dictionary = life.initialize_controlled_player_health()
	if initial_health.get("ok") != true \
		or not life.register_damage_origin("qa_patient",Callable(self,"_validate_qa_patient")):
		_fail_setup("fresh controlled player health/QA authority configure failed")
		return
	pose_manager = PhysicalPoseManager.new()
	writer_bridge = PhysicalWriterBridge.new()
	if not writer_bridge.configure(world,physical,Callable(pose_manager,"physical_life_current")):
		_fail_setup("actual physical writer bridge configure failed")
		return
	var pose_configuration: Dictionary = pose_manager.configure(world,life,SourceHero,writer_bridge.providers())
	if pose_configuration.get("ok") != true:
		_fail_setup("actual physical pose admission failed: "+str(pose_configuration.get("reason","")))
		return
	var pose_binding: Dictionary = life.bind_pose_provider(pose_manager)
	if pose_binding.get("ok") != true:
		_fail_setup("physical life/pose binding failed: "+str(pose_binding.get("reason","")))
		return
	targets = PhysicalTargets.new()
	targets.name = "SourceProfessionTargets"
	add_child(targets)
	if not targets.configure(world,Callable(self,"_current_host"),Callable(self,"_current_core"),_fixture_save_path()):
		_fail_setup(targets.last_error)
		return
	occlusion.set_roots([stage_geometry,world,targets])
	_bind_movement()
	if not persistence.configure(world,core,host,Squad,Host,_fixture_save_path(),options):
		_fail_setup("persistence configure failed")
		return
	persistence.bindings_changed.connect(_on_bindings_changed)
	persistence.bindings_retiring.connect(_on_bindings_retiring)
	_build_toolbar()
	_rebuild_presentation()
	if not setup_error.is_empty():
		return
	# Inspect existing bytes before enabling the first operation that can autosave.
	# A rejected save stays intact; the source still allows hiring in memory.
	var startup_restore: Dictionary = persistence.load_now()
	if not setup_error.is_empty():
		return
	host.adopt_candidates(true)
	ready_for_acceptance = true
	checkpoint.arm()
	_reconcile_pending = true
	status_label.text = "E — разговор · Отряд — найм и снаряжение" if startup_restore.get("ok",false) else "Сохранение не загружено: "+str(startup_restore.get("error",""))+" · автосохранение заблокировано"

func _fixture_save_path() -> String:
	# QA supplies an isolated path so its controlled fixture never touches a user's save.
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--gang-save-path="):
			return argument.trim_prefix("--gang-save-path=")
	return "user://gang_recruitment_save.json"

func _fixture_resident_ids() -> Array:
	# Seed existing physical identities for genuine original-JS save fixtures.
	# This never edits imported save text or substitutes an unrelated resident.
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--gang-resident-ids="):
			return Array(argument.trim_prefix("--gang-resident-ids=").split(",",false))
	return []

func _build_stage() -> void:
	stage_geometry = Node3D.new()
	stage_geometry.name = "ControlledStageGeometry"
	add_child(stage_geometry)
	var floor_mesh := PlaneMesh.new()
	floor_mesh.size = Vector2(64,64)
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.24,0.27,0.25)
	material.roughness = 1.0
	var ground := MeshInstance3D.new()
	ground.name = "FixtureGround"
	ground.mesh = floor_mesh
	ground.material_override = material
	stage_geometry.add_child(ground)
	# The source action station requires real support and collision, not a mesh
	# standing in for a passability provider. Top surface is exactly y=0 metres.
	var floor_body := StaticBody3D.new()
	floor_body.name = "PhysicalGround"
	floor_body.set_meta("nativeTerrainKind","ground")
	var floor_shape := CollisionShape3D.new()
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(64,.2,64)
	floor_shape.shape = floor_box
	floor_shape.position.y = -.1
	floor_body.add_child(floor_shape)
	stage_geometry.add_child(floor_body)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50,-30,0)
	light.light_energy = 1.5
	light.shadow_enabled = true
	add_child(light)
	var environment_node := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.08,0.11,0.14)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.72,0.76,0.85)
	environment.ambient_light_energy = 0.65
	environment_node.environment = environment
	add_child(environment_node)
	camera = Camera3D.new()
	camera.name = "AcceptanceCamera"
	add_child(camera)
	camera.position = Vector3(0,5,3.8)
	# Controlled fixture framing keeps the source talk hint clear of the back row.
	camera.fov = 40.0
	camera.look_at(Vector3(0,0.8,-1.2))
	camera.current = true
	hud = CanvasLayer.new()
	hud.name = "SourceGangPresentation"
	add_child(hud)

func _build_toolbar() -> void:
	toolbar = HBoxContainer.new()
	toolbar.name = "FixtureActions"
	toolbar.position = Vector2(18,18)
	toolbar.add_theme_constant_override("separation",12)
	hud.add_child(toolbar)
	for action in [["Отряд",Callable(self,"_open_roster")],
		["Приказы",Callable(self,"_open_commands")],
		["Сохранить",Callable(self,"_save_clicked")],["Загрузить",Callable(self,"_load_clicked")]]:
		var button := Button.new()
		button.text = action[0]
		button.pressed.connect(action[1])
		toolbar.add_child(button)
	status_label = Label.new()
	status_label.position = Vector2(18,62)
	hud.add_child(status_label)
	var scope_label := Label.new()
	scope_label.text = "Общая сцена переноса · WASD · Shift · X — действие · V — за мной"
	scope_label.position = Vector2(18,88)
	hud.add_child(scope_label)

func _rebuild_presentation() -> void:
	_dispose_commands()
	if is_instance_valid(recruitment_ui):
		recruitment_ui.dispose()
		hud.remove_child(recruitment_ui)
		recruitment_ui.queue_free()
	if is_instance_valid(badges):
		badges.dispose()
		hud.remove_child(badges)
		badges.queue_free()
	badges = Badges.new()
	badges.name = "OriginalGangBadges"
	hud.add_child(badges)
	recruitment_ui = RecruitUI.new()
	recruitment_ui.name = "OriginalRecruitmentUI"
	hud.add_child(recruitment_ui)
	recruitment_host_view = RecruitmentHostView.new(host,world)
	var ui_receipt: Dictionary = recruitment_ui.configure(recruitment_host_view,{
		"begin_conversation":Callable(host,"begin_conversation"),
		"end_conversation":Callable(host,"end_conversation"),
		"get_talk_target":Callable(self,"_get_talk_target"),
		"is_blocked":Callable(self,"_external_blocked"),
		"has_priority_interaction":Callable(interaction_context,"has_priority_interaction"),
		"is_transport_interaction":Callable(interaction_context,"transport_interaction")})
	var badge_receipt: Dictionary = badges.configure(camera,{
		"get_actors":Callable(host,"presentation_actors"),
		"get_focus":Callable(self,"_focus_position"),
		"get_talk_id":Callable(self,"_get_talk_id"),
		"hide_owned":Callable(self,"_hide_owned"),
		"get_hud_rects":Callable(self,"_hud_rects"),
		"wall_clock_ms":Callable(self,"_wall_clock_ms"),
		"occluded":Callable(occlusion,"occluded")},null)
	# null reproduces mercenary_walk.mjs:28: optional proximity ring is inactive.
	if not ui_receipt.get("ok",false) or not badge_receipt.get("ok",false):
		_fail_setup("presentation configuration rejected")
		return
	_build_commands()

func _focus_position() -> Vector3:
	return world.player.global_position

func _wall_clock_ms() -> float:
	return world.now()*1000.0

func _hide_owned() -> bool:
	# Visual hiding follows live source vehicle state, not the post-exit key latch.
	return interaction_context.vehicle_context()

func _external_blocked() -> bool:
	return not ready_for_acceptance or interaction_context.transport_interaction() \
		or (is_instance_valid(command_ui) and command_ui.blocks_world_input())

func configure_interaction_providers(providers: Dictionary) -> bool:
	return interaction_context.configure(providers)

func reserve_transport_e_press() -> void:
	# Actual transport owner calls this before its own synchronous state change.
	interaction_context.reserve_e_press()

func release_transport_controls() -> void:
	# Walk blur/releaseControls: a missing keyup must not retain the old gesture.
	interaction_context.release_controls()
	_pressed.clear()
	physical.stop_player()
	if is_instance_valid(recruitment_ui) and recruitment_ui.has_method("release_transport_controls"):
		recruitment_ui.release_transport_controls()

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT:
		release_transport_controls()

func _input(event: InputEvent) -> void:
	interaction_context.observe_key(event)
	# Never consume the vehicle owner's E gesture here.
	if event is InputEventKey and not event.echo:
		var key: int = event.physical_keycode if event.physical_keycode != 0 else event.keycode
		if key in [KEY_W,KEY_A,KEY_S,KEY_D,KEY_SHIFT]:
			if not event.pressed:
				_pressed.erase(key)
			elif not _world_input_blocked() and not event.ctrl_pressed and not event.alt_pressed and not event.meta_pressed:
				_pressed[key] = true
	if event is InputEventMouseMotion and not _world_input_blocked() \
		and (event.button_mask & MOUSE_BUTTON_MASK_RIGHT) != 0:
		_camera_yaw -= event.relative.x*.003

func _hud_rects() -> Array:
	var rectangles: Array = recruitment_ui.hud_rects() if is_instance_valid(recruitment_ui) else []
	if is_instance_valid(toolbar):
		rectangles.append(toolbar.get_global_rect())
	if is_instance_valid(command_ui):
		rectangles.append_array(command_ui.hud_rects())
	return rectangles

func _get_talk_id() -> Variant:
	if interaction_context.transport_interaction():
		return null
	return _talk_target.get("id")

func _get_talk_target() -> Dictionary:
	_refresh_talk_target()
	return _talk_target

func _refresh_talk_target() -> void:
	_talk_target.clear()
	if not ready_for_acceptance or interaction_context.transport_interaction() or recruitment_ui.blocks_world_input():
		return
	# Source mercenary_walk nearestOwnMember: first five, 2.5 horizontal metres,
	# +/-1.5 vertical metres, live status, projected bounds, score and line of sight.
	var focus: Vector3 = _focus_position()
	var roster: Dictionary = host.get_roster()
	var owned: Array = []
	for row: Dictionary in roster.members.slice(0,5):
		var live: Variant = host.get_member(str(row.id))
		var body: Node3D = host.get_actor(str(row.id))
		if not live is Dictionary or not is_instance_valid(body) or not body.is_visible_in_tree():
			continue
		var point := Vector3(float(live.position.x),float(live.position.y),float(live.position.z))
		var metres := Vector2(point.x-focus.x,point.z-focus.z).length()
		if metres>2.5 or absf(point.y-focus.y)>1.5 or float(live.hp)<=0 or live.dead or live.downed or not live.available:
			continue
		var talk_point := point+Vector3.UP*1.2
		var camera_depth := -camera.to_local(talk_point).z
		if camera_depth<camera.near or camera_depth>camera.far:
			continue
		var pixel := camera.unproject_position(talk_point)
		var viewport_size := get_viewport().get_visible_rect().size
		var ndc := Vector2(pixel.x/viewport_size.x*2-1,1-pixel.y/viewport_size.y*2)
		if absf(ndc.x)>0.72 or absf(ndc.y)>0.9:
			continue
		owned.append({"id":str(row.id),"position":point,"body":body,"score":absf(ndc.x)*2+metres})
	owned.sort_custom(func(a:Dictionary,b:Dictionary)->bool:return a.score<b.score)
	for row: Dictionary in owned:
		# Source mercenary_targets.hasLineOfSight excludes the intended actor;
		# another visible actor can block this segment. Hero is excluded by metadata.
		if not occlusion.occluded(focus+Vector3.UP*1.15,row.position+Vector3.UP*1.05,[row.body]):
			_talk_target = {"id":row.id,"member":true}
			return
	# Source world.nearestCandidate is horizontal proximity, not camera selection.
	var candidates: Array = host.candidate_rows()
	candidates.sort_custom(func(a:Dictionary,b:Dictionary)->bool:return a.distanceMeters<b.distanceMeters)
	for row: Dictionary in candidates:
		if row.distanceMeters<=3:
			_talk_target = {"id":str(row.id),"member":false}
			return

func _process(delta: float) -> void:
	if not ready_for_acceptance:
		return
	_talk_clock += maxf(0,delta)
	if _talk_clock>=0.2:
		_talk_clock = 0
		_refresh_talk_target()
	# Source badges/UI own their bounded process cadence; no duplicate advance.

func _physics_process(delta: float) -> void:
	if not ready_for_acceptance:
		return
	_reconcile_clock += maxf(0,delta)
	if _reconcile_pending or (targets.needs_reconciliation_retry() and _reconcile_clock >= 1.0):
		_reconcile_pending = false
		_reconcile_clock = 0.0
		targets.reconcile_restored_pending()
	var direction := Vector3.ZERO
	if not _world_input_blocked():
		direction = Vector3(float(_pressed.has(KEY_D))-float(_pressed.has(KEY_A)),0,
			float(_pressed.has(KEY_S))-float(_pressed.has(KEY_W)))
		direction = Basis(Vector3.UP,_camera_yaw)*direction
	else:
		_pressed.clear()
	physical.advance_player(delta,direction,_pressed.has(KEY_SHIFT))
	# Exactly one core update through the source movement owner -> host.tick.
	movement.tick(delta)
	targets.advance(delta)
	# The physical manager advances its real bodies once, without another core tick.
	# Retire stale medical promises even when old-life completions are suppressed.
	life.retire_stale_pending()
	pose_last_receipt = pose_manager.tick(delta)
	checkpoint.after_update()
	var orbit := Basis(Vector3.UP,_camera_yaw)
	camera.global_position = world.player.global_position+orbit*Vector3(0,5,3.8)
	camera.look_at(world.player.global_position+orbit*Vector3(0,.8,-1.2))

func _current_core() -> RefCounted:
	return core

func _current_host() -> RefCounted:
	return host

func _save_checkpoint() -> Dictionary:
	return persistence.save_now()

func _open_roster() -> void:
	if ready_for_acceptance:
		if is_instance_valid(command_ui):
			command_ui.close()
		recruitment_ui.open_roster()

func _save_clicked() -> void:
	var receipt: Dictionary = persistence.save_now()
	status_label.text = "Сохранено" if receipt.get("ok",false) else "Ошибка сохранения: "+str(receipt.get("error",receipt.get("reason","")))

func _load_clicked() -> void:
	var receipt: Dictionary = persistence.load_now()
	status_label.text = "Загружено" if receipt.get("ok",false) else "Ошибка загрузки: "+str(receipt.get("error",receipt.get("reason","")))

func _on_bindings_retiring(old_host: RefCounted) -> void:
	# Release the actual tracked conversation while its owner is still live.
	# Emitted only after a successful restore; rejected input preserves the UI.
	if is_same(old_host,host) and is_instance_valid(recruitment_ui):
		recruitment_ui.dispose()
	if is_same(old_host,host):
		_dispose_commands()
		if movement != null:
			movement.dispose()
			movement = null

func _on_bindings_changed(next_core: RefCounted,next_host: RefCounted) -> void:
	core = next_core
	host = next_host
	# All old-host holds have ended. Remove their released metadata identities.
	world.prune_released_conversation_rows()
	_bind_movement()
	if is_instance_valid(targets):
		targets.rebind_effects()
	_reconcile_pending = true
	_talk_target.clear()
	_rebuild_presentation()
	checkpoint.arm()

func _bind_movement() -> void:
	if movement != null:
		movement.dispose()
	var options: Dictionary = physical.options()
	options.merge({"is_ready":Callable(self,"_movement_ready"),
		"is_local":Callable(world,"is_local"),"is_hidden":Callable(self,"_is_hidden"),
		"now":Callable(world,"now"),"performance_now_ms":Callable(self,"_performance_now_ms"),
		"update_core":Callable(host,"tick"),"persist":Callable(checkpoint,"persist"),
		"clear_focus":Callable(self,"_clear_focus")},true)
	movement = Movement.new(core,host,options)

func _movement_ready() -> bool:
	return ready_for_acceptance and setup_error.is_empty()

func _is_hidden() -> bool:
	return get_window().mode == Window.MODE_MINIMIZED

func _performance_now_ms() -> float:
	return float(Time.get_ticks_usec())/1000.0

func _move_member(id: String,target: Variant,options: Dictionary) -> void:
	if movement != null:
		movement.on_move_request(id,target,options)
	else:
		physical.stop_body(id,"owner_retired")

func _member_action(id: String,action: Dictionary) -> void:
	if movement != null:
		movement.on_action(id,action)

func _member_motion(id: String) -> Dictionary:
	return movement.get_member_motion(id) if movement != null else {}

func _can_start_queued(id: String) -> bool:
	return movement != null and movement.can_start_queued(id)

func _can_auto_revive(id: String) -> bool:
	return movement != null and movement.can_auto_revive(id)

func _order_follow() -> Dictionary:
	return movement.follow() if movement != null else {"ok":false,"reason":"movement_owner_unavailable"}

func _order_rally(point: Dictionary) -> Dictionary:
	return movement.rally(point) if movement != null else {"ok":false,"reason":"movement_owner_unavailable"}

func _order_cancel(id: String = "") -> Dictionary:
	return movement.cancel_command(id) if movement != null else {"ok":false,"reason":"movement_owner_unavailable"}

func _clear_focus(id: String) -> void:
	var member: Dictionary = host.member_row(id)
	if member.is_empty():
		return
	# mercenary_world.js clearFocus: interruption clears these even without focus.
	for field in ["_mercenarySafeExit","_mercenaryConversation","_mercenaryGreetingUntil"]:
		member.erase(field)
	var focus: Variant = member.get("_mercenaryFocus")
	if not focus is Dictionary or focus.is_empty():
		return
	if is_same(member.get("targetRef"),focus.get("ref")):
		member.targetKind = null
		member.targetRef = null
		member.targetId = null
	member.erase("_mercenaryFocus")
	member._mercenaryDefending = false

func _get_physical_target(id: String) -> Variant:
	return targets.get_target(id) if is_instance_valid(targets) else null

func _perform_effect(effect: Dictionary) -> Variant:
	return targets.perform_effect(effect) if is_instance_valid(targets) else false

func _get_npc(id: String) -> Variant:
	if life != null:
		return life.get_npc(id)
	var source_id := id.trim_prefix("npc:")
	for resident: Dictionary in world.get_residents():
		var actual_id := str(resident.get("id"))
		if source_id == actual_id or source_id == "npc_"+actual_id:
			return resident
	return null

func _get_player_target() -> Variant:
	return life.get_player_target() if life != null else null

func _life_effect(method: String,args: Array) -> Variant:
	if life == null or not life.has_method(method):
		return {"ok":false,"reason":"source_life_owner_unavailable"}
	return life.callv(method,args)

func _hospitalize_member(member: Dictionary,effect: Dictionary) -> Variant:
	return _life_effect("hospitalize_member",[member,effect])

func _discharge_member(member: Dictionary,effect: Dictionary) -> Variant:
	return _life_effect("discharge_member",[member,effect])

func _revive_member(member: Dictionary,effect: Dictionary) -> Variant:
	return _life_effect("revive_member",[member,effect])

func _revive_player(effect: Dictionary) -> Variant:
	return _life_effect("revive_player",[effect])

func _is_revive_blocked(id: String) -> bool:
	return life.is_revive_blocked(id) if life != null else true

func _intimidate_npc(npc: Dictionary,operator: Dictionary,effect: Dictionary) -> Variant:
	return _life_effect("intimidate_npc",[npc,operator,effect])

func qa_place_patient() -> Dictionary:
	# The original showcase's explicit QA operation. No ambient/scripted injury;
	# the source owner validates the actual bruiser and current supported position.
	if not ready_for_acceptance or life == null or not _qa_patient_event.is_empty():
		return {"ok":false,"reason":"qa_patient_scene_unavailable"}
	_qa_patient_sequence += 1
	_qa_patient_event = "controlled-patient:%s:%s" % [get_instance_id(),_qa_patient_sequence]
	var result: Dictionary = life.qa_place_patient({"event_id":_qa_patient_event})
	_qa_patient_event = ""
	checkpoint.after_update()
	return result

func _validate_qa_patient(query: Dictionary) -> bool:
	var context: Variant = query.get("context")
	if not ready_for_acceptance or _qa_patient_event.is_empty() or not context is Dictionary \
		or context.get("event_id") != _qa_patient_event:
		return false
	var member: Dictionary = host.member_row(str(query.get("id","")))
	var record: Variant = core.get_record(str(query.get("id","")))
	return not member.is_empty() and record is Dictionary and record.get("profession") == "bruiser" \
		and is_same(world.registered_actor_body(member),query.get("body"))

func _get_target_ui(id: String) -> Dictionary:
	var value: Variant = host.get_target(id)
	if not value is Dictionary:
		return {}
	var result: Dictionary = value.duplicate()
	if result.get("object") is Node3D:
		return result
	var body: Node3D = host.get_actor(str(result.get("id",id)))
	var npc: Variant = _get_npc(id) if not is_instance_valid(body) else null
	if npc is Dictionary:
		body = npc.get("body") as Node3D
	if id == "player":
		body = world.player
	if not is_instance_valid(body) or not body.is_inside_tree() or not body.is_visible_in_tree():
		return {}
	result.object = body
	result.valid = true
	result.sourceId = str(body.get_meta("sourceBotId",id))
	return result

func _ray_hit() -> Dictionary:
	if not ready_for_acceptance or not is_instance_valid(world.player):
		return {}
	var pixel := get_viewport().get_visible_rect().size*.5
	var origin := camera.project_ray_origin(pixel)
	var end := origin+camera.project_ray_normal(pixel)*80.0
	var query := PhysicsRayQueryParameters3D.create(origin,end,0xFFFFFFFF,
		[(world.player as CharacterBody3D).get_rid()])
	return get_world_3d().direct_space_state.intersect_ray(query)

func _pick_target() -> Dictionary:
	return _target_from_hit(_ray_hit())

func _target_from_hit(hit: Dictionary) -> Dictionary:
	if hit.is_empty():
		return {}
	var node: Node = hit.get("collider") as Node
	var id: String = targets.target_id_for_node(node)
	if not id.is_empty():
		return _get_target_ui(id)
	for member: Dictionary in world.get_gang():
		if is_same(member.get("body"),node):
			return _get_target_ui(str(member.id))
	for resident: Dictionary in world.get_residents():
		if is_same(resident.get("body"),node):
			return _get_target_ui("npc:"+str(resident.id))
	return {}

func _pick_ground() -> Variant:
	var hit := _ray_hit()
	if hit.is_empty() or not _target_from_hit(hit).is_empty() or hit.normal.y < .65:
		return null
	var node: Node = hit.get("collider") as Node
	if is_instance_valid(node) and node.get_meta("nativeTerrainKind","") == "ground":
		return hit.position
	return null

func _command_blocked() -> bool:
	return not ready_for_acceptance or (is_instance_valid(recruitment_ui) and recruitment_ui.blocks_world_input())

func _world_input_blocked() -> bool:
	var focus := get_viewport().gui_get_focus_owner()
	return _external_blocked() or _command_blocked() or focus is LineEdit or focus is TextEdit

func _command_open_changed(_opened: bool) -> void:
	_pressed.clear()
	physical.stop_player()

func _build_commands() -> void:
	selection = Selection.new()
	add_child(selection)
	task_markers = TaskMarkers.new()
	hud.add_child(task_markers)
	action_timers = ActionTimers.new()
	hud.add_child(action_timers)
	command_ui = CommandUI.new()
	hud.add_child(command_ui)
	var receipts := [selection.configure(self),
		task_markers.configure(camera,{"get_focus":Callable(self,"_focus_position"),
			"get_actors":Callable(host,"presentation_actors"),"occluded":Callable(occlusion,"occluded")},self,10),
		action_timers.configure(camera,{"get_host":Callable(self,"_current_host"),
			"get_target":Callable(self,"_get_target_ui"),"get_focus":Callable(self,"_focus_position"),
			"now_seconds":Callable(world,"now")}),
		command_ui.configure(host,{"get_target":Callable(self,"_get_target_ui"),
			"pick_target":Callable(self,"_pick_target"),"pick_ground":Callable(self,"_pick_ground"),
			"is_transport_interaction":Callable(interaction_context,"transport_interaction"),
			"is_blocked":Callable(self,"_command_blocked"),
			"on_open_change":Callable(self,"_command_open_changed"),
			"selection":selection,"task_markers":task_markers,"action_timers":action_timers})]
	for receipt: Dictionary in receipts:
		if receipt.get("ok") != true:
			_fail_setup("command presentation configuration rejected:"+str(receipt.get("reason")))
			return
	# CommandUI owns the one presentation update; root never advances these twice.

func _dispose_commands() -> void:
	for node: Node in [command_ui,task_markers,action_timers,selection]:
		if is_instance_valid(node):
			node.dispose()
			if node.get_parent() != null:
				node.get_parent().remove_child(node)
			node.queue_free()
	command_ui = null
	task_markers = null
	action_timers = null
	selection = null

func _open_commands() -> void:
	if not ready_for_acceptance:
		return
	recruitment_ui.close()
	command_ui.open()

func _fail_setup(message: String) -> void:
	setup_error = message
	ready_for_acceptance = false
	push_error(message)

func _exit_tree() -> void:
	ready_for_acceptance = false
	if life != null:
		life.dispose()
	if pose_manager != null:
		var retired_pose: Dictionary = pose_manager.dispose("scene_exit")
		if retired_pose.get("ok") != true:
			push_error("Physical pose retirement failed: "+str(retired_pose.get("reason","")))
	if writer_bridge != null:
		var retired_writers: Dictionary = writer_bridge.dispose("scene_exit")
		if retired_writers.get("ok") != true:
			push_error("Physical writer retirement failed: "+str(retired_writers.get("reason","")))
	_dispose_commands()
	if movement != null:
		movement.dispose()
	if is_instance_valid(targets):
		targets.dispose()
	if is_instance_valid(recruitment_ui):
		recruitment_ui.dispose()
	if is_instance_valid(badges):
		badges.dispose()
	if occlusion != null:
		occlusion.dispose()
	if host != null:
		host.dispose()
	if persistence != null:
		persistence.dispose()
	checkpoint.dispose()
	physical.dispose()
	interaction_context.dispose()
	# Fixture owns only its actors; scene tree owns teardown after host callbacks stop.
