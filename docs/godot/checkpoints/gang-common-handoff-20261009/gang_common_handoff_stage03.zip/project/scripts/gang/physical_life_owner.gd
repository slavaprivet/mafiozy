extends RefCounted
## Controlled local health authority. Pose owns physical down/recovery; this
## owner never acknowledges recovery before its actual physical commit.
const Squad = preload("res://addons/walk_mercenary/mercenary_squad.gd")
var _world: Node3D
var _get_host: Callable
var _get_core: Callable
var _movement: RefCounted
var _player: CharacterBody3D
var _configured := false
var _disposed := false
var _last_receipt: Dictionary = {}
var _session := ""
var _origins: Dictionary = {}
var _lives: Dictionary = {}
var _events: Dictionary = {}
var _pose: RefCounted
var _pending: Dictionary = {}
var _busy := false
var _player_initialized := false

func configure(world: Node3D, get_host: Callable, get_core: Callable,
		physical_movement_owner: RefCounted) -> bool:
	if _configured or _disposed or not is_instance_valid(world) or not world.is_inside_tree() \
		or not get_host.is_valid() or not get_core.is_valid() or physical_movement_owner == null:
		return false
	for method: String in ["is_local","get_residents","get_gang","original_residents",
		"registered_actor_body","original_resident","source_body","model_metadata"]:
		if not world.has_method(method):
			return false
	if not world.player is CharacterBody3D or not _live_body(world.player):
		return false
	var originals: Array = world.original_residents()
	if originals.is_empty():
		return false
	for row: Variant in originals:
		if not row is Dictionary or not row.get("id") is String \
			or not is_same(world.original_resident(row.id),row) \
			or not _live_body(world.registered_actor_body(row)):
			return false
	var host: Variant = get_host.call()
	var core: Variant = get_core.call()
	if not host is Object or not is_instance_valid(host) or not host.has_method("member_row") \
		or not core is Object or not is_instance_valid(core):
		return false
	for method: String in ["get_record","stats","get_action","get_roster"]:
		if not core.has_method(method):
			return false
	for method: String in ["get_member_position","stop_body","ground_height","placement_ready",
		"placement_query_point","placement_body_clear","placement_inside_building","placement_blocks_vehicle"]:
		if not physical_movement_owner.has_method(method):
			return false
	_world = world
	_player = world.player
	_get_host = get_host
	_get_core = get_core
	_movement = physical_movement_owner
	_session = "controlled-life:%s:%s" % [world.get_instance_id(),Time.get_ticks_usec()]
	_configured = true
	return true

func options() -> Dictionary:
	var callbacks: Dictionary = {}
	for method: String in ["get_npc","get_player_target","revive_member","revive_player",
		"intimidate_npc","is_revive_blocked","hospitalize_member","discharge_member"]:
		callbacks[method] = Callable(self,method)
	return callbacks

func _ready() -> bool:
	return _configured and not _disposed and is_instance_valid(_world) \
		and _world.is_inside_tree() and _world.is_local() and _get_host.is_valid() \
		and _get_core.is_valid() and _live_body(_player) and is_same(_world.player,_player)

func _live_body(value: Variant) -> bool:
	return value is CharacterBody3D and is_instance_valid(value) and value.is_inside_tree() \
		and not value.is_queued_for_deletion() and value.global_position.is_finite()

func _member(id: String) -> Dictionary:
	if not _ready():
		return {}
	var host: Variant = _get_host.call()
	var core: Variant = _get_core.call()
	if not host is Object or not is_instance_valid(host) or not core is Object or not is_instance_valid(core):
		return {}
	var row: Variant = host.member_row(id)
	if not row is Dictionary or row.get("id") != id or core.get_record(id) == null \
		or not _live_body(_world.registered_actor_body(row)):
		return {}
	for actual: Variant in _world.get_gang():
		if is_same(actual,row):
			return row
	return {}

func get_npc(id: String) -> Variant:
	if not _ready():
		return null
	# Source findNpc accepts npc: plus the original/raw npc_ alias. Do not
	# invent the unavailable browser _threeNpcEntityId renderer mapping.
	var key := id.trim_prefix("npc:")
	for row: Dictionary in _world.get_residents():
		if key != str(row.id) and key != "npc_"+str(row.id):
			continue
		if is_same(_world.original_resident(str(row.id)),row) \
			and _live_body(_world.registered_actor_body(row)):
			return row # Borrowed original Dictionary, never a diagnostic copy.
	return null

func get_player_target() -> Variant:
	if not _ready():
		return null
	# These are only read when an actual owner has written all three fields.
	# The current fixture does not provide that owner. No 80/100 HP fallback.
	if not _number(_player.get_meta("hp",null)) or not _number(_player.get_meta("max_hp",null)) \
		or not _player.get_meta("dead",null) is bool or float(_player.get_meta("max_hp")) <= 0:
		_reject("player_health_owner_missing")
		return null
	var point := _point(_player.global_position)
	var dead: bool = _player.get_meta("dead")
	return {"id":"player","kind":"player","object":_player,"position":point,
		"hp":0.0 if dead else float(_player.get_meta("hp")),"maxHp":float(_player.get_meta("max_hp")),
		"dead":false,"downed":dead,"revivable":dead and _pose != null and _player_initialized and _player_emergency_clear(),
		"unavailableReason":"player_health_recovery_owner_missing" if _pose == null else ""}

func is_revive_blocked(id: String) -> bool:
	# Source createMercenaryVehicleExplosionOwner.isReviveBlocked is this
	# explicit fatal-life flag, not generic dead/hp-zero. Never clear it here.
	var row := _member(id)
	return not row.is_empty() and bool(row.get("_mercenaryVehicleExplosionFatal",false))

func revive_member(row: Dictionary, effect: Dictionary) -> Variant:
	var actual := _member(str(row.get("id","")))
	if actual.is_empty() or not is_same(row,actual) or effect.get("targetId") != actual.id:
		return _reject("member_identity_unavailable")
	if is_revive_blocked(actual.id):
		return _reject("fatal_life_revive_blocked")
	var record: Variant = _get_core.call().get_record(actual.id)
	if record.status == "hospital" or not _number(actual.get("hp")) or float(actual.hp) > 0:
		return _reject("member_not_revivable")
	var fraction: Variant = _medic_fraction(effect)
	if fraction == null or not _number(actual.get("max_hp")) or float(actual.max_hp) <= 0:
		return _reject("medical_stats_unavailable")
	return _recover(actual.id,effect,maxf(1.0,floorf(float(actual.max_hp)*float(fraction)+.5)))

func revive_player(effect: Dictionary) -> Variant:
	if not _ready() or get_player_target() == null:
		return _reject("player_health_owner_missing")
	if effect.get("targetId") != "player" or not bool(_player.get_meta("dead")):
		return _reject("player_not_downed")
	# Even if present, these exclusions cannot replace emergency-owner cleanup.
	for flag: String in ["_ambulanceInTransit","_carriedByAmbulance","_murderPoliceArrest"]:
		if bool(_player.get_meta(flag,false)):
			return _reject("player_emergency_or_arrest")
	if _number(_player.get_meta("myJailIn",null)) and float(_player.get_meta("myJailIn")) > 0:
		return _reject("player_emergency_or_arrest")
	var fraction: Variant = _medic_fraction(effect)
	if fraction == null:
		return _reject("medical_stats_unavailable")
	return _recover("player",effect,maxf(1.0,ceilf(float(_player.get_meta("max_hp"))*float(fraction))))

func _player_emergency_clear() -> bool:
	if not _ready(): return false
	for flag: String in ["_ambulanceInTransit","_carriedByAmbulance","_murderPoliceArrest"]:
		if bool(_player.get_meta(flag,false)): return false
	return not (_number(_player.get_meta("myJailIn",null)) and float(_player.get_meta("myJailIn"))>0)

func intimidate_npc(row: Dictionary, attacker: Dictionary, effect: Dictionary) -> Dictionary:
	var actual: Variant = get_npc(str(effect.get("targetId","")))
	var member := _member(str(effect.get("memberId","")))
	if not actual is Dictionary or not is_same(actual,row) or member.is_empty() or not is_same(member,attacker):
		return _reject("intimidation_identity_unavailable")
	if bool(row.get("dead",false)) or row.get("alive",true) == false \
		or not _number(row.get("hp")) or float(row.hp) <= 0:
		return _reject("npc_not_alive")
	for flag: String in ["_empireBoss","_guard","_invulnerable"]:
		if bool(row.get(flag,false)):
			return _reject("npc_protected")
	return _reject("civilian_panic_movement_owner_missing",{
		"bodyInstanceId":row.body.get_instance_id(),"sourceFearMilliseconds":60000,
		"sourcePanicMilliseconds":8000})

func hospitalize_member(_row: Dictionary, _effect: Dictionary) -> Dictionary:
	return _reject("hospital_seat_life_owner_missing")

func discharge_member(_row: Dictionary, _effect: Dictionary) -> Dictionary:
	return _reject("hospital_door_seat_life_owner_missing")

func register_damage_origin(name: String, validator: Callable) -> bool:
	if not _ready() or name.is_empty() or not validator.is_valid() or _origins.has(name):
		return false
	_origins[name] = validator
	return true

func initialize_controlled_player_health() -> Dictionary:
	if not _ready() or _player_initialized or _player.has_meta("hp") or _player.has_meta("dead") or _player.has_meta("max_hp"):
		return _reject("player_health_already_owned_or_unavailable")
	# world.html24759..24783 fresh local initial state, never a missing-HP fallback.
	_player.set_meta("hp",100.0)
	_player.set_meta("max_hp",100.0)
	_player.set_meta("dead",false)
	_player.set_meta("_localDeath",false)
	_player.set_meta("myDeathBy","")
	_player.set_meta("myDeathLeft",0.0)
	_player_initialized = true
	return {"ok":true,"session_id":_session,"hp":100.0,"max_hp":100.0,"source":"world.html:24759-24783"}

func bind_pose_provider(provider: RefCounted) -> Dictionary:
	if not _ready() or provider == null or _pose != null:
		return _reject("pose_binding_unavailable")
	for method: String in ["down","recover","diagnostics","dispose"]:
		if not provider.has_method(method):
			return _reject("pose_provider_api_missing:"+method)
	_pose = provider
	return {"ok":true,"physical_pose_run":false}

func apply_down(event_id: String) -> Dictionary:
	var proof := physical_event({"event_id":event_id})
	if _pose == null or proof.get("accepted") != true or proof.event.get("medical_downed") != true:
		return _reject("down_pose_provider_or_current_health_event_missing")
	var event: Dictionary = _events[event_id]
	if event.physical_pose_run:
		return {"ok":true,"duplicate":true,"physical_pose_run":true,"event_id":event_id}
	var receipt: Variant = _pose.down(event_id)
	event.physical_receipt = receipt.duplicate(true) if receipt is Dictionary else {"ok":false,"reason":"invalid_pose_receipt"}
	event.physical_pose_run = receipt is Dictionary and receipt.get("ok") == true
	return {"ok":event.physical_pose_run,"event_id":event_id,"physical_pose_run":event.physical_pose_run,"receipt":event.physical_receipt.duplicate(true)}

func revive_handoff(row: Dictionary, effect: Dictionary) -> Variant:
	return revive_player(effect) if effect.get("targetId") == "player" else revive_member(row,effect)

func _actor(id: String) -> Dictionary:
	if not _ready(): return {}
	if id == "player":
		if not _player_initialized: return {}
		return {"id":"player","source_id":"player","body":_player,"hp":_player.get_meta("hp"),
			"max_hp":_player.get_meta("max_hp"),"source_generation":int(_player.get_meta("life_generation",0))}
	var row := _member(id)
	if row.is_empty(): return {}
	return {"id":id,"source_id":str(row.sourceBotId),"body":row.body,"hp":row.get("hp"),
		"max_hp":row.get("max_hp"),"source_generation":row.get("_mercenaryLifeGeneration",0),"row":row}

func actor_life(source_id: String, body: CharacterBody3D) -> Dictionary:
	if not _ready() or not _live_body(body): return {}
	var actor: Dictionary = {}
	if source_id == "player": actor = _actor("player")
	else:
		for row: Dictionary in _world.get_gang():
			if str(row.get("sourceBotId","")) == source_id: actor = _actor(str(row.id)); break
	if actor.is_empty() or not is_same(actor.body,body) or not _number(actor.hp) \
		or not _number(actor.max_hp) or float(actor.max_hp) <= 0 \
		or not actor.source_generation is int or actor.source_generation < 0:
		return {}
	var model: Dictionary = _world.model_metadata(actor.id)
	var rig: Variant = model.get("skeleton")
	if not rig is Skeleton3D or not is_instance_valid(rig) or not rig.is_inside_tree() \
		or not body.is_ancestor_of(rig) or rig.get_bone_count() != 28: return {}
	var key := str(body.get_instance_id())
	if not _lives.has(key):
		_lives[key] = {"body":body,"source_id":source_id,"member_id":actor.id,
			"rig_instance_id":rig.get_instance_id(),"body_rid":body.get_rid(),
			"source_generation":actor.source_generation,"physical_epoch":1,"revision":0,"event_id":""}
		if actor.has("row"): _lives[key]["row"] = actor.row
	var life: Dictionary = _lives[key]
	if not is_same(life.body,body) or life.source_id != source_id or life.member_id != actor.id \
		or life.source_generation != actor.source_generation or life.rig_instance_id != rig.get_instance_id() \
		or life.body_rid != body.get_rid(): return {}
	if actor.has("row") and not is_same(life.get("row"),actor.row): return {}
	var result := life.duplicate()
	result.merge({"session_id":_session,"body_instance_id":body.get_instance_id(),"body_rid":body.get_rid(),
		"hp":actor.hp,"max_hp":actor.max_hp,"downed":float(actor.hp)<=0,"source_authority":false,
		"rig":rig,"rig_instance_id":rig.get_instance_id(),"model_metadata":model.duplicate(),
		"owner_instance_id":get_instance_id(),"life_generation":life.physical_epoch,
		"source_life_generation":life.source_generation,"hp_revision":life.revision},true)
	if actor.has("row"): result["row"] = actor.row # Exact borrowed current host row.
	return result

func damage(id: String, amount: float, context: Dictionary = {}) -> Dictionary:
	if not _ready() or _busy or not is_finite(amount) or amount <= 0 or amount > 2147483647:
		return _reject("invalid_damage_or_lifetime")
	var actor := _actor(id)
	var event_id: String = str(context.get("event_id",""))
	var origin: String = str(context.get("origin",""))
	if actor.is_empty() or event_id.is_empty() or not _origins.has(origin): return _reject("damage_origin_or_actor_missing")
	if _events.has(event_id):
		var old: Dictionary = _events[event_id]
		if old.member_id != id or old.body_instance_id != actor.body.get_instance_id() or old.amount != amount or old.origin != origin:
			return _reject("event_identity_collision")
		return {"ok":true,"duplicate":true,"event":old.duplicate(true),"physical_pose_run":old.get("physical_pose_run",false)}
	var life := actor_life(actor.source_id,actor.body)
	if life.is_empty() or not _number(actor.hp) or float(actor.hp)<=0 or _pending.has(id): return _reject("damage_life_unavailable")
	if id != "player" and (is_revive_blocked(id) or bool(actor.row.get("_mercenaryHospital",false)) or _seated(actor.row)):
		return _reject("damage_external_life_owner")
	_busy = true
	var allowed: Variant = (_origins[origin] as Callable).call({"id":id,"body":actor.body,"amount":amount,"context":context.duplicate(true),"life":life.duplicate()})
	_busy = false
	var fresh := _actor(id)
	if not allowed is bool or not allowed or fresh.is_empty() or not is_same(fresh.body,actor.body) or fresh.hp != actor.hp or fresh.source_generation != actor.source_generation:
		return _reject("damage_origin_rejected_or_changed")
	var dealt := maxf(1.0,float(int(amount)) if id == "player" else floorf(amount+.5))
	var hp := maxf(0.0,float(actor.hp)-dealt)
	var stamp := Time.get_ticks_msec()
	if id == "player":
		_player.set_meta("hp",hp)
		_player.set_meta("_localHpHurtAt",stamp)
		_player.set_meta("_selfHpBarUntil",stamp+4500)
		if hp<=0:
			_player.set_meta("dead",true); _player.set_meta("_localDeath",true)
			_player.set_meta("myDeathBy",origin); _player.set_meta("myDeathLeft",18.0)
	else:
		actor.row.hp = hp
		actor.row._hurtUntil = stamp+360
		if hp<=0:
			actor.row._medicalDowned = true
			actor.row._mercenaryDownAt = stamp
	return _record_health(actor,life,event_id,origin,amount,hp)

func _record_health(actor: Dictionary, life: Dictionary, event_id: String, origin: String, amount: float, hp: float) -> Dictionary:
	var live: Dictionary = _lives[str(actor.body.get_instance_id())]
	live.revision += 1
	if hp<=0: live.event_id = event_id
	var body: CharacterBody3D = actor.body
	var event := {"id":event_id,"event_id":event_id,"member_id":actor.id,"source_id":actor.source_id,
		"session_id":_session,"source_generation":life.source_generation,"physical_epoch":life.physical_epoch,
		"body_instance_id":body.get_instance_id(),"body_rid":body.get_rid(),"body":body,
		"rig_instance_id":life.rig_instance_id,
		"hp_before":actor.hp,"committed_hp":hp,"max_hp":actor.max_hp,"revision":live.revision,
		"origin":origin,"amount":amount,"confirmed":true,"medical_downed":hp<=0,
		"kind":"source_medical_down" if hp<=0 else "source_damage",
		"linear_velocity":body.velocity,"angular_velocity":Vector3.ZERO,
		"reference_point":body.global_position,"impulse_ns":Vector3.ZERO,
		"already_solved_by_godot":true,"apply_again":false,"physical_pose_run":false}
	_events[event_id] = event
	if hp<=0 and _pose != null:
		apply_down(event_id)
	return {"ok":true,"health_committed":true,"event":event.duplicate(true),"physical_pose_run":event.physical_pose_run}

func physical_event(query: Dictionary) -> Dictionary:
	var id := str(query.get("event_id",""))
	if not _ready() or not _events.has(id): return {"known":false,"completed":false,"accepted":false}
	var event: Dictionary = _events[id]
	var life := actor_life(event.source_id,event.body)
	if life.is_empty() or life.revision != event.revision or life.source_generation != event.source_generation \
		or life.physical_epoch != event.physical_epoch or life.hp != event.committed_hp \
		or life.rig_instance_id != event.rig_instance_id:
		return {"known":true,"completed":true,"accepted":false,"reason":"stale_health_event"}
	if event.kind == "source_medical_down" and not _medical_current(life):
		return {"known":true,"completed":true,"accepted":false,"reason":"source_medical_life_not_current"}
	var output: Dictionary = event.duplicate(true)
	output["life_generation"] = life.physical_epoch
	output["local_preview_hp_revision"] = life.revision # Legacy field; actual controlled health revision.
	var result := {"known":true,"completed":true,"accepted":true,"life":life,"event":output}
	if query.has("binding"):
		if query.get("mode") != "event" or not query.binding is Dictionary or not _binding_matches_life(query.binding,life):
			return {"known":true,"completed":true,"accepted":false,"reason":"physical_binding_mismatch"}
		result["binding"] = query.binding.duplicate(true)
	return result

func _medical_current(life: Dictionary) -> bool:
	if not _number(life.get("hp")) or float(life.hp)>0: return false
	if life.source_id == "player":
		return _player.get_meta("dead",false) == true and _player.get_meta("_localDeath",false) == true \
			and _player.get_meta("_mercenaryVehicleExplosionFatal",false) != true
	return life.get("row") is Dictionary and life.row.get("dead",false) != true \
		and life.row.get("_mercenaryVehicleExplosionFatal",false) != true

func _binding_matches_life(binding: Dictionary, life: Dictionary) -> bool:
	# Admission owns the independently measured descriptor/session, and validates
	# it before AND after calling us. Never recurse into admission while it is busy.
	if life.is_empty() or binding.get("source_id") != life.source_id \
		or binding.get("life_generation") != life.physical_epoch \
		or binding.get("body_instance_id") != life.body_instance_id \
		or binding.get("body_rid") != life.body_rid or binding.get("rig_instance_id") != life.rig_instance_id \
		or binding.get("rig_epoch") != life.rig_instance_id \
		or binding.get("placement_mode") != "COMMON_SCENE_ACTUAL": return false
	for key: String in ["session_id","render_id","bridge_id","descriptor_sha256"]:
		if not binding.get(key) is String or binding[key].is_empty(): return false
	return binding.render_id == binding.bridge_id and binding.descriptor_sha256.length() == 64 \
		and binding.descriptor_sha256.is_valid_hex_number(false)

func can_recover(plan: Dictionary) -> bool:
	# Pure proof of the CURRENT pending medical request; no HP/ledger mutation.
	var id := str(plan.get("member_id",""))
	if not _pending.has(id): return false
	var job: Dictionary = _pending[id]
	if not _recovery_current(id,job.request_id) or not is_same(plan.get("body"),job.actor.body) \
		or plan.get("source_id") != job.life.source_id or plan.get("source_generation") != job.life.source_generation \
		or plan.get("physical_epoch") != job.life.physical_epoch or plan.get("revision") != job.life.revision \
		or plan.get("event_id") != job.request_id: return false
	return physical_event({"event_id":job.life.event_id}).get("accepted") == true

func retire_stale_pending() -> int:
	# Root calls during its existing physics orchestration; there is no new timer
	# or scheduler. Private pose suppresses stale callbacks, so our core promises
	# must be retired independently after host/action/body/life replacement.
	if not Thread.is_main_thread(): return 0
	var retired := 0
	for id: Variant in _pending.keys():
		var job: Dictionary = _pending[id]
		if _recovery_current(str(id),job.request_id): continue
		_pending.erase(id)
		job.pending.settle({"ok":false,"reason":"medical_request_retired"})
		retired += 1
	return retired

func source_recovery(request: Dictionary) -> Dictionary:
	var rejected := {"ok":false,"medical_release_allowed":false,"reason":"current_medical_request_required"}
	if request.get("phase") not in ["begin","step","commit"] \
		or not request.get("target") is Transform3D or not request.target.is_finite() \
		or not request.get("binding") is Dictionary or not can_recover(request): return rejected
	var job: Dictionary = _pending[str(request.member_id)]
	if request.get("request_id") != job.request_id or request.get("down_event_id") != job.life.event_id \
		or not _binding_matches_life(request.binding,job.life): return rejected
	return {"ok":true,"binding":request.binding.duplicate(true),"request_id":request.request_id,
		"phase":request.phase,"medical_release_allowed":true}

func _seated(row: Dictionary) -> bool:
	for key: String in ["_inVehicle","_mercenaryVehicleId","_mercenaryVehicleSeat","_mercenaryVehicleReservedId","_mercenaryVehicleReservedSeat","_ambulanceInTransit","_carriedByAmbulance"]:
		if row.get(key) != null and row.get(key) != false and row.get(key) != "": return true
	return false

func _recover(id: String, effect: Dictionary, hp: float) -> Variant:
	if _pose == null: return _reject("member_pose_recovery_owner_missing")
	var actor := _actor(id)
	if actor.is_empty() or float(actor.hp)>0 or _pending.has(id): return _reject("recovery_actor_unavailable")
	if id != "player" and _seated(actor.row): return _reject("recovery_seat_owner_missing")
	var life := actor_life(actor.source_id,actor.body)
	if life.is_empty() or life.event_id.is_empty() or not physical_event({"event_id":life.event_id}).get("accepted",false):
		return _reject("recovery_health_event_missing")
	var core: Variant = _get_core.call()
	var action: Variant = core.get_action(str(effect.get("memberId","")))
	if not action is Dictionary or action.get("id") != effect.get("actionId") or action.get("kind") != "revive":
		return _reject("recovery_current_action_missing")
	var pending := Squad.PendingEffect.new()
	var request_id := "%s/revive:%s" % [life.event_id,str(effect.actionId)]
	_pending[id] = {"pending":pending,"actor":actor,"life":life,"hp":hp,"core":core,"effect":effect.duplicate(true),"request_id":request_id}
	var plan := life.duplicate()
	plan["down_event_id"] = life.event_id
	plan["event_id"] = request_id
	plan["completion"] = Callable(self,"_recovery_completed").bind(id,request_id)
	plan["still_current"] = Callable(self,"_recovery_current").bind(id,request_id)
	var result: Variant = _pose.recover(plan)
	if result is Dictionary and result.get("physical_committed") == true:
		_recovery_completed(result,id,request_id)
	elif not result is Dictionary or result.get("ok") != true or result.get("pending") != true:
		_recovery_completed({"ok":false,"reason":"physical_recovery_rejected"},id,request_id)
	return pending

func _recovery_current(id: String, request_id: String) -> bool:
	if not _ready() or not _pending.has(id): return false
	var job: Dictionary = _pending[id]
	if job.request_id != request_id: return false
	var actor := _actor(id)
	var current: Variant = _get_core.call()
	if actor.is_empty() or not is_instance_valid(current) or not is_same(current,job.core): return false
	var action: Variant = current.get_action(job.effect.memberId)
	var life := actor_life(job.actor.source_id,job.actor.body)
	var medic := _member(str(job.effect.get("memberId","")))
	if medic.is_empty() or not _number(medic.get("hp")) or float(medic.hp)<=0 or medic.get("dead",false) == true \
		or medic.get("_mercenaryHospital",false) == true or is_revive_blocked(str(medic.id)): return false
	var record: Variant = current.get_record(medic.id)
	if not record is Dictionary or record.get("profession") != "medic" or record.get("status") == "hospital": return false
	if not action is Dictionary or action.get("id") != job.effect.actionId \
		or action.get("kind") != "revive" or action.get("memberId") != medic.id \
		or action.get("targetId") != id or life.is_empty() or not _medical_current(life) \
		or life.revision != job.life.revision or life.source_generation != job.life.source_generation \
		or life.physical_epoch != job.life.physical_epoch or life.hp > 0: return false
	if id == "player":
		return _player_emergency_clear()
	return not is_revive_blocked(id) and not bool(actor.row.get("_mercenaryHospital",false)) and not _seated(actor.row)

func _recovery_completed(receipt: Dictionary, id: String, request_id: String) -> void:
	if not _pending.has(id): return
	var job: Dictionary = _pending[id]
	if job.request_id != request_id: return # Old callback cannot cancel a newer request.
	var current_before_erase := _recovery_current(id,request_id)
	_pending.erase(id)
	var actor := _actor(id)
	var current: Variant = _get_core.call() if _ready() else null
	var action: Variant = current.get_action(job.effect.memberId) if is_instance_valid(current) else null
	var life := actor_life(job.actor.source_id,job.actor.body)
	var valid: bool = current_before_erase and receipt.get("ok") == true and receipt.get("physical_committed") == true \
		and receipt.get("event_id") == job.request_id and receipt.get("body_instance_id") == job.life.body_instance_id \
		and receipt.get("revision") == job.life.revision and not actor.is_empty() and not life.is_empty() \
		and life.revision == job.life.revision and life.source_generation == job.life.source_generation \
		and life.hp <= 0 and is_same(current,job.core) and action is Dictionary \
		and action.get("id") == job.effect.actionId
	if not valid or (id != "player" and (is_revive_blocked(id) or bool(actor.row.get("_mercenaryHospital",false)) or _seated(actor.row))):
		job.pending.settle({"ok":false,"reason":"physical_recovery_failed_or_stale"})
		return
	if id == "player":
		_player.set_meta("hp",job.hp); _player.set_meta("dead",false); _player.set_meta("_localDeath",false)
		_player.set_meta("myDeathBy",""); _player.set_meta("myDeathLeft",0.0)
		_player.set_meta("_localHpHurtAt",0); _player.set_meta("_selfHpBarUntil",Time.get_ticks_msec()+4500)
		_player.set_meta("life_generation",life.source_generation+1)
		_player.velocity = Vector3.ZERO
	else:
		actor.row.hp = job.hp
		_new_member_life(actor.row)
	var stored: Dictionary = _lives[str(job.actor.body.get_instance_id())]
	stored.source_generation += 1; stored.physical_epoch += 1; stored.revision += 1; stored.event_id = ""
	job.pending.settle({"ok":true,"physical_committed":true,"hp":job.hp,"body_instance_id":job.life.body_instance_id})

func _new_member_life(row: Dictionary) -> void:
	for key: String in ["_mercenaryVehicleExplosionFatal","deathConfirmed","deadAt","_lifeState","_mercenaryQaRescueUntil"]: row.erase(key)
	row.dead = false; row._medicalDowned = false; row._mercenaryDownAt = 0; row._mercenaryHospital = false
	row._mercenaryLifeGeneration = int(row.get("_mercenaryLifeGeneration",0))+1

func qa_place_patient(options: Dictionary = {}) -> Dictionary:
	if not _ready() or _busy or not _origins.has("qa_patient") or not _movement.placement_ready():
		return _reject("qa_patient_origin_or_placement_missing")
	var core: Variant = _get_core.call()
	var actor: Dictionary = {}
	for record: Dictionary in core.get_roster():
		if record.profession == "bruiser": actor = _actor(record.id); break
	if actor.is_empty() or not _number(actor.hp) or _seated(actor.row):
		return _reject("qa_patient_actor_unavailable")
	var event_id := str(options.get("event_id",""))
	if event_id.is_empty(): return _reject("qa_patient_event_id_empty")
	if _events.has(event_id):
		var old: Dictionary = _events[event_id]
		if old.origin != "qa_patient" or old.member_id != actor.id or old.body_instance_id != actor.body.get_instance_id():
			return _reject("event_identity_collision")
		return {"ok":true,"duplicate":true,"event":old.duplicate(true),"physical_pose_run":old.get("physical_pose_run",false)}
	if float(actor.hp)<=0: return _reject("qa_patient_already_downed")
	var point := _point(actor.body.global_position)
	# This controlled scenario admits the current real supported position only;
	# arbitrary QA teleport requires the separate relocation transaction owner.
	if options.has("position") and options.position != point: return _reject("qa_patient_relocation_owner_required")
	var floor_query: Dictionary = _movement.placement_query_point(point)
	if floor_query.get("blocked",true) or not _number(floor_query.get("depth")) or float(floor_query.depth)>.08 \
		or not _movement.placement_body_clear(point,{"id":actor.id}) \
		or _movement.placement_inside_building(_point(actor.body.global_position+Vector3.UP*.9)) \
		or _movement.placement_blocks_vehicle(point,{"radius":.18*float(_world.source_world_scale())*sqrt(2.0),"height":1.9}):
		return _reject("qa_patient_point_blocked")
	var life := actor_life(actor.source_id,actor.body)
	var action: Variant = core.get_action(actor.id)
	if life.is_empty() or (action is Dictionary and (action.get("armed",false) or action.get("awaiting",false))):
		return _reject("qa_patient_life_busy")
	_busy = true
	var allowed: Variant = (_origins["qa_patient"] as Callable).call({"id":actor.id,"body":actor.body,"context":options.duplicate(true),"life":life.duplicate()})
	_busy = false
	var fresh := _actor(actor.id)
	if not allowed is bool or not allowed or fresh.is_empty() or not is_same(fresh.body,actor.body) or fresh.hp != actor.hp or fresh.source_generation != actor.source_generation:
		return _reject("qa_patient_origin_rejected_or_changed")
	var reset: Dictionary = core.reset_qa_patient(actor.id)
	if not reset.get("ok",false): return _reject("qa_patient_core_reset_denied")
	for record: Dictionary in core.get_roster():
		var row := _member(record.id)
		var work: Variant = core.get_action(record.id)
		if row.is_empty() or float(row.hp)<=0 or record.status == "hospital" \
			or (work is Dictionary and (work.get("armed",false) or work.get("awaiting",false))): continue
		core.clear_queue(record.id)
		if work != null: core.cancel(record.id)
		row._mercenaryOrder = "rally"; row._mercenaryRally = _point(row.body.global_position); row._mercenaryMove = null
	_new_member_life(actor.row)
	var live: Dictionary = _lives[str(actor.body.get_instance_id())]
	live.source_generation += 1; live.physical_epoch += 1
	life.source_generation += 1; life.physical_epoch += 1
	actor.row.hp = 0.0; actor.row._medicalDowned = true
	actor.row._mercenaryDownAt = Time.get_ticks_msec()
	actor.row._mercenaryQaRescueUntil = float(_world.now())+600.0
	actor.row._mercenaryMove = null; actor.row._followSpeed = 0.0
	actor.row._threatUntil = 0.0; actor.row._mercenaryDefending = false
	return _record_health(actor,life,event_id,"qa_patient",float(actor.hp),0.0)

func _medic_fraction(effect: Dictionary) -> Variant:
	var medic := _member(str(effect.get("memberId","")))
	if medic.is_empty():
		return null
	var core: Variant = _get_core.call()
	var record: Variant = core.get_record(medic.id)
	if record.profession != "medic":
		return null
	var stats: Dictionary = core.stats(medic.id)
	return stats.reviveFraction if _number(stats.get("reviveFraction")) else null

func get_state() -> Dictionary:
	var rows: Array = []
	if _ready():
		for row: Dictionary in _world.get_residents()+_world.get_gang():
			var body: Variant = _world.registered_actor_body(row)
			var life: Dictionary = _lives.get(str(body.get_instance_id()),{}) if _live_body(body) else {}
			var event: Dictionary = _events.get(str(life.get("event_id","")),{})
			rows.append({"id":row.get("id"),"hp":row.get("hp"),"maxHp":row.get("max_hp"),
				"dead":row.get("dead"),"hospital":row.get("_mercenaryHospital",false),
				"bodyInstanceId":body.get_instance_id() if _live_body(body) else null,
				"position":_point(body.global_position) if _live_body(body) else null,
				"physicalPoseRun":event.get("physical_pose_run",false),"panicMotionAdmitted":false})
	return {"configured":_configured,"disposed":_disposed,"scope":"controlled_health_authority",
		"poseProviderBound":_pose != null,"medicalNativeAccepted":false,"fearOwnerReady":false,"hospitalOwnerReady":false,
		"playerHealthInitialized":_player_initialized,"session_id":_session,"eventCount":_events.size(),
		"pendingRecoveryCount":_pending.size(),"actors":rows,"lastReceipt":_last_receipt.duplicate(true)}

func _reject(reason: String, evidence: Dictionary = {}) -> Dictionary:
	_last_receipt = {"ok":false,"reason":reason,"preserved":true,"physicalApplied":false}
	_last_receipt.merge(evidence,true)
	return _last_receipt.duplicate(true)

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _point(value: Vector3) -> Dictionary:
	return {"x":value.x,"y":value.y,"z":value.z}

func dispose() -> void:
	if _disposed: return
	# Reject pending acknowledgments while the old core still exists. The root
	# retires physical leases before replacing a body/host binding.
	for id: String in _pending.keys():
		var job: Dictionary = _pending[id]
		job.pending.settle({"ok":false,"reason":"life_owner_disposed"})
	_pending.clear()
	# Root disposes the manager AFTER health authority is revoked. Private manager
	# has no cancel API, and cannot dispose a still-current active medical life.
	_pose = null
	_disposed = true
	_configured = false
	_world = null
	_player = null
	_get_host = Callable()
	_get_core = Callable()
	_movement = null
