extends Node3D
## Port of mercenary_breach_door.mjs. The source core owns action/fuse clocks.
## This owner acknowledges only after the closed leaf's physical collider has
## been exchanged for the source moving-leaf reservation; frames remain solid.

var target_id := ""
var leaf: Node3D
var latch: MeshInstance3D
var fragment: MeshInstance3D
var leaf_body: StaticBody3D
var leaf_shape: CollisionShape3D
var sweep_body: StaticBody3D
var sweep_shape: CollisionShape3D
var opened := false
var opening := false
var method := ""
var elapsed := 0.0
var angle := 0.0
var _configured := false
var _disposed := false
var _frame_bodies: Array[StaticBody3D] = []
var _collision_pins: Dictionary = {}

func configure(id: String, at: Vector3, yaw := 0.0) -> bool:
	if _configured or id.is_empty() or not at.is_finite() or not is_finite(yaw):
		return false
	target_id = id
	name = "Mercenary_Locked_Service_Door"
	position = at
	rotation.y = yaw
	set_meta("gang_target_id", id)
	var wood := _material(Color.html("77503a"), .86)
	var metal := _material(Color.html("475355"), .57, .65)
	var lock_metal := _material(Color.html("ab925c"), .4, .7)
	for box: Array in [[Vector3(-1.105,1.3,0),Vector3(.21,2.6,.24)],
		[Vector3(1.105,1.3,0),Vector3(.21,2.6,.24)],
		[Vector3(0,2.5,0),Vector3(2,.20,.24)]]:
		_box(self,box[0],box[1],metal)
		_frame_bodies.append(_solid(self,box[0],box[1]))
	leaf = Node3D.new()
	leaf.name = "Breach_Door_Hinged_Leaf"
	leaf.position = Vector3(-1,0,0)
	add_child(leaf)
	for index in 8:
		_box(leaf,Vector3(.124+index*.25,1.21,0),Vector3(.246,2.38,.12),wood)
	for box: Array in [[Vector3(1,.40,-.075),Vector3(1.96,.085,.034)],
		[Vector3(1,1.99,-.075),Vector3(1.96,.085,.034)],
		[Vector3(.05,1.19,0),Vector3(.06,2.4,.15)]]:
		_box(leaf,box[0],box[1],metal)
	_box(leaf,Vector3(1.72,1.02,-.089),Vector3(.11,.23,.045),lock_metal)
	_box(leaf,Vector3(1.76,1.06,-.145),Vector3(.21,.038,.06),lock_metal)
	latch = _box(self,Vector3(.98,1.02,-.095),Vector3(.13,.09,.08),lock_metal)
	fragment = _box(self,Vector3(.98,1.02,-.095),Vector3(.13,.09,.08),lock_metal)
	fragment.visible = false
	# The source solid command surface also bridges decorative plank seams.
	leaf_body = _solid(leaf,Vector3(1,1.21,0),Vector3(2,2.38,.16))
	leaf_shape = leaf_body.get_child(0) as CollisionShape3D
	sweep_body = _solid(self,Vector3(-.31,1.21,.95),Vector3(2.82,2.38,2.30))
	sweep_body.name = "MovingLeafReservation"
	sweep_shape = sweep_body.get_child(0) as CollisionShape3D
	sweep_body.collision_layer = 0
	sweep_body.collision_mask = 0
	_collision_pins = {"leaf":leaf,"leaf_body":leaf_body,"leaf_shape":leaf_shape,
		"sweep_body":sweep_body,"sweep_shape":sweep_shape,
		"leaf_resource":leaf_shape.shape,"sweep_resource":sweep_shape.shape,
		"leaf_scene_owner":leaf_shape.owner,"sweep_scene_owner":sweep_shape.owner}
	_configured = true
	return true

func describe() -> Variant:
	if _disposed or not _configured or not is_inside_tree() or not is_visible_in_tree():
		return null
	var approach := to_global(Vector3(.6,0,-1.08))
	return {"id":target_id,"kind":"door","sourceId":target_id,"object":self,
		"position":_point(approach),"center":_point(global_position),"valid":true,
		"destroyed":false,"locked":not opened,"lockable":true,"lockpickable":false,
		"opened":opened,"breachable":not opened,"bombable":not opened,
		"workRange":.08,"workPoint":_point(to_global(Vector3(.6,.85,-.08))),
		"workNormal":_point(global_basis*Vector3(0,0,-1)),
		"label":"Запертая дверь",
		"highlightBounds":{"min":[-1.22,0,-.18],"max":[1.22,2.61,.16]}}

func break_open(effect: Dictionary) -> Dictionary:
	return _open("kick",effect)

func blast(effect: Dictionary) -> Dictionary:
	return _open("blast",effect)

func _open(kind: String, effect: Dictionary) -> Dictionary:
	if _disposed or not is_inside_tree():
		return {"ok":false,"reason":"disposed"}
	if effect.has("targetId") and effect.targetId != target_id:
		return {"ok":false,"reason":"wrong_target"}
	if not _collision_connected():
		return {"ok":false,"reason":"collision_not_connected"}
	if opened:
		return {"ok":true,"duplicate":true,"opened":true,"targetId":target_id}
	# Broad-phase bodies already exist. Publish only after the actual layer swap.
	sweep_body.collision_layer = 1
	sweep_body.collision_mask = 1
	leaf_body.collision_layer = 0
	leaf_body.collision_mask = 0
	opened = true
	opening = true
	method = kind
	latch.visible = false
	fragment.visible = true
	set_meta("locked",false)
	set_meta("mercenaryOpened",true)
	return {"ok":true,"opened":true,"breached":true,"targetId":target_id,
		"physicalReservation":sweep_body.get_instance_id()}

func _collision_connected() -> bool:
	# Source leafBox/sweepBox in mercenary_breach_door.mjs. Validate the exact
	# configured native owners/resources before publishing or acknowledging any
	# transition. A same-sized replacement is not the registered original shape.
	if not _configured or _collision_pins.is_empty() or is_queued_for_deletion() \
		or not global_transform.is_finite():
		return false
	var actual := {"leaf":leaf,"leaf_body":leaf_body,"leaf_shape":leaf_shape,
		"sweep_body":sweep_body,"sweep_shape":sweep_shape}
	for key: String in actual:
		var value: Variant = actual[key]
		if not is_instance_valid(value):
			return false
		var node := value as Node3D
		if node == null or not is_same(node,_collision_pins.get(key)) \
			or not node.is_inside_tree() or node.is_queued_for_deletion() \
			or node.get_world_3d() != get_world_3d() or not node.global_transform.is_finite():
			return false
	if leaf.get_parent() != self or leaf_body.get_parent() != leaf \
		or leaf_shape.get_parent() != leaf_body or sweep_body.get_parent() != self \
		or sweep_shape.get_parent() != sweep_body \
		or not is_same(leaf_shape.owner,_collision_pins.leaf_scene_owner) \
		or not is_same(sweep_shape.owner,_collision_pins.sweep_scene_owner):
		return false
	var expected_leaf := Transform3D(Basis(Vector3.UP,angle if opened else 0.0),Vector3(-1,0,0))
	if not leaf.transform.is_equal_approx(expected_leaf) \
		or not leaf_body.transform.is_equal_approx(Transform3D(Basis.IDENTITY,Vector3(1,1.21,0))) \
		or not sweep_body.transform.is_equal_approx(Transform3D(Basis.IDENTITY,Vector3(-.31,1.21,.95))):
		return false
	if not _shape_connected(leaf_body,leaf_shape,_collision_pins.leaf_resource,Vector3(2,2.38,.16)) \
		or not _shape_connected(sweep_body,sweep_shape,_collision_pins.sweep_resource,Vector3(2.82,2.38,2.30)):
		return false
	# Reservation starts inactive, but its shape is already enabled and registered.
	# During source hinge animation the active/inactive roles are reversed.
	var leaf_layer := 0 if opening else 1
	var sweep_layer := 1 if opening else 0
	return leaf_body.collision_layer == leaf_layer and leaf_body.collision_mask == leaf_layer \
		and sweep_body.collision_layer == sweep_layer and sweep_body.collision_mask == sweep_layer \
		and PhysicsServer3D.body_get_collision_layer(leaf_body.get_rid()) == leaf_layer \
		and PhysicsServer3D.body_get_collision_mask(leaf_body.get_rid()) == leaf_layer \
		and PhysicsServer3D.body_get_collision_layer(sweep_body.get_rid()) == sweep_layer \
		and PhysicsServer3D.body_get_collision_mask(sweep_body.get_rid()) == sweep_layer

func _shape_connected(body: StaticBody3D, collision: CollisionShape3D,
		expected: BoxShape3D, size: Vector3) -> bool:
	if not is_instance_valid(expected) or collision.shape == null or collision.disabled \
		or not is_same(collision.shape,expected) or not expected.size.is_equal_approx(size) \
		or not collision.transform.is_equal_approx(Transform3D.IDENTITY):
		return false
	var owners := body.get_shape_owners()
	if owners.size() != 1 or body.shape_owner_get_owner(owners[0]) != collision \
		or body.is_shape_owner_disabled(owners[0]) or body.shape_owner_get_shape_count(owners[0]) != 1 \
		or not is_same(body.shape_owner_get_shape(owners[0],0),expected) \
		or not body.shape_owner_get_transform(owners[0]).is_equal_approx(collision.transform):
		return false
	# Missing pending native registration is not permission to report success.
	var rid := body.get_rid()
	return PhysicsServer3D.body_get_shape_count(rid) == 1 \
		and PhysicsServer3D.body_get_shape(rid,0) == expected.get_rid() \
		and PhysicsServer3D.body_get_shape_transform(rid,0).is_equal_approx(collision.transform)

func advance(dt: float) -> void:
	if _disposed or not opening or not is_finite(dt):
		return
	elapsed = minf(.8,elapsed+clampf(dt,0,.1))
	var t := elapsed/.8
	angle = -deg_to_rad(108.0)*(1.0-pow(1.0-t,3))
	leaf.rotation.y = angle
	fragment.position = Vector3(.98+.22*t,maxf(.05,1.02-1.65*t*t),-.095-.30*t)
	fragment.rotation = Vector3(t*4.2,0,t*2.3)
	if t >= 1.0:
		# Keep the rotated leaf and all frames as physical obstacles.
		leaf_body.collision_layer = 1
		leaf_body.collision_mask = 1
		sweep_body.collision_layer = 0
		sweep_body.collision_mask = 0
		opening = false

func get_state() -> Dictionary:
	return {"id":target_id,"opened":opened,"locked":not opened,"opening":opening,
		"mode":method,"angle":angle,"frameBodies":_frame_bodies.size(),
		"leafPhysical":is_instance_valid(leaf_body) and leaf_body.collision_layer != 0,
		"sweepPhysical":is_instance_valid(sweep_body) and sweep_body.collision_layer != 0}

func dispose() -> void:
	_disposed = true
	opening = false
	# Scene owns these Nodes; never free another owner's geometry.

func _solid(parent: Node3D, at: Vector3, size: Vector3) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = at
	body.collision_layer = 1
	body.collision_mask = 1
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	parent.add_child(body)
	return body

func _box(parent: Node3D, at: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	instance.mesh = box
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)
	return instance

func _material(color: Color, roughness: float, metallic := 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	return material

func _point(value: Vector3) -> Dictionary:
	return {"x":value.x,"y":value.y,"z":value.z}
