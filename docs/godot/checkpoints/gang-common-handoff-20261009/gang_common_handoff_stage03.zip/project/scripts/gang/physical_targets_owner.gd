extends Node3D
## Source profession-showcase layout and actual target owners in the SAME scene.
## No command duration, actor spawn, HP shortcut or fabricated effect receipt.
const Door = preload("res://scripts/gang/source_breach_door.gd")
const Fence = preload("res://scripts/gang/source_fence.gd")
const Power = preload("res://scripts/gang/source_power_panel.gd")
const Safe = preload("res://scripts/gang/source_safe.gd")
const Vehicle = preload("res://scripts/gang/source_parked_vehicle.gd")
const TargetEffects = preload("res://addons/walk_mercenary_host/mercenary_target_effects.gd")
const Squad = preload("res://addons/walk_mercenary/mercenary_squad.gd")
const PREFIX := "QA-MERCENARY-GODOT-common"

var world: Node3D
var last_error := ""
var safe: Node3D
var _get_host: Callable
var _get_core: Callable
var _owners: Dictionary = {}
var _effects: RefCounted
var _configured := false
var _disposed := false
var _reconciliation_blocked: Array = []

func configure(registry: Node3D, get_host: Callable, get_core: Callable, save_path: String) -> bool:
	if _configured or _disposed or not is_inside_tree() or not is_instance_valid(registry) \
		or not get_host.is_valid() or not get_core.is_valid() or save_path.is_empty():
		last_error = "invalid_configuration"
		return false
	world = registry
	_get_host = get_host
	_get_core = get_core
	# Same relative source showcase layout (mercenary_profession_showcase.mjs).
	var fence := Fence.new()
	add_child(fence)
	if not fence.configure(PREFIX+":cage:north-panel",Vector3(-7,0,3)):
		return _fail("source_fence_unavailable")
	_register(fence.target_id,fence)
	var power := Power.new()
	add_child(power)
	if not power.configure(PREFIX+":power",Vector3(-4.85,0,.25)):
		return _fail("source_circuit_unavailable")
	_register(power.target_id,power)
	var door := Door.new()
	add_child(door)
	if not door.configure(PREFIX+":door",Vector3(5,0,-5)):
		return _fail("source_door_unavailable")
	_register(door.target_id,door)
	# A second instance of the same source factory permits independent door C4
	# and breach outcomes. It does not replace the source parked-car lock action.
	var blast_door := Door.new()
	add_child(blast_door)
	if not blast_door.configure(PREFIX+":blast-door",Vector3(8,0,-5)):
		return _fail("source_blast_door_unavailable")
	_register(blast_door.target_id,blast_door)
	safe = Safe.new()
	add_child(safe)
	var room_id := PREFIX+":floor:0:main"
	var safe_id := "interior-safe:"+room_id
	if not safe.configure(safe_id,PREFIX,room_id,Vector3(-7,0,-5),PI,
		_get_host,Callable(world,"is_local"),save_path+".interior-safes.json"):
		return _fail("source_safe_unavailable")
	_register(safe_id,safe)
	var vehicle := Vehicle.new()
	add_child(vehicle)
	if not vehicle.configure("traffic:vehicle_gang_common_parked", "vehicle_gang_common_parked",
		Vector3(12,0,5),0,_get_host):
		return _fail("source_parked_vehicle_unavailable:"+vehicle.last_error)
	_register("traffic:vehicle_gang_common_parked",vehicle)
	_configured = true
	rebind_effects()
	return true

func _fail(reason: String) -> bool:
	last_error = reason
	return false

func _register(id: String, owner: Node3D) -> void:
	_owners[id] = owner
	owner.set_meta("gang_target_id",id)

func get_target(id: Variant) -> Variant:
	if _disposed or not _configured:
		return null
	var owner: Node3D = _owners.get(str(id)) as Node3D
	if not is_instance_valid(owner) or owner.is_queued_for_deletion() or not owner.is_inside_tree():
		return null
	return owner.describe()

func rebind_effects() -> void:
	if _effects != null:
		_effects.dispose()
	_effects = TargetEffects.new(Callable(self,"get_target"),{
		"onDoorBreach":Callable(self,"_door_breach"),
		"onDoorBlast":Callable(self,"_door_blast"),
		"onUnlock":Callable(self,"_unlock"),
		"onFenceCut":Callable(self,"_fence_cut"),
		"onDisablePower":Callable(self,"_power_off")},Callable(self,"_pending"))

func _pending() -> RefCounted:
	return Squad.PendingEffect.new()

func perform_effect(effect: Dictionary) -> Variant:
	if _disposed or not _configured or _effects == null:
		return {"ok":false,"reason":"target_owner_unavailable"}
	return _effects.perform_effect(effect)

func _owner_for(target: Dictionary) -> Variant:
	var owner: Variant = _owners.get(str(target.get("id","")))
	if not is_instance_valid(owner):
		return null
	var fresh: Variant = owner.describe()
	return owner if fresh is Dictionary and fresh.get("object") == target.get("object") else null

func _context(effect: Dictionary) -> Dictionary:
	var context := effect.duplicate()
	context.requestId = "mercenary:"+str(effect.get("actionId",""))
	return context

func _door_breach(target: Dictionary,effect: Dictionary) -> Variant:
	var owner: Variant = _owner_for(target)
	return owner.break_open(_context(effect)) if owner != null and target.kind == "door" else false

func _door_blast(target: Dictionary,effect: Dictionary) -> Variant:
	var owner: Variant = _owner_for(target)
	return owner.blast(_context(effect)) if owner != null and target.kind == "door" else false

func _unlock(target: Dictionary,effect: Dictionary) -> Variant:
	var owner: Variant = _owner_for(target)
	if owner == null:
		return false
	if target.kind == "safe":
		# Safe authority retains canonical safeId:unlock, with actionId in context.
		return owner.unlock(effect)
	if target.kind == "vehicle":
		return owner.unlock(target,effect)
	return {"ok":false,"reason":"unlock_owner_missing"}

func _fence_cut(target: Dictionary,effect: Dictionary) -> Variant:
	var owner: Variant = _owner_for(target)
	return owner.cut(_context(effect)) if owner != null and target.kind == "fence" else false

func _power_off(target: Dictionary,effect: Dictionary) -> Variant:
	var owner: Variant = _owner_for(target)
	return owner.disable_power(_context(effect)) if owner != null and target.kind == "power_panel" else false

func reconcile_restored_pending() -> Array:
	var receipts: Array = []
	_reconciliation_blocked.clear()
	var core: Variant = _get_core.call() if _get_core.is_valid() else null
	if _disposed or core == null or not is_instance_valid(safe):
		return receipts
	for pending: Dictionary in core.snapshot().get("pendingTransactions",[]):
		if pending.get("kind") != "unlock_safe" or not _owners.has(str(pending.get("targetId"))):
			continue
		var owner: Variant = _owners[str(pending.targetId)]
		if owner != safe:
			continue
		var receipt: Dictionary = safe.authoritative_receipt(str(pending.targetId)+":unlock",str(pending.memberId))
		# An unavailable authority stays pending. Never resend the effect or infer
		# success from UI flags/the RAM TargetEffects duplicate map.
		if receipt.get("ok") != true and receipt.get("reason") != "locked":
			_reconciliation_blocked.append({"requestId":pending.requestId,
				"targetId":pending.targetId,"reason":receipt.get("reason","source_unavailable")})
			continue
		receipts.append(core.resolve_pending(pending.requestId,receipt))
	return receipts

func needs_reconciliation_retry() -> bool:
	return not _reconciliation_blocked.is_empty()

func reconciliation_diagnostics() -> Array:
	return _reconciliation_blocked.duplicate(true)

func advance(dt: float) -> void:
	if _disposed:
		return
	for owner: Node3D in _owners.values():
		if is_instance_valid(owner) and owner.has_method("advance"):
			owner.advance(dt)

func target_id_for_node(node: Node) -> String:
	var cursor := node
	while is_instance_valid(cursor):
		var id := str(cursor.get_meta("gang_target_id",""))
		if _owners.has(id):
			return id
		cursor = cursor.get_parent()
	return ""

func get_states() -> Dictionary:
	var result: Dictionary = {}
	for id: String in _owners:
		var owner: Node3D = _owners[id]
		if is_instance_valid(owner):
			result[id] = owner.get_state()
	return result

func dispose() -> void:
	_disposed = true
	if _effects != null:
		_effects.dispose()
	for owner: Node3D in _owners.values():
		if is_instance_valid(owner):
			owner.dispose()
	_owners.clear()
	_get_host = Callable()
	_get_core = Callable()
