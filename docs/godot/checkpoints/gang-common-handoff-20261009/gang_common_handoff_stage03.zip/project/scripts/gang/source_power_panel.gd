extends Node3D
## mercenary_power_panel.mjs: exactly one authored two-lamp circuit. The
## physical box and circuit belong here; no timer or scene-wide light changes.
var target_id := ""
var lever: Node3D
var panel_body: StaticBody3D
var _lights: Array[OmniLight3D] = []
var _lamps: Array[MeshInstance3D] = []
var _owned: Array[Node3D] = []
var _bulb: StandardMaterial3D
var _powered := true
var _nearby := true
var _configured := false
var _disposed := false

func configure(id: String, at: Vector3, yaw: float = 0.0) -> bool:
	if _configured or _disposed or id.is_empty() or not at.is_finite() or not is_finite(yaw):
		return false
	target_id = id
	name = "Service_Yard_Power_Panel"
	position = at
	rotation.y = yaw
	set_meta("gang_target_id", id)
	var steel := _material("586967",.63,.6)
	var dark := _material("232927",.75)
	var warning := _material("e6b343",.65)
	_bulb = _material("e6dfb9",.35)
	_bulb.emission_enabled = true
	_bulb.emission = Color.html("ffdb8f")
	_box(self,"Panel_Post",Vector3(.12,1.1,.12),Vector3(0,.55,0),dark)
	_box(self,"Steel_Fuse_Box",Vector3(.66,.87,.28),Vector3(0,1.33,0),steel)
	_box(self,"Recessed_Switch_Plate",Vector3(.53,.66,.025),Vector3(0,1.33,-.153),dark)
	_box(self,"Warning_Plate",Vector3(.14,.12,.012),Vector3(.17,1.52,-.173),warning)
	lever = Node3D.new()
	lever.name = "Main_Isolation_Lever"
	lever.position = Vector3(-.11,1.35,-.19)
	add_child(lever)
	_owned.append(lever)
	_box(lever,"Insulated_Lever",Vector3(.075,.23,.075),Vector3(0,.085,0),warning)
	for x: float in [-4.15,0.0]:
		_box(self,"Yard_Lamp_Bracket",Vector3(.1,.15,.46),Vector3(x,2.05,4.8),steel)
		var lamp := _box(self,"Yard_Work_Lamp",Vector3(.32,.08,.22),Vector3(x,1.97,4.95),_bulb)
		lamp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_lamps.append(lamp)
		var light := OmniLight3D.new()
		light.name = "Yard_Work_Light"
		light.position = Vector3(x,1.88,4.95)
		light.light_color = Color.html("ffe4b5")
		light.light_energy = 2.2
		light.omni_range = 7.0
		light.omni_attenuation = 2.0
		light.shadow_enabled = false
		add_child(light)
		_lights.append(light)
		_owned.append(light)
	panel_body = StaticBody3D.new()
	panel_body.name = "SourcePowerPanelCollision"
	panel_body.position.y = .9
	panel_body.collision_layer = 1
	panel_body.collision_mask = 1
	panel_body.set_meta("source_collider_id",target_id)
	panel_body.set_meta("mercenaryPowerPanel",true)
	var collision := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(.72,1.8,.36)
	collision.shape = box
	panel_body.add_child(collision)
	add_child(panel_body)
	_owned.append(panel_body)
	_configured = true
	_visual()
	return true

func describe() -> Variant:
	if _disposed or not _configured or not is_inside_tree() or not is_visible_in_tree() or is_queued_for_deletion():
		return null
	return {"id":target_id,"kind":"power_panel","sourceId":target_id,"object":self,
		"position":_point(to_global(Vector3(0,0,-1.02))),"center":_point(global_position),
		"valid":true,"destroyed":false,"powered":_powered,"disabled":not _powered,
		"workRange":.08,"workPoint":_point(to_global(Vector3(-.11,1.4,-.22))),
		"workNormal":_point((global_basis*Vector3(0,0,-1)).normalized()),
		"label":"Щиток освещения клетки",
		"highlightBounds":{"min":[-.37,.86,-.24],"max":[.37,1.8,.18]}}

func disable_power(effect: Dictionary = {}) -> Dictionary:
	if _disposed or not _configured or not is_inside_tree() or is_queued_for_deletion():
		return {"ok":false,"reason":"disposed"}
	if effect.has("targetId") and effect.targetId != target_id:
		return {"ok":false,"reason":"wrong_target"}
	if not _powered:
		return {"ok":true,"alreadyOff":true,"powered":false,"targetId":target_id}
	if not _circuit_connected():
		return {"ok":false,"reason":"power_not_connected"}
	# This is the real owned circuit acknowledgement, not a caller-supplied
	# success stub. Both exact lights and their shared bulb change synchronously.
	_powered = false
	_visual()
	return {"ok":true,"powered":false,"targetId":target_id}

func update_visibility(focus: Vector3, max_distance: float = 60.0) -> bool:
	if _disposed:
		return false
	var distance := maxf(0,max_distance) if is_finite(max_distance) else 60.0
	_nearby = is_finite(focus.x) and is_finite(focus.z) and is_inside_tree() \
		and Vector2(focus.x-global_position.x,focus.z-global_position.z).length_squared() <= distance*distance
	for light: OmniLight3D in _lights:
		if is_instance_valid(light):
			light.visible = _powered and _nearby
	return _powered and _nearby

func get_state() -> Dictionary:
	return {"id":target_id,"powered":_powered,"pending":false,"disposed":_disposed,
		"lightsVisible":_powered and _nearby and not _disposed,
		"ownedLights":_lights.size(),"circuitConnected":_circuit_connected(),
		"leverAngle":lever.rotation.x if is_instance_valid(lever) else 0.0}

func advance(_dt: float) -> void:
	pass # Source circuit has no autonomous timers or animation.

func dispose() -> void:
	if _disposed:
		return
	_disposed = true
	for child: Node3D in _owned:
		if not is_instance_valid(child):
			continue
		if child is StaticBody3D:
			child.collision_layer = 0
			child.collision_mask = 0
		if child.get_parent() == self:
			remove_child(child)
		child.queue_free()
	_owned.clear()
	_lamps.clear()
	_lights.clear()
	_bulb = null

func _visual() -> void:
	set_meta("powered",_powered)
	set_meta("mercenaryPowered",_powered)
	set_meta("mercenaryDisabled",not _powered)
	lever.rotation.x = -.6 if _powered else .8
	_bulb.emission_energy_multiplier = 1.5 if _powered else 0.0
	for light: OmniLight3D in _lights:
		light.visible = _powered and _nearby

func _circuit_connected() -> bool:
	if _disposed or not _configured or not is_inside_tree() or not is_instance_valid(panel_body) \
		or not panel_body.is_inside_tree() or panel_body.is_queued_for_deletion() \
		or panel_body.get_parent() != self or panel_body.collision_layer != 1 \
		or panel_body.get_world_3d() != get_world_3d() or panel_body.get_child_count() != 1:
		return false
	var shape := panel_body.get_child(0) as CollisionShape3D
	if not is_instance_valid(shape) or shape.disabled or shape.is_queued_for_deletion() or not shape.shape is BoxShape3D:
		return false
	if _lights.size() != 2 or _lamps.size() != 2 or not is_instance_valid(lever) \
		or lever.get_parent() != self or lever.is_queued_for_deletion() or _bulb == null:
		return false
	for light: OmniLight3D in _lights:
		if not is_instance_valid(light) or not light.is_inside_tree() \
			or light.get_parent() != self or light.is_queued_for_deletion():
			return false
	for lamp: MeshInstance3D in _lamps:
		if not is_instance_valid(lamp) or lamp.get_parent() != self or lamp.is_queued_for_deletion() \
			or lamp.material_override != _bulb:
			return false
	return true

func _box(parent: Node3D, mesh_name: String, size: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = mesh_name
	var box := BoxMesh.new()
	box.size = size
	instance.mesh = box
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)
	if parent == self:
		_owned.append(instance)
	return instance

func _material(color: String, roughness: float, metallic: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color.html(color)
	material.roughness = roughness
	material.metallic = metallic
	return material

func _point(value: Vector3) -> Dictionary:
	return {"x":value.x,"y":value.y,"z":value.z}
