extends Node3D
## Original interior_interactive_safe / interior_safe_source / mercenary_safe_source.
## Controlled native-local ledger; browser URL gating is replaced by is_local.
## Collection/wallet are deliberately unconnected. Native acceptance NOT RUN.
const Squad = preload("res://addons/walk_mercenary/mercenary_squad.gd")
const ASSET := "res://assets/source_safe.glb.bytes"
const ASSET_SHA := "4503b7e50904d2a7187ece196a2782c19dda500a09da4520022f5eddde499db0"
const UID := "local-player"
const OPEN_ANGLE := -112.0 * PI / 180.0
const BODY_BOXES := [
	[Vector3(-.396,.66,0),Vector3(.068,1.24,.68)],
	[Vector3(.396,.66,0),Vector3(.068,1.24,.68)],
	[Vector3(0,.074,0),Vector3(.724,.068,.68)],
	[Vector3(0,1.246,0),Vector3(.724,.068,.68)],
	[Vector3(0,.66,-.306),Vector3(.724,1.104,.068)],
]
var _id := ""
var _building := ""
var _room := ""
var _path := ""
var _host_provider: Callable
var _local_provider: Callable
var _configured := false
var _disposed := false
var _opened := false
var _collected := false
var _loot_dropped := false
var _revision := 0
var _fraction := 0.0
var _loot_fraction := 0.0
var _waiting := false
var _operator := ""
var _pivot: Node3D
var _loot: MeshInstance3D
var _bag: MeshInstance3D
var _visual: Node3D
var _pending: Variant = null
var _pending_action: Variant = null
var _error := ""

func configure(id: String, building_id: String, room_id: String, at: Vector3, yaw: float, get_host: Callable, is_local: Callable, ledger_path: String) -> bool:
	if _configured or _disposed or not _canonical(id,building_id,room_id) or not at.is_finite() or not is_finite(yaw):
		_error = "invalid_configuration"
		return false
	if not get_host.is_valid() or not is_local.is_valid() or ledger_path.is_empty():
		_error = "source_not_connected"
		return false
	_id=id; _building=building_id; _room=room_id
	_host_provider=get_host; _local_provider=is_local
	_path=ProjectSettings.globalize_path(ledger_path)
	if not _path.is_absolute_path() or not _local_allowed():
		_error="standalone_not_allowed"
		return false
	var loaded := _read_store()
	if not loaded.ok:
		_error=loaded.reason
		return false
	position=at; rotation.y=yaw
	if not _build_geometry():
		_error="source_geometry_unavailable"
		return false
	_configured=true
	_apply_store(loaded.state,false)
	return true

func _canonical(id: String, building: String, room: String) -> bool:
	if building.is_empty() or building.length()>160 or id!="interior-safe:"+room or not room.begins_with(building+":floor:"):
		return false
	var expression := RegEx.new()
	expression.compile("^[0-9]+:(main|room:[0-9]+)$")
	return expression.search(room.substr(building.length()+7))!=null

func _local_allowed() -> bool:
	return not _disposed and _local_provider.is_valid() and _local_provider.call()==true

func _build_geometry() -> bool:
	if not FileAccess.file_exists(ASSET) or FileAccess.get_sha256(ASSET)!=ASSET_SHA:
		return false
	var bytes := FileAccess.get_file_as_bytes(ASSET)
	if bytes.size()!=174980: return false
	var document := GLTFDocument.new()
	var state := GLTFState.new()
	if document.append_from_buffer(bytes,"",state)!=OK: return false
	_visual=document.generate_scene(state) as Node3D
	if _visual==null: return false
	_clear_extras(_visual)
	add_child(_visual)
	var door := _visual.find_child("Safe_Hinged_Door",true,false) as MeshInstance3D
	_loot=_visual.find_child("Safe_Source_Loot",true,false) as MeshInstance3D
	_bag=_visual.find_child("Safe_Dropped_Money_Bag",true,false) as MeshInstance3D
	var shell := _visual.find_child("Safe_Hollow_Steel_Body",true,false) as MeshInstance3D
	if door==null or _loot==null or _bag==null or shell==null:
		_visual.free(); _visual=null
		return false
	_pivot=door.get_parent() as Node3D
	if _pivot==null or not _pivot.position.is_equal_approx(Vector3(-.369,0,.352)):
		_visual.free(); _visual=null
		return false
	for row in BODY_BOXES:
		_add_box(self,row[0],row[1])
	_add_box(_pivot,Vector3(.369,.66,.008),Vector3(.738,1.108,.104))
	_publish()
	return true

func _clear_extras(node: Node) -> void:
	for key in node.get_meta_list(): node.remove_meta(key)
	for child in node.get_children(): _clear_extras(child)

func _add_box(parent: Node3D, at: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.collision_layer=1; body.collision_mask=0
	var collider := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size=size; collider.shape=shape; collider.position=at
	body.add_child(collider); parent.add_child(body)

func _point(local: Vector3) -> Dictionary:
	var world := global_transform * local
	return {"x":world.x,"y":world.y,"z":world.z}

func describe() -> Dictionary:
	var normal := global_basis * Vector3(0,0,1)
	return {"id":_id,"sourceId":_id,"kind":"safe","label":"Сейф","object":self,
		"valid":_configured and not _disposed,"buildingId":_building,"roomId":_room,
		"position":_point(Vector3(0,0,1.34)),"approach":_point(Vector3(0,0,1.34)),
		"workPoint":_point(Vector3(-.084,.88,.5)),"workNormal":{"x":normal.x,"y":normal.y,"z":normal.z},
		"workRange":.08,"locked":not _opened,"lockable":true,"opened":_opened,"collected":_collected}

func unlock(effect: Dictionary) -> Squad.PendingEffect:
	if _pending!=null and _pending_action==effect.get("actionId"):
		return _pending
	var ticket := Squad.PendingEffect.new()
	if _pending!=null:
		ticket.settle(_failure("request_conflict"))
		return ticket
	_pending=ticket; _pending_action=effect.get("actionId")
	_unlock_deferred.call_deferred(effect.duplicate(true),ticket)
	return ticket

func _unlock_deferred(effect: Dictionary, ticket: Squad.PendingEffect) -> void:
	var receipt := _unlock_transaction(effect)
	if _pending==ticket:
		_pending=null; _pending_action=null
	ticket.settle(receipt)

func _authorize(effect: Dictionary) -> bool:
	if not _local_allowed() or not _host_provider.is_valid(): return false
	if effect.get("targetId")!=_id or effect.get("kind")!="unlock_safe": return false
	var host: Variant = _host_provider.call()
	if not is_instance_valid(host): return false
	for method in ["get_member","get_action","get_roster","get_actor"]:
		if not host.has_method(method): return false
	var member_id := str(effect.get("memberId",""))
	var member: Variant = host.get_member(member_id)
	var action: Variant = host.get_action(member_id)
	var roster: Variant = host.get_roster()
	if not member is Dictionary or not action is Dictionary or not roster is Dictionary: return false
	if float(member.get("hp",0))<=0 or member.get("available",true)==false: return false
	if action.get("kind")!="unlock_safe" or action.get("targetId")!=_id or action.get("id")!=effect.get("actionId") or action.get("phase") not in ["working","awaiting"]: return false
	for row in roster.get("members",[]):
		if row is Dictionary and row.get("id")==member.get("id"):
			return row.get("profession")=="safecracker"
	return false

func _unlock_transaction(effect: Dictionary) -> Dictionary:
	if _disposed or not _configured: return _failure("disposed" if _disposed else "not_configured")
	if not _local_allowed(): return _failure("standalone_not_allowed")
	if effect.get("targetId")!=_id: return _failure("wrong_target")
	var loaded := _read_store()
	if not loaded.ok: return loaded
	if loaded.state.states.has(_id):
		_apply_store(loaded.state,true)
		return _receipt(loaded.state,true)
	if not _authorize(effect): return _failure("mercenary_not_authorized")
	# No await between read/permission/write: main-thread owner serializes this transaction.
	loaded=_read_store()
	if not loaded.ok: return loaded
	if loaded.state.states.has(_id):
		_apply_store(loaded.state,true)
		return _receipt(loaded.state,true)
	var next: Dictionary = loaded.state.duplicate(true)
	next.states[_id]={"safeId":_id,"buildingId":_building,"roomId":_room,"openedBy":UID,
		"collected":false,"lootDropped":true,"revision":1,"at":int(Time.get_unix_time_from_system()*1000.0)}
	var written := _write_store(next,loaded.bytes)
	if not written.ok: return written
	_operator=str(effect.get("memberId",""))
	_apply_store(next,true)
	return _receipt(next,false)

func collect(_context: Dictionary = {}) -> Dictionary:
	return _failure("collect_not_connected")

func authoritative_receipt(request_id: Variant, operator_id: String = "") -> Dictionary:
	if str(request_id)!=_id+":unlock": return _failure("invalid_request_id")
	if not _configured or not _local_allowed(): return _failure("source_not_connected")
	var loaded := _read_store()
	if not loaded.ok: return loaded
	if not loaded.state.states.has(_id): return _failure("locked")
	var row: Dictionary = loaded.state.states[_id]
	if int(row.get("revision",1))<_revision: return _failure("stale_source_state")
	# Fresh restored authority may differ from the state hydrated at configure.
	# Reconcile its physical owner before acknowledging, retaining the source
	# operator-clearance animation instead of snapping a leaf through an actor.
	if not operator_id.is_empty() and not _restored_operator_valid(operator_id):
		return _failure("reconciliation_operator_invalid")
	if not _opened and operator_id.is_empty():
		return _failure("reconciliation_operator_required")
	if not operator_id.is_empty() and _fraction<1:
		_operator=operator_id
	_apply_store(loaded.state,true)
	var receipt := _receipt(loaded.state,true)
	# Original applySourceState is monotonic even if an equal revision snapshot
	# omits an already-confirmed collected/lootDropped flag.
	receipt.merge({"opened":_opened,"locked":not _opened,"collected":_collected,
		"lootDropped":_loot_dropped,"revision":_revision},true)
	return receipt

func _restored_operator_valid(operator_id: String) -> bool:
	if not _host_provider.is_valid(): return false
	var host: Variant = _host_provider.call()
	if not is_instance_valid(host): return false
	for method in ["get_action","get_actor","get_pending_transactions"]:
		if not host.has_method(method): return false
	var action: Variant = host.get_action(operator_id)
	if not action is Dictionary or action.get("memberId")!=operator_id \
		or action.get("kind")!="unlock_safe" or action.get("targetId")!=_id \
		or action.get("phase")!="awaiting" or action.get("awaiting")!=true:
		return false
	var actor: Variant = host.get_actor(operator_id)
	if not actor is Node3D or not is_instance_valid(actor) or not actor.is_inside_tree() \
		or actor.is_queued_for_deletion() or not actor.global_position.is_finite():
		return false
	var matching_pending := false
	for pending: Variant in host.get_pending_transactions():
		if pending is Dictionary and pending.get("requestId")==action.get("id") \
			and pending.get("memberId")==operator_id and pending.get("targetId")==_id \
			and pending.get("kind")=="unlock_safe":
			matching_pending=true
			break
	return matching_pending and _authorize({"memberId":operator_id,"targetId":_id,
		"kind":"unlock_safe","actionId":action.get("id")})

func _receipt(store: Dictionary, duplicate: bool) -> Dictionary:
	var row: Dictionary = store.states.get(_id,{})
	return {"ok":true,"id":_id,"targetId":_id,"buildingId":_building,"roomId":_room,
		"requestId":_id+":unlock","opened":not row.is_empty(),"locked":row.is_empty(),
		"collected":row.get("collected",true),"lootDropped":row.get("lootDropped",false),
		"revision":row.get("revision",1),"duplicate":duplicate,"gained":0,
		"localBalance":store.balances.get(UID,0),"source":"native-local-preview"}

func _read_store() -> Dictionary:
	if not FileAccess.file_exists(_path):
		return {"ok":true,"state":{"version":1,"states":{},"ledger":[],"balances":{}},"bytes":PackedByteArray()}
	var file := FileAccess.open(_path,FileAccess.READ)
	if file==null: return _failure("storage_unavailable")
	var bytes := file.get_buffer(file.get_length())
	var expected_length := file.get_length()
	file.close()
	if bytes.size()!=expected_length: return _failure("storage_unavailable")
	if bytes.get_string_from_utf8().to_utf8_buffer()!=bytes: return _failure("storage_state_invalid")
	var json := JSON.new()
	if json.parse(bytes.get_string_from_utf8())!=OK or not _valid_store(json.data):
		return _failure("storage_state_invalid")
	return {"ok":true,"state":json.data,"bytes":bytes}

func _whole(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value)==floor(float(value)) and abs(float(value))<=9007199254740991.0

func _valid_store(value: Variant) -> bool:
	if not value is Dictionary or value.get("version")!=1 or not value.get("states") is Dictionary or not value.get("ledger") is Array or not value.get("balances") is Dictionary: return false
	for balance in value.balances.values():
		if not _whole(balance) or balance<0: return false
	for key in value.states:
		var row: Variant = value.states[key]
		if not row is Dictionary or not _canonical(str(key),str(row.get("buildingId","")),str(row.get("roomId",""))) or row.get("safeId")!=key: return false
		if row.has("collected") and not row.collected is bool: return false
		if row.has("lootDropped") and not row.lootDropped is bool: return false
		if not _whole(row.get("revision",1)) or row.get("revision",1)<1 or not _whole(row.get("at")) or row.at<0: return false
		if row.get("collected",true)==false:
			if row.get("lootDropped")!=true or row.get("revision")!=1 or not row.get("openedBy") is String or row.openedBy.is_empty(): return false
		else:
			if not row.get("awardedTo") is String or row.awardedTo.is_empty() or not _whole(row.get("amount")) or row.amount<0 or row.amount>5000: return false
	var awards := {}
	for entry in value.ledger:
		if not entry is Dictionary or not _canonical(str(entry.get("safeId","")),str(entry.get("buildingId","")),str(entry.get("roomId",""))): return false
		if not _whole(entry.get("amount")) or entry.amount<0 or entry.amount>5000 or not entry.get("awardedTo") is String or entry.awardedTo.is_empty(): return false
		if entry.get("requestId") not in [str(entry.safeId)+":unlock",str(entry.safeId)+":collect"] or not _whole(entry.get("at")) or entry.at<0: return false
		if awards.has(entry.safeId) or not value.states.has(entry.safeId): return false
		var saved: Dictionary = value.states[entry.safeId]
		if saved.get("collected",true)!=true or saved.get("amount")!=entry.amount or saved.get("awardedTo")!=entry.awardedTo: return false
		awards[entry.safeId]=true
	for key in value.states:
		if value.states[key].get("collected",true)==true and not awards.has(key): return false
	return true

func _write_store(state: Dictionary, before: PackedByteArray) -> Dictionary:
	if not _valid_store(state): return _failure("storage_state_invalid")
	if not before.is_empty() and not FileAccess.file_exists(_path): return _failure("storage_changed")
	if FileAccess.file_exists(_path) and FileAccess.get_file_as_bytes(_path)!=before: return _failure("storage_changed")
	var parent := _path.get_base_dir()
	if not DirAccess.dir_exists_absolute(parent): return _failure("storage_unavailable")
	var suffix := ".safe-"+str(get_instance_id())+"-"+str(Time.get_ticks_usec())
	var temp := _path+suffix+".tmp"
	var backup := _path+suffix+".bak"
	var bytes := JSON.stringify(state).to_utf8_buffer()
	var file := FileAccess.open(temp,FileAccess.WRITE)
	if file==null: return _failure("storage_unavailable")
	file.store_buffer(bytes); file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error!=OK or FileAccess.get_file_as_bytes(temp)!=bytes:
		DirAccess.remove_absolute(temp)
		return _failure("storage_unavailable")
	var had_original := FileAccess.file_exists(_path)
	if had_original and DirAccess.rename_absolute(_path,backup)!=OK:
		DirAccess.remove_absolute(temp)
		return _failure("storage_unavailable")
	if DirAccess.rename_absolute(temp,_path)!=OK:
		if had_original: DirAccess.rename_absolute(backup,_path)
		DirAccess.remove_absolute(temp)
		return _failure("storage_unavailable")
	if FileAccess.get_file_as_bytes(_path)!=bytes:
		# Retain failed new file for diagnostics; restore exact original if possible.
		DirAccess.rename_absolute(_path,temp)
		if had_original: DirAccess.rename_absolute(backup,_path)
		return _failure("storage_unavailable")
	if had_original: DirAccess.remove_absolute(backup)
	return {"ok":true}

func _apply_store(store: Dictionary, animate: bool) -> void:
	var row: Dictionary = store.states.get(_id,{})
	if row.is_empty() or int(row.get("revision",1))<_revision: return
	_opened=true; _collected=_collected or row.get("collected",true)
	_loot_dropped=_loot_dropped or row.get("lootDropped",false)
	_revision=int(row.get("revision",1))
	if not animate:
		_fraction=1.0; _loot_fraction=1.0; _pivot.rotation.y=OPEN_ANGLE
		_bag.position=Vector3(0,0,1.05)
	_publish()

func _operator_blocks() -> bool:
	if _operator.is_empty(): return false
	if not _host_provider.is_valid(): return true
	var host: Variant = _host_provider.call()
	if not is_instance_valid(host) or not host.has_method("get_actor"): return true
	var actor: Variant = host.get_actor(_operator)
	if not is_instance_valid(actor):
		_operator=""
		return false
	var p: Vector3 = actor.global_position
	if not p.is_finite(): return true
	var hinge := _pivot.global_position
	var scale_xz := maxf(Vector2(global_basis.x.x,global_basis.x.z).length(),Vector2(global_basis.z.x,global_basis.z.z).length())
	return p.y<hinge.y+1.3 and p.y+1.9>hinge.y and Vector2(p.x-hinge.x,p.z-hinge.z).length()<.80*scale_xz+.18*4.1+.08

func advance(dt: float) -> void:
	if not _configured or _disposed or not is_finite(dt): return
	dt=clampf(dt,0,.1)
	if dt<=0 or not _opened: return
	_waiting=_fraction<1 and _operator_blocks()
	if _fraction<1 and not _waiting:
		_fraction=minf(1,_fraction+dt/.85)
		_pivot.rotation.y=OPEN_ANGLE*_fraction*_fraction*(3-2*_fraction)
		if _fraction>=1: _operator=""
	if _loot_dropped and not _collected and _fraction>.45 and _loot_fraction<1:
		_loot_fraction=minf(1,_loot_fraction+dt/.7)
		var t := _loot_fraction
		_bag.position=Vector3(0,maxf(0,.65*(1-t)-.3*t*t)+sin(t*PI*3)*.035*(1-t),.24+.81*t)
		_bag.rotation.z=sin(t*PI*2)*.15*(1-t)
	_publish()

func _publish() -> void:
	set_meta("locked",not _opened); set_meta("mercenaryOpened",_opened)
	if is_instance_valid(_loot): _loot.visible=_opened and not _collected and not _loot_dropped
	if is_instance_valid(_bag): _bag.visible=_opened and not _collected and _loot_dropped and _fraction>.45

func get_state() -> Dictionary:
	return {"id":_id,"buildingId":_building,"roomId":_room,"opened":_opened,"locked":not _opened,
		"collected":_collected,"lootDropped":_loot_dropped,"revision":_revision,"openFraction":_fraction,
		"opening":_opened and (_fraction<1 or (_loot_dropped and not _collected and _loot_fraction<1)),
		"waitingForOperator":_waiting,"pending":"unlock" if _pending!=null else "","disposed":_disposed,
		"configured":_configured,"error":_error,"collectConnected":false}

func _failure(reason: String) -> Dictionary:
	return {"ok":false,"reason":reason}

func dispose() -> void:
	if _disposed: return
	_disposed=true
	if _pending!=null: _pending.settle(_failure("disposed"))
	_pending=null; _host_provider=Callable(); _local_provider=Callable()
	for child in get_children(): child.queue_free()
