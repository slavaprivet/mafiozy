extends RefCounted
## Sole physical execution adapter for the controlled, source-model fixture.
## Gameplay owns routes, steering, substeps and catchup eligibility/confirmations.
## No process loop, navigation solver, fabricated support or replacement actors.
## Call from root's physics tick. Geometry must have actual collision shapes.

const HEIGHT := 1.9
const RADIUS := 0.30
const WALK_SPEED := 3.2 # preview_player.gd:9-11, not member steering policy.
const RUN_SPEED := 5.8
const ACCELERATION := 18.0
const FLOOR_EPSILON := 0.02
const FOOTPRINT_OFFSETS := [Vector2.ZERO, Vector2(-1,-1), Vector2(-1,0),
	Vector2(-1,1), Vector2(0,-1), Vector2(0,1), Vector2(1,-1), Vector2(1,0), Vector2(1,1)]
const EXTERNAL_OWNERS := ["dead", "deathConfirmed", "_mercenaryHospital", "_medicalDowned",
	"_mercenaryConversation", "_playerConversationOpen", "_mercenaryVehicleSeat",
	"_civilianSeat", "_inVehicle", "_inCar", "vehicleId", "vehicle_id", "_carriedByAmbulance",
	"_waterEscaping", "_waterDrowning", "_residentIndoors", "_interiorId"]

var _world: Node3D
var _player_body: CharacterBody3D
var _get_host: Callable
var _configured := false
var _player_stance := "stand"
var _support_excluded: Array[RID] = []
var _capsule := CapsuleShape3D.new()
var _source_box := BoxShape3D.new()
var last_motion: Dictionary = {}
var _writer_leases: Dictionary = {}


func configure(world: Node3D, get_host: Callable) -> bool:
	if not _writer_leases.is_empty():
		return false
	_configured = false
	if not is_instance_valid(world) or not world.is_inside_tree() or not get_host.is_valid():
		return false
	for method: String in ["registered_actor_body", "refresh_actor_coordinates", "original_residents",
		"get_gang", "get_player_position", "source_world_scale", "is_local"]:
		if not world.has_method(method):
			return false
	if not world.player is CharacterBody3D or not _capsule_supported(world.player):
		return false
	_world = world
	_player_body = world.player
	_get_host = get_host
	_configured = true
	_support_excluded.clear()
	_support_excluded.append((world.player as CharacterBody3D).get_rid())
	for row: Dictionary in world.original_residents():
		var body: CharacterBody3D = world.registered_actor_body(row)
		if is_instance_valid(body):
			_support_excluded.append(body.get_rid())
	_capsule.radius = RADIUS
	_capsule.height = HEIGHT
	_source_box.size = Vector3.ONE * (0.36 * float(world.source_world_scale()))
	_source_box.size.y = HEIGHT
	return true


func options() -> Dictionary:
	var result: Dictionary = {}
	for name: String in ["get_member_position", "get_player_state", "get_crowd", "source_path_passable",
		"native_can_move", "body_passable", "ground_height", "apply_motion", "stop_body",
		"face_body", "relocate_body", "placement_ready", "placement_query_point",
		"placement_body_clear", "placement_inside_building", "placement_blocks_vehicle"]:
		result[name] = Callable(self, name)
	return result


func _ready() -> bool:
	return _configured and is_instance_valid(_world) and _world.is_inside_tree() \
		and _world.is_local() and _get_host.is_valid() and is_instance_valid(_player_body) \
		and is_same(_world.player, _player_body)


func _member(id: String) -> Dictionary:
	if not _ready():
		return {}
	var host: Variant = _get_host.call()
	if not host is Object or not is_instance_valid(host) or not host.has_method("member_row"):
		return {}
	var row: Variant = host.member_row(id)
	if not row is Dictionary or str(row.get("id", "")) != id:
		return {}
	var body: CharacterBody3D = _world.registered_actor_body(row)
	if body == null or not _capsule_supported(body):
		return {}
	# Original resident refs remain valid for diagnostics; member execution needs
	# actual current gang identity as well as the current host's exact Dictionary.
	for current: Variant in _world.get_gang():
		if is_same(current, row):
			return row
	return {}


func _movable(row: Dictionary, allow_conversation_yaw: bool = false) -> bool:
	if row.is_empty() or not _number(row.get("hp")) or float(row.hp) <= 0.0:
		return false
	if has_writer_lease(row.get("body") as CharacterBody3D):
		return false
	for key: String in EXTERNAL_OWNERS:
		if allow_conversation_yaw and key in ["_mercenaryConversation", "_playerConversationOpen"]:
			continue
		if _truthy(row.get(key)):
			return false
	return str(row.get("status", "")) != "hospital"


func get_member_position(id: String) -> Variant:
	var row := _member(id)
	if row.is_empty():
		return null
	var actual: Variant = _world.refresh_actor_coordinates(row)
	return actual.duplicate() if actual is Dictionary else null


func get_player_state() -> Dictionary:
	if not _ready() or not is_instance_valid(_world.player):
		return {"alive": false, "position": null}
	var player: CharacterBody3D = _world.player
	var point := _dict(player.global_position)
	return {"position": point, "angle": PI * 0.5 - player.global_rotation.y,
		"stance": _player_stance, "alive": not bool(player.get_meta("dead", false)) \
			and float(player.get_meta("hp", 80.0)) > 0.0,
		"interior": bool(player.get_meta("interior", false)) or placement_inside_building(point),
		"inVehicle": bool(player.get_meta("inVehicle", false))}


func get_crowd() -> Variant:
	# Policy owns the source 1024-row overflow rule and once-per-recovery snapshot.
	# Do not truncate here: overflow must stay visible to that policy.
	var result: Array = []
	if not _ready():
		return null # Gameplay treats non-Array as resolver_unavailable.
	for row: Dictionary in _world.get_residents():
		var body: CharacterBody3D = _world.registered_actor_body(row)
		if body == null:
			return null # Never silently reduce the real resident population.
		_world.refresh_actor_coordinates(row)
		result.append({"id": row.id, "position": _dict(body.global_position),
			"hp": row.get("hp", 0), "dead": row.get("dead", false),
			"_civilianSeat": row.get("_civilianSeat"), "_inVehicle": row.get("_inVehicle"),
			"_inCar": row.get("_inCar")})
	return result


func _space() -> PhysicsDirectSpaceState3D:
	return _world.get_world_3d().direct_space_state if _ready() else null


func _capsule_supported(body: CharacterBody3D) -> bool:
	if not is_instance_valid(body) or not body.is_inside_tree() or body.is_queued_for_deletion():
		return false
	if not body.global_transform.is_finite() or not body.global_basis.get_scale().is_equal_approx(Vector3.ONE):
		return false
	if body.global_basis.y.dot(Vector3.UP) < 0.9999:
		return false
	var count := 0
	for child: Node in body.get_children():
		if not child is CollisionShape3D or child.disabled:
			continue
		count += 1
		if not child.shape is CapsuleShape3D or not is_equal_approx(child.shape.radius, RADIUS) \
				or not is_equal_approx(child.shape.height, HEIGHT) \
				or not child.position.is_equal_approx(Vector3(0, HEIGHT * 0.5, 0)) \
				or not child.basis.is_equal_approx(Basis.IDENTITY):
			return false
	return count == 1 and body.collision_mask != 0


func _actor_rids() -> Array[RID]:
	# Fixture bodies are immutable until teardown/reconfigure, including hires.
	return _support_excluded


func _floor_at(point: Vector3) -> Dictionary:
	var space := _space()
	if space == null or not point.is_finite():
		return {}
	var query := PhysicsRayQueryParameters3D.create(point + Vector3.UP * 0.6,
		point - Vector3.UP * 1.2, 0xFFFFFFFF, _actor_rids())
	query.collide_with_areas = false
	var hit := space.intersect_ray(query)
	if hit.is_empty() or not hit.position.is_finite() or hit.normal.dot(Vector3.UP) < cos(deg_to_rad(46.0)):
		return {}
	var depth: Variant = _tag(hit.get("collider"), "water_depth", 0.0)
	if not _number(depth):
		return {}
	return {"height": float(hit.position.y), "depth": float(depth),
		"blocked": _truthy(_tag(hit.get("collider"), "walk_blocked", false)), "hit": hit}


func ground_height(x: float, z: float) -> float:
	if not _ready() or not is_finite(x) or not is_finite(z):
		return NAN
	var floor := _floor_at(Vector3(x, _world.player.global_position.y, z))
	return float(floor.height) if not floor.is_empty() else NAN


func _overlaps(shape: Shape3D, feet: Vector3, excluded: Array[RID], areas: bool = false) -> Array[Dictionary]:
	var space := _space()
	if space == null:
		return [{"unavailable": true}]
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = shape
	query.transform = Transform3D(Basis.IDENTITY, feet + Vector3.UP * (HEIGHT * 0.5 + FLOOR_EPSILON))
	query.collision_mask = 0xFFFFFFFF
	query.exclude = excluded
	query.collide_with_areas = areas
	return space.intersect_shape(query, 32)


func _footprint(point: Vector3) -> bool:
	if not point.is_finite():
		return false
	var radius := 0.18 * float(_world.source_world_scale())
	var low := INF
	var high := -INF
	for offset: Vector2 in FOOTPRINT_OFFSETS:
		var sample := point + Vector3(offset.x * radius, 0, offset.y * radius)
		var floor := _floor_at(sample)
		if floor.is_empty() or floor.blocked or float(floor.depth) > 0.025:
			return false
		low = minf(low, float(floor.height))
		high = maxf(high, float(floor.height))
	if high - low > 0.28 or absf(point.y - (low + high) * 0.5) > 0.28:
		return false
	return _overlaps(_source_box, Vector3(point.x, high, point.z), _actor_rids()).is_empty()


func source_path_passable(from: Dictionary, to: Dictionary, id: String) -> bool:
	var row := _member(id)
	if not _movable(row) or not _point(from) or not _point(to):
		return false
	return _supported_segment(_vector(from), _vector(to))


func _supported_segment(from: Vector3, to: Vector3) -> bool:
	# Admission only, no route search: sample actual support continuously along
	# the requested edge at less than the native capsule diameter.
	if not from.is_finite() or not to.is_finite() or not _footprint(to):
		return false
	var spacing := 0.14 * float(_world.source_world_scale()) # world.html:9493.
	var count := maxi(1, int(ceil(from.distance_to(to) / spacing)))
	for index in range(count + 1):
		if not _footprint(from.lerp(to, float(index) / float(count))):
			return false
	# Source authored-solid resolver uses a continuous square-footprint sweep,
	# in addition to samples; catch thin fences between sample points.
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = _source_box
	query.transform = Transform3D(Basis.IDENTITY, from + Vector3.UP * (HEIGHT * 0.5 + FLOOR_EPSILON))
	query.motion = to - from
	query.exclude = _actor_rids()
	query.collision_mask = 0xFFFFFFFF
	var fractions: PackedFloat32Array = _space().cast_motion(query)
	return fractions.size() == 2 and fractions[0] >= 1.0


func native_can_move(from: Dictionary, to: Dictionary, id: String) -> bool:
	var row := _member(id)
	if not _movable(row) or not _point(from) or not _point(to):
		return false
	var body: CharacterBody3D = row.body
	var start := body.global_transform
	start.origin = _vector(from) + Vector3.UP * FLOOR_EPSILON
	return not body.test_move(start, _vector(to) - _vector(from), null, 0.001)


func body_passable(point: Dictionary, id: String) -> bool:
	var row := _member(id)
	return _movable(row) and _point(point) and _footprint(_vector(point)) \
		and _capsule_clear(_vector(point), row.body)


func _capsule_clear(point: Vector3, body: CharacterBody3D) -> bool:
	var excluded: Array[RID] = [body.get_rid()]
	return _overlaps(_capsule, point, excluded).is_empty()


func apply_motion(id: String, request: Dictionary) -> bool:
	var row := _member(id)
	if not _movable(row):
		return false
	var displacement: Variant = request.get("displacement")
	var seconds: Variant = request.get("seconds")
	var heading: Variant = request.get("heading")
	if not _number(seconds) or float(seconds) <= 0.0 or not _number(heading):
		return false
	var step: Vector3 = displacement if displacement is Vector3 else _vector(displacement)
	if not step.is_finite() or not _point(request.get("position")):
		return false
	var body: CharacterBody3D = row.body
	var before := body.global_position
	var target := _vector(request.position)
	# Reject a stale request; never substitute an old requested position for reality.
	if Vector2(target.x - before.x - step.x, target.z - before.z - step.z).length() > 0.00001:
		return false
	# Gameplay sends horizontal displacement with y=0 and a separately resolved
	# destination floor. Reconfirm that floor before including the vertical sweep.
	var floor := _floor_at(target)
	if floor.is_empty() or absf(target.y - float(floor.height)) > 0.03:
		return false
	step.y = target.y - before.y
	if not (step / float(seconds)).is_finite():
		return false
	if not _supported_segment(before, target) or not _capsule_clear(target, body):
		body.velocity = Vector3.ZERO
		last_motion = {"id": id, "accepted": false, "reason": "unsupported_or_blocked", "position": _dict(before)}
		return false
	# Explicit displacement consumes caller seconds exactly; move_and_slide would
	# multiply each Gameplay substep by the engine frame delta again.
	body.velocity = step / float(seconds)
	var collision: KinematicCollision3D = body.move_and_collide(step, false, 0.001)
	var actual := body.global_position - before
	body.velocity = actual / float(seconds)
	_world.refresh_actor_coordinates(row)
	face_body(id, float(heading), str(request.get("posture", "stand")))
	last_motion = {"id": id, "accepted": true, "blocked": collision != null,
		"seconds": seconds, "requested": _dict(step), "actual": _dict(actual),
		"position": _dict(body.global_position), "body_id": body.get_instance_id()}
	return step.is_zero_approx() or actual.length_squared() > 0.00000001


func stop_body(id: String, reason: String = "") -> void:
	var row := _member(id)
	if row.is_empty():
		return
	# External seat/death/conversation owners retain their velocity/state.
	if _movable(row):
		(row.body as CharacterBody3D).velocity = Vector3.ZERO
		last_motion = {"id": id, "accepted": true, "reason": reason, "position": get_member_position(id)}


func face_body(id: String, source_heading: float, posture: String = "stand") -> void:
	var row := _member(id)
	# Source facePlayer runs during greeting/conversation while translation stays
	# held. This exception changes yaw only; medical/seat/external owners still win.
	if not _movable(row, true) or not is_finite(source_heading):
		return
	var body: CharacterBody3D = row.body
	body.global_rotation.y = PI * 0.5 - source_heading
	row.ang = source_heading
	body.set_meta("movement_posture", posture) # Inform presentation; no fake gait.


func placement_ready() -> bool:
	return _ready() and _space() != null and is_finite(ground_height(
		_world.player.global_position.x, _world.player.global_position.z))


func placement_query_point(point: Dictionary) -> Dictionary:
	if not _point(point):
		return {"blocked": true, "depth": NAN}
	var y := ground_height(float(point.x), float(point.z))
	if not is_finite(y):
		return {"blocked": true, "depth": NAN}
	var floor := _floor_at(Vector3(float(point.x), y, float(point.z)))
	return {"blocked": bool(floor.get("blocked", true)), "depth": floor.get("depth", NAN)}


func placement_body_clear(point: Dictionary, member_state: Dictionary) -> bool:
	var row := _member(str(member_state.get("id", "")))
	if not _movable(row) or not _point(point):
		return false
	var y := ground_height(float(point.x), float(point.z))
	return is_finite(y) and _capsule_clear(Vector3(float(point.x), y, float(point.z)), row.body)


func placement_inside_building(point: Dictionary) -> bool:
	if not _ready() or not _point(point):
		return true
	return _tagged_volume(_vector(point), "inside_building", 0.01, 0.02)


func placement_blocks_vehicle(point: Dictionary, volume: Dictionary) -> bool:
	if not _ready() or not _point(point) or not _number(volume.get("radius")) or not _number(volume.get("height")):
		return true
	return _tagged_volume(_vector(point), "blocks_vehicle", float(volume.radius), float(volume.height))


func _tagged_volume(point: Vector3, key: String, radius: float, height: float) -> bool:
	if radius <= 0.0 or height <= 0.0:
		return true
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = height
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = shape
	query.transform = Transform3D(Basis.IDENTITY, point + Vector3.UP * (height * 0.5))
	query.collision_mask = 0xFFFFFFFF
	query.collide_with_areas = true
	query.exclude = _actor_rids()
	var hits := _space().intersect_shape(query, 64)
	if hits.size() >= 64:
		return true # Overflow cannot be interpreted as a clear volume.
	for hit: Dictionary in hits:
		if _truthy(_tag(hit.get("collider"), key, false)):
			return true
	return false


func relocate_body(id: String, point: Dictionary, _context: Dictionary) -> bool:
	var row := _member(id)
	if not _movable(row) or not _point(point) or not placement_ready():
		return false
	var destination := _vector(point)
	var floor := _floor_at(destination)
	if floor.is_empty() or absf(destination.y - float(floor.height)) > 0.08:
		return false
	if not _footprint(destination) or not placement_body_clear(point, {"id": id}) \
			or placement_inside_building(_dict(destination + Vector3.UP * 0.9)) \
			or placement_blocks_vehicle(point, {"radius": 0.18 * float(_world.source_world_scale()) * sqrt(2.0), "height": HEIGHT}):
		return false
	var radius := 0.18 * float(_world.source_world_scale())
	for offset: Vector2 in FOOTPRINT_OFFSETS:
		var sample := destination + Vector3(offset.x * radius, 0, offset.y * radius)
		var support := _floor_at(sample)
		if support.is_empty() or placement_inside_building(_dict(Vector3(sample.x, float(support.height) + 0.9, sample.z))):
			return false
	# Gameplay has completed source eligibility and >=60ms two-sample confirmation.
	# Source catchup is a destination-validated relocation, not a swept walk; do
	# not invent a corridor test that rejects source-authorized catchup over walls.
	var body: CharacterBody3D = row.body
	body.velocity = Vector3.ZERO
	body.global_position = destination
	_world.refresh_actor_coordinates(row)
	last_motion = {"id": id, "accepted": true, "reason": "source_catchup",
		"position": _dict(body.global_position), "body_id": body.get_instance_id()}
	return true


func advance_player(seconds: float, direction: Vector3, run: bool = false) -> Dictionary:
	if not _ready() or not is_finite(seconds) or seconds <= 0.0 or not direction.is_finite():
		return {"ok": false, "reason": "invalid_input"}
	var body: CharacterBody3D = _world.player
	if has_writer_lease(body):
		return {"ok":false,"reason":"physical_pose_writer_lease"}
	var state := get_player_state()
	if not state.alive or state.inVehicle or state.interior or bool(body.get_meta("conversation_open", false)):
		return {"ok": false, "reason": "external_owner"}
	direction.y = 0.0
	if direction.length_squared() > 1.0:
		direction = direction.normalized()
	var speed := RUN_SPEED if run else WALK_SPEED
	var velocity := Vector3(move_toward(body.velocity.x, direction.x * speed, ACCELERATION * seconds),
		0, move_toward(body.velocity.z, direction.z * speed, ACCELERATION * seconds))
	var before := body.global_position
	var step := velocity * seconds
	if not step.is_finite():
		return {"ok": false, "reason": "invalid_displacement"}
	var floor := _floor_at(before + step)
	if floor.is_empty():
		body.velocity = Vector3.ZERO
		return {"ok": false, "reason": "unsupported", "position": _dict(before)}
	step.y = float(floor.height) - before.y
	if not _supported_segment(before, before + step):
		body.velocity = Vector3.ZERO
		return {"ok": false, "reason": "unsupported", "position": _dict(before)}
	var hit: KinematicCollision3D = body.move_and_collide(step, false, 0.001)
	body.velocity = (body.global_position - before) / seconds
	if direction.length_squared() > 0.001:
		var target_yaw := atan2(direction.x, direction.z)
		body.global_rotation.y = lerp_angle(body.global_rotation.y, target_yaw, minf(1.0, seconds * 12.0))
	_player_stance = "stand" # Run changes speed, not source stand/crouch/prone posture.
	_world.get_player_position()
	return {"ok": true, "blocked": hit != null, "position": _dict(body.global_position),
		"actual": _dict(body.global_position - before), "body_id": body.get_instance_id()}


func _tag(object: Variant, key: String, fallback: Variant) -> Variant:
	var node: Node = object as Node
	while is_instance_valid(node):
		if node.has_meta(key):
			return node.get_meta(key)
		node = node.get_parent()
	return fallback


func _truthy(value: Variant) -> bool:
	if value == null:
		return false
	if value is bool:
		return value
	if value is int or value is float:
		return float(value) != 0.0 and not is_nan(float(value))
	if value is String:
		return not value.is_empty()
	return true


func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))


func _point(value: Variant) -> bool:
	return value is Dictionary and _number(value.get("x")) and _number(value.get("z")) \
		and (not value.has("y") or _number(value.y))


func _vector(value: Variant) -> Vector3:
	return Vector3(float(value.x), float(value.get("y", 0.0)), float(value.z)) \
		if _point(value) else Vector3(NAN, NAN, NAN)


func _dict(point: Vector3) -> Dictionary:
	return {"x": point.x, "y": point.y, "z": point.z}


func _registered_body(body: CharacterBody3D) -> bool:
	if not _ready() or not is_instance_valid(body) or not body.is_inside_tree() \
		or body.is_queued_for_deletion():
		return false
	if is_same(body,_player_body):
		return true
	for row: Dictionary in _world.original_residents():
		if is_same(_world.registered_actor_body(row),body):
			return true
	return false

func has_writer_lease(body: CharacterBody3D) -> bool:
	if not is_instance_valid(body):
		return false
	return _writer_leases.has(str(body.get_instance_id()))

func acquire_writer_lease(body: CharacterBody3D, lease_id: String) -> bool:
	if not _registered_body(body) or lease_id.is_empty() or has_writer_lease(body):
		return false
	_writer_leases[str(body.get_instance_id())] = {"body":body,"rid":body.get_rid(),"lease_id":lease_id}
	return true

func writer_lease_current(body: CharacterBody3D, lease_id: String) -> bool:
	if not _registered_body(body) or not has_writer_lease(body):
		return false
	var lease: Dictionary = _writer_leases[str(body.get_instance_id())]
	return is_same(lease.body,body) and lease.rid == body.get_rid() and lease.lease_id == lease_id

func release_writer_lease(body: CharacterBody3D, lease_id: String, _reason: String) -> bool:
	# Cleanup uses the original saved body/RID even after its source life retires.
	# A replacement actor or unrelated lease can never release this suspension.
	if not is_instance_valid(body) or not has_writer_lease(body):
		return false
	var key := str(body.get_instance_id())
	var lease: Dictionary = _writer_leases[key]
	if not is_same(lease.body,body) or lease.rid != body.get_rid() or lease.lease_id != lease_id:
		return false
	_writer_leases.erase(key)
	return true

func stop_player() -> void:
	if _ready() and not has_writer_lease(_player_body):
		_player_body.velocity = Vector3.ZERO

func dispose() -> void:
	# The composition must retire the real pose writer leases before this owner.
	if not _writer_leases.is_empty():
		push_error("Physical movement disposed with active pose writer leases")
		return
	_configured = false
	_world = null
	_player_body = null
	_get_host = Callable()
	_support_excluded.clear()
	last_motion.clear()
