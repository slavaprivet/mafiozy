extends RefCounted
## Post-update checkpoint for lifecycle changes which emit no onAction signal,
## including a detached deferred receipt. Never persists inside core.onAction.
## Progress, transforms and remaining timer values are deliberately excluded:
## their continuous changes must not turn normal physics ticks into disk writes.

var _get_core: Callable
var _get_host: Callable
var _save: Callable
var _observed := ""
var _enabled := false
var _saving := false
var _disposed := false
var _attempts := 0
var _last_receipt: Dictionary = {}

func configure(get_core: Callable, get_host: Callable, save: Callable) -> bool:
	if _disposed or _get_core.is_valid() or not get_core.is_valid() \
		or not get_host.is_valid() or not save.is_valid():
		return false
	_get_core = get_core
	_get_host = get_host
	_save = save
	return true

func arm() -> void:
	# Startup restore and world-authority hydration must finish before this call.
	_observed = _signature()
	_enabled = not _observed.is_empty()

func persist(_snapshot: Dictionary = {}, _rows: Array = []) -> Dictionary:
	if _disposed or not _save.is_valid() or _saving:
		return {"ok":false,"reason":"checkpoint_unavailable"}
	_saving = true
	_attempts += 1
	var receipt: Variant = _save.call()
	_last_receipt = receipt.duplicate(true) if receipt is Dictionary \
		else {"ok":false,"reason":"invalid_save_receipt"}
	# Remember an observed attempt even on a blocked save, retaining the actual
	# failure receipt. Explicit save/retry remains available through the owner.
	_observed = _signature()
	_saving = false
	return _last_receipt.duplicate(true)

func after_update() -> Dictionary:
	if not _enabled or _disposed or _saving:
		return {"ok":false,"reason":"checkpoint_inactive"}
	var signature := _signature()
	if signature.is_empty():
		return {"ok":false,"reason":"binding_unavailable"}
	if signature == _observed:
		return {"ok":true,"unchanged":true}
	return persist()

func _signature() -> String:
	if not _get_core.is_valid() or not _get_host.is_valid():
		return ""
	var core: Variant = _get_core.call()
	var host: Variant = _get_host.call()
	if core == null or host == null:
		return ""
	var snapshot: Dictionary = core.snapshot()
	var records: Array = core.get_roster()
	var rows: Array = []
	for record: Dictionary in records:
		# get_roster exposes absolute cooldowns; snapshot exposes diminishing
		# cooldown remaining. Only the former belongs in a semantic signature.
		record.erase("hospitalRemaining")
		var member: Variant = host.member_row(str(record.id))
		var row := {"record":record}
		if member is Dictionary:
			for field in ["hp","alive","dead","_medicalDowned","_mercenaryHospital",
				"_mercenaryOrder","_mercenaryRally","_mercenaryVehicleExplosionFatal"]:
				if member.has(field):
					row[field] = member[field]
		rows.append(row)
	return JSON.stringify({"sequence":snapshot.get("sequence"),
		"settledActionIds":snapshot.get("settledActionIds",[]),
		"pendingTransactions":snapshot.get("pendingTransactions",[]),
		"charges":snapshot.get("charges",[]),"members":rows},"",true)

func diagnostics() -> Dictionary:
	return {"enabled":_enabled,"disposed":_disposed,"attempts":_attempts,
		"last_receipt":_last_receipt.duplicate(true)}

func dispose() -> void:
	_disposed = true
	_enabled = false
	_get_core = Callable()
	_get_host = Callable()
	_save = Callable()
