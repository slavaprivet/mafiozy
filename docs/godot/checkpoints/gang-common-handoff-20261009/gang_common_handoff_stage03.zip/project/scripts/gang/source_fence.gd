extends Node3D
## mercenary_fences.mjs: source cage geometry and intrinsic collision owner.
## `at` is the cage origin in metres; target identity belongs to its north panel.
const PANEL_SUFFIX := ":north-panel"
const SECTIONS := [Vector4(-3,-2.5,-1.2,-2.5), Vector4(1.2,-2.5,3,-2.5),
	Vector4(-3,-2.5,-3,2.5), Vector4(3,-2.5,3,2.5), Vector4(-3,2.5,3,2.5)]

var target_id := ""
var site_id := ""
var panel: Node3D
var left: Node3D
var right: Node3D
var cut_body: StaticBody3D
var _fixed_bodies: Array[StaticBody3D] = []
var _owned: Array[Node3D] = []
var _wire: StandardMaterial3D
var _cylinder: CylinderMesh
var _is_cut := false
var _configured := false
var _disposed := false
var _rod_count := 0

func configure(id: String, at: Vector3, yaw: float = 0.0) -> bool:
	if _configured or _disposed or not id.ends_with(PANEL_SUFFIX) \
		or id.length() <= PANEL_SUFFIX.length() or not at.is_finite() or not is_finite(yaw):
		return false
	target_id = id
	site_id = id.trim_suffix(PANEL_SUFFIX)
	name = "Print_Shop_Service_Wire_Cage"
	position = at
	rotation.y = yaw
	_wire = StandardMaterial3D.new()
	_wire.albedo_color = Color.html("727872")
	_wire.metallic = .5
	_wire.roughness = .75
	_cylinder = CylinderMesh.new()
	_cylinder.top_radius = 1.0
	_cylinder.bottom_radius = 1.0
	_cylinder.height = 1.0
	_cylinder.radial_segments = 5
	_cylinder.rings = 0
	var fixed_rods: Array = []
	for section: Vector4 in SECTIONS:
		fixed_rods.append_array(_net(section))
	_rods(self, fixed_rods, "Fixed_Wire_Nets")
	var posts: Array = []
	for point: Vector2 in [Vector2(-3,-2.5),Vector2(-1.2,-2.5),Vector2(1.2,-2.5),
		Vector2(3,-2.5),Vector2(-3,2.5),Vector2(3,2.5)]:
		posts.append([Vector3(point.x,0,point.y),Vector3(point.x,2.22,point.y),.045])
	_rods(self, posts, "Cage_Posts")
	var roof: Array = []
	for index in 31:
		var x := -3.0 + index * .2
		roof.append([Vector3(x,2.18,-2.5),Vector3(x,2.18,2.5),.008])
	for index in 26:
		var z := -2.5 + index * .2
		roof.append([Vector3(-3,2.18,z),Vector3(3,2.18,z),.008])
	for z: float in [-2.5,0.0,2.5]:
		roof.append([Vector3(-3,2.18,z),Vector3(3,2.18,z),.03])
	_rods(self, roof, "Cage_Roof_Mesh")
	panel = Node3D.new()
	panel.name = "WireFence_Cuttable_North"
	panel.position.z = -2.5
	panel.set_meta("gang_target_id", target_id)
	panel.set_meta("mercenaryCut", false)
	# The source invisible ray proxy is a picking volume, never physics.
	panel.set_meta("source_pick_aabb", AABB(Vector3(-1.2,0,-.0175),Vector3(2.4,2,.035)))
	add_child(panel)
	_owned.append(panel)
	left = Node3D.new()
	left.name = "Left_Cut_Mesh"
	left.position.x = -1.2
	panel.add_child(left)
	right = Node3D.new()
	right.name = "Right_Cut_Mesh"
	right.position.x = 1.2
	panel.add_child(right)
	_rods(left, _net(Vector4(0,0,1.2,0)), "Left_Wire_Net")
	_rods(right, _net(Vector4(-1.2,0,0,0)), "Right_Wire_Net")
	for index in SECTIONS.size():
		_fixed_bodies.append(_section_body(SECTIONS[index],site_id+":fixed:"+str(index)))
	_fixed_bodies.append(_solid(Vector3(0,2.185,0),Vector3(6,.09,5),site_id+":roof"))
	cut_body = _section_body(Vector4(-1.2,-2.5,1.2,-2.5),target_id)
	_configured = true
	return true

func describe() -> Variant:
	if _disposed or not _configured or not is_inside_tree() or not is_instance_valid(panel) \
		or not panel.is_visible_in_tree() or panel.is_queued_for_deletion():
		return null
	return {"id":target_id,"kind":"fence","sourceId":target_id,"object":panel,
		"position":_point(panel.to_global(Vector3(0,0,-.92))),
		"center":_point(panel.global_position),"valid":true,"destroyed":false,
		"cut":_is_cut,"cuttable":not _is_cut,"workRange":.08,
		"workPoint":_point(panel.to_global(Vector3(0,.65,-.018))),
		"workNormal":_point((panel.global_basis*Vector3(0,0,-1)).normalized()),
		"label":"Сетчатый забор · прорезать проход",
		"highlightBounds":{"min":[-1.22,.05,-.05],"max":[1.22,2.03,.05]}}

func cut(effect: Dictionary = {}) -> Dictionary:
	if _disposed or not _configured or not is_inside_tree() or is_queued_for_deletion():
		return {"ok":false,"reason":"disposed"}
	if effect.has("targetId") and effect.targetId != target_id:
		return {"ok":false,"reason":"wrong_target"}
	if _is_cut:
		return {"ok":true,"alreadyCut":true,"cut":true,"targetId":target_id}
	if not _connected(cut_body) or not is_instance_valid(panel) \
		or not is_instance_valid(left) or not is_instance_valid(right):
		return {"ok":false,"reason":"collision_not_connected"}
	if panel.get_parent() != self or not panel.is_inside_tree() or panel.is_queued_for_deletion() \
		or left.get_parent() != panel or right.get_parent() != panel \
		or left.is_queued_for_deletion() or right.is_queued_for_deletion():
		return {"ok":false,"reason":"collision_not_connected"}
	for body: StaticBody3D in _fixed_bodies:
		if not _connected(body):
			return {"ok":false,"reason":"collision_not_connected"}
	# Only the original cutBody is removed. Fixed padding (.12 each side), roof
	# and six posts remain source-sized; no collider follows the folding wire.
	var removed_id := cut_body.get_instance_id()
	cut_body.collision_layer = 0
	cut_body.collision_mask = 0
	_owned.erase(cut_body)
	remove_child(cut_body)
	cut_body.queue_free()
	cut_body = null
	_is_cut = true
	left.rotation.y = PI - .06
	right.rotation.y = -PI + .06
	panel.set_meta("mercenaryCut", true)
	panel.remove_meta("source_pick_aabb")
	return {"ok":true,"cut":true,"targetId":target_id,"removedCollider":removed_id}

func get_state() -> Dictionary:
	return {"id":target_id,"siteId":site_id,"cut":_is_cut,"disposed":_disposed,
		"cutColliderConnected":_connected(cut_body),"fixedColliderCount":_fixed_bodies.size(),
		"nominalGapWidth":2.4,"sourcePaddedClearWidth":2.16,"rodInstances":_rod_count,
		"leftAngle":left.rotation.y if is_instance_valid(left) else 0.0,
		"rightAngle":right.rotation.y if is_instance_valid(right) else 0.0}

func advance(_dt: float) -> void:
	pass # Source cut folds immediately; no fabricated animation timer.

func dispose() -> void:
	if _disposed:
		return
	_disposed = true
	for child: Node3D in _owned:
		if not is_instance_valid(child):
			continue
		if child is StaticBody3D:
			child.collision_layer = 0
			child.collision_mask = 0
		if child.get_parent() == self:
			remove_child(child)
		child.queue_free()
	_owned.clear()
	_fixed_bodies.clear()
	_wire = null
	_cylinder = null
	# Root keeps the disposed registry owner until it frees the common scene.

func _net(section: Vector4) -> Array:
	var from := Vector3(section.x,0,section.y)
	var to := Vector3(section.z,0,section.w)
	var segments: Array = []
	var count := ceili(from.distance_to(to)/.16)
	for index in range(count+1):
		var point := from.lerp(to,float(index)/count)
		segments.append([point+Vector3.UP*.12,point+Vector3.UP*1.95,.008])
	for index in 12:
		var height := .12 + index*.16
		segments.append([from+Vector3.UP*height,to+Vector3.UP*height,.008])
	segments.append([from+Vector3.UP*2,to+Vector3.UP*2,.027])
	return segments

func _rods(parent: Node3D, segments: Array, mesh_name: String) -> void:
	var instances := MultiMesh.new()
	instances.transform_format = MultiMesh.TRANSFORM_3D
	instances.mesh = _cylinder
	instances.instance_count = segments.size()
	for index in segments.size():
		var segment: Array = segments[index]
		var from: Vector3 = segment[0]
		var to: Vector3 = segment[1]
		var radius: float = segment[2]
		var direction := to-from
		var basis := Basis(Quaternion(Vector3.UP,direction.normalized()))
		basis = basis * Basis.from_scale(Vector3(radius,direction.length(),radius))
		instances.set_instance_transform(index,Transform3D(basis,(from+to)*.5))
	var mesh := MultiMeshInstance3D.new()
	mesh.name = mesh_name
	mesh.multimesh = instances
	mesh.material_override = _wire
	parent.add_child(mesh)
	if parent == self:
		_owned.append(mesh)
	_rod_count += segments.size()

func _section_body(section: Vector4, id: String) -> StaticBody3D:
	var minimum := Vector2(minf(section.x,section.z)-.12,minf(section.y,section.w)-.12)
	var maximum := Vector2(maxf(section.x,section.z)+.12,maxf(section.y,section.w)+.12)
	return _solid(Vector3((minimum.x+maximum.x)*.5,1.05,(minimum.y+maximum.y)*.5),
		Vector3(maximum.x-minimum.x,2.1,maximum.y-minimum.y),id)

func _solid(at: Vector3, size: Vector3, id: String) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = "SourceFenceCollision"
	body.position = at
	body.collision_layer = 1
	body.collision_mask = 1
	body.set_meta("source_collider_id",id)
	body.set_meta("mercenaryFenceId",site_id)
	var collision := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	collision.shape = box
	body.add_child(collision)
	add_child(body)
	_owned.append(body)
	return body

func _connected(body: StaticBody3D) -> bool:
	if not is_instance_valid(body) or not body.is_inside_tree() or body.is_queued_for_deletion() \
		or body.get_parent() != self or body.get_world_3d() != get_world_3d() or body.collision_layer != 1:
		return false
	if body.get_child_count() != 1:
		return false
	var shape := body.get_child(0) as CollisionShape3D
	return is_instance_valid(shape) and not shape.disabled and not shape.is_queued_for_deletion() \
		and shape.shape is BoxShape3D

func _point(value: Vector3) -> Dictionary:
	return {"x":value.x,"y":value.y,"z":value.z}
