extends RefCounted
## Bounded source port: world.html17835-17853,9688-9729,19193-19235.
## UNBOUND until actual source navigation/budget/lifecycle providers are supplied.
## No invented speed, straight-line escape, actor spawn, or squad/core tick.
const SCALE := 4.1
const REQUIRED := ["now_ms","random01","authorize_effect","claim_body","release_body",
	"cancel_interruptions","source_waypoint_ok","source_point_passable","source_sweep",
	"reserve_route_work","route_work_expired","finish_route_work","ground_support",
	"pick_waypoint","record_simulation_tick"]
const DIRECTIONS := [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]
var _world: Node
var _services: Dictionary = {}
var _active: Dictionary = {}
var _receipts: Dictionary = {}
var _completed: Array = []
var _disposed := false
var _last_frame := -1
var last_error := ""

func configure(world: Node, services: Dictionary) -> bool:
	if _disposed or is_instance_valid(_world) or not is_instance_valid(world): return false
	for method in ["original_resident","source_body","get_residents","get_gang","source_world_scale"]:
		if not world.has_method(method):
			last_error="original_registry_unavailable:"+method
			return false
	if world.source_world_scale()!=SCALE:
		last_error="source_world_scale_mismatch"
		return false
	for method: String in REQUIRED:
		var callback: Variant = services.get(method)
		if not callback is Callable or not callback.is_valid():
			last_error="source_dependency_unavailable:"+method
			return false
	# Source grid is still dynamic MAP_COLS, not guessed from this fixture floor.
	if not services.get("map_columns") is int or services.map_columns<=0:
		last_error="source_map_columns_unavailable"
		return false
	_world=world; _services=services.duplicate()
	return true

func _call(name: String, args: Array = []) -> Variant:
	var callback: Callable = _services.get(name,Callable())
	return callback.callv(args) if callback.is_valid() else null

func _number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))

func _truth(value: Variant) -> bool:
	if value==null: return false
	if value is bool: return value
	if value is int or value is float: return value!=0 and not is_nan(float(value))
	if value is String: return not value.is_empty()
	return true

func _original(row: Dictionary) -> CharacterBody3D:
	if _disposed or not is_instance_valid(_world): return null
	var id := str(row.get("id",""))
	var actual: Variant = _world.original_resident(id)
	if not actual is Dictionary or not is_same(actual,row): return null
	var present := false
	for candidate in _world.get_residents():
		if is_same(candidate,row): present=true; break
	if not present: return null
	var body: Variant = _world.source_body(id)
	if not body is CharacterBody3D or not is_instance_valid(body) or body!=row.get("body") \
		or not body.is_inside_tree() or body.is_queued_for_deletion() or not body.global_position.is_finite(): return null
	for member in _world.get_gang():
		if member is Dictionary and member.get("body")==body: return null
	return body

func _eligible(row: Dictionary) -> bool:
	if _truth(row.get("dead")) or row.get("alive",true)==false or (_number(row.get("hp")) and float(row.hp)<=0): return false
	for flag in ["_empireBoss","_guard","_invulnerable"]:
		if _truth(row.get(flag)): return false
	return true

func _witness_able(row: Dictionary, now: float) -> bool:
	if not _eligible(row): return false
	for flag in ["_medicalDowned","_policeCuffed","_hostile","_fighting","_fightingMelee"]:
		if _truth(row.get(flag)): return false
	for field in ["_knockedUntil","_meleeStunnedUntil","_empireDownUntil"]:
		if float(row.get(field,0))>now: return false
	return true

func _admitted_row(row: Dictionary, body: CharacterBody3D) -> bool:
	if body==null or not _number(row.get("speed")) or not _number(row.get("r")) \
		or not _number(row.get("c")) or not _number(row.get("walkPhase")): return false
	if absf(float(row.r)*SCALE-body.global_position.z)>.001 or absf(float(row.c)*SCALE-body.global_position.x)>.001: return false
	var arc: Variant = row.get("_arc")
	if arc!=null and (not arc is Dictionary or (arc.has("panicMult") and not _number(arc.panicMult))): return false
	# These source update branches own motion before panic; never steal their body.
	for field in ["_npcInitialPlacementPending","_vehicleHijackControlled","_hijackReaction",
		"_civilianTrip","_civilianTripRiding","_residentNativeVisit","_residentIndoors",
		"_inVehicle","_inCar","_carriedByAmbulance","_ambulanceInTransit","_waterEscaping"]:
		if _truth(row.get(field)): return false
	return true

func apply_intimidation(row: Dictionary, attacker: Dictionary, effect: Dictionary) -> Dictionary:
	var body := _original(row)
	if not _admitted_row(row,body): return _fail("source_row_or_body_dependencies_unavailable")
	if not _eligible(row): return _fail("source_intimidation_rejected")
	var now: Variant = _call("now_ms")
	if not _number(now) or not _number(attacker.get("r")) or not _number(attacker.get("c")): return _fail("source_clock_or_attacker_unavailable")
	var key := str(effect.get("actionId",""))
	if key.is_empty() or effect.get("kind")!="intimidate": return _fail("invalid_effect")
	var signature := str(effect.get("targetId",""))+"@"+str(effect.get("memberId",""))
	if _receipts.has(key):
		return _receipts[key].receipt.duplicate(true) if _receipts[key].signature==signature else _fail("request_conflict")
	if _call("authorize_effect",[row,attacker,effect])!=true: return _fail("source_authority_unavailable")
	# Provider checks upstream medical/transport/AI ownership and claims THIS body.
	if _call("claim_body",[row,body,self])!=true: return _fail("civilian_body_owner_unavailable")
	# Genuine corpse-phone/social/activity owners must perform source cancellation.
	# Callback returns false before mutations when its actual dependencies are absent.
	if _call("cancel_interruptions",[row,"intimidated"])!=true:
		_call("release_body",[row,body,self])
		return _fail("source_interruption_owners_unavailable")
	row._intimidatedUntil=float(now)+60000
	row._hostile=false; row._fighting=false; row._fightingMelee=false
	var submitted := _truth(row.get("_witnessReportNonce")) and row.get("_witnessReportSentNonce")==row.get("_witnessReportNonce")
	if submitted: row._witnessIntimidatedSubmittedNonce=row._witnessReportNonce
	if _truth(row.get("snitching")):
		row.snitching=false; row.snitchUntil=0; row._witnessCallUntil=0
		row._witnessStage="report_pending" if submitted else "intimidated"
	row._witnessRetreatUntil=0; row._weaponSeenSince=0
	if _witness_able(row,float(now)):
		row.panicUntil=maxf(float(row.get("panicUntil",0)),float(now)+8000)
		row.panicSrcR=attacker.r; row.panicSrcC=attacker.c
		row._panicStyle="flee"; row._panicFreezeUntil=0; row._panicCowerUntil=0; row._panicCallUntil=0; row.idleUntil=0
		row._lifeState="panic"; row._lifeGesture="flee"; row._lifeStateUntil=row.panicUntil
		if row.get("_routeKind")!="panic": _clear_route(row)
		_active[str(row.id)]={"row":row,"body":body,"moved_metres":0.0,"steps":0,"last_result":"admitted"}
	else:
		_call("release_body",[row,body,self])
	# mercenary_world.js:566 host effect adds the source three-second cry.
	row.cryText="Не трогай меня!"; row.cryUntil=float(now)+3000
	var receipt := {"ok":true,"targetId":effect.targetId,"requestId":effect.get("requestId",effect.actionId),
		"bodyInstanceId":body.get_instance_id(),"panicMotionAdmitted":_active.has(str(row.id)),"physicalMotionObserved":false}
	_receipts[key]={"signature":signature,"receipt":receipt}
	if _receipts.size()>4096: _receipts.erase(_receipts.keys()[0])
	return receipt

func advance(dt: float) -> void:
	if _disposed or not is_instance_valid(_world) or not is_finite(dt) or dt<=0: return
	var frame := Engine.get_physics_frames()
	if frame==_last_frame: return
	_last_frame=frame
	var now: Variant = _call("now_ms")
	if not _number(now): return
	for id: String in _active.keys():
		var active: Dictionary = _active[id]
		var row: Dictionary = active.row
		var body := _original(row)
		if body!=active.body or not _admitted_row(row,body) or not _witness_able(row,float(now)):
			_release(id,"body_or_lifecycle_changed")
			continue
		# Panic is important in _npcSimulationDelta: current dt, no distant carry.
		if _call("record_simulation_tick",[row,dt,float(now)])!=true:
			_release(id,"source_simulation_counter_unavailable")
			continue
		row.walking=false
		var before := body.global_position
		active.last_result=_panic_step(row,body,dt,float(now))
		active.moved_metres+=body.global_position.distance_to(before)
		active.steps+=1
		if float(row.get("panicUntil",0))==0: _release(id,str(active.last_result))

func _panic_step(row: Dictionary, body: CharacterBody3D, dt: float, now: float) -> String:
	if float(row.get("panicUntil",0))<=now:
		var random: Variant = _call("random01")
		if not _number(random) or random<0 or random>=1: return "source_rng_unavailable"
		row.panicUntil=0; row.idleUntil=now+800+float(random)*800
		_call("pick_waypoint",[row])
		return "panic_expired"
	var arc: Variant = row.get("_arc")
	if arc is Dictionary and arc.get("panicMult")==0:
		row.panicUntil=0; _clear_route(row)
		return "source_no_panic_archetype"
	# Intimidation sets all hold counters to zero; a new external panic owner
	# supersedes this scoped lease instead of silently approximating its branch.
	if float(row.get("_panicFreezeUntil",0))>now or float(row.get("_panicCowerUntil",0))>now or float(row.get("_panicCallUntil",0))>now or row.get("_panicStyle")!="flee":
		_release(str(row.id),"different_panic_owner")
		return "different_panic_owner"
	var sr := float(row.panicSrcR) if _number(row.get("panicSrcR")) else float(row.r)
	var sc := float(row.panicSrcC) if _number(row.get("panicSrcC")) else float(row.c)
	var distance := Vector2(float(row.r)-sr,float(row.c)-sc).length()
	var multiplier := float(arc.panicMult) if arc is Dictionary and _truth(arc.get("panicMult")) else 2.5
	var route: Variant = row.get("_route")
	if (row.get("_routeKind")!="panic" or not route is Array or route.is_empty()) and now>=float(row.get("_routeRetryAt",0)):
		_clear_route(row)
		if not _plan_escape(row,sr,sc): row._routeRetryAt=now+450
	var speed := minf(maxf(0,float(row.speed)*multiplier),7.80/SCALE)
	var moved := _advance_route(row,body,dt,speed)
	if moved=="blocked":
		if not _truth(row.get("_routeBlockedAt")): row._routeBlockedAt=now
		if now-float(row._routeBlockedAt)>350: _clear_route(row)
	elif moved=="arrived":
		_clear_route(row)
		if distance<=14 and not _plan_escape(row,sr,sc): row._routeRetryAt=now+450
	if distance>14:
		row.panicUntil=0; _clear_route(row)
	return moved

func _clear_route(row: Dictionary) -> void:
	row._npcWanderSearch=null; row._route=null; row._routeIndex=0
	row._routeGoalR=null; row._routeGoalC=null; row._routeBlockedAt=0

func _plan_escape(row: Dictionary, threat_r: float, threat_c: float) -> bool:
	row._npcWanderSearch=null
	if _call("reserve_route_work",[row])!=true: return false
	var start := Vector2i(floori(float(row.r)),floori(float(row.c)))
	var columns: int = _services.map_columns
	var start_key := start.x*columns+start.y
	var first := {"r":start.x,"c":start.y,"key":start_key,"depth":0}
	var queue := [first]
	var nodes := {}
	nodes[start_key]=first
	var initial := Vector2(float(row.r)-threat_r,float(row.c)-threat_c).length()
	var best: Dictionary = first
	var best_score := initial*5
	var index := 0
	while index<queue.size() and nodes.size()<620 and _call("route_work_expired")!=true:
		var current: Dictionary = queue[index]
		index+=1
		var safe_distance := Vector2(float(current.r)+.5-threat_r,float(current.c)+.5-threat_c).length()
		var score := safe_distance*5+float(current.depth)*.12
		if score>best_score: best_score=score; best=current
		if int(current.depth)>=14: continue
		for direction: Vector2i in DIRECTIONS:
			var r := int(current.r)+direction.x
			var c := int(current.c)+direction.y
			var key := r*columns+c
			if nodes.has(key) or _call("source_waypoint_ok",[row,r+.5,c+.5])!=true: continue
			var next := {"r":r,"c":c,"key":key,"depth":int(current.depth)+1,"parent":current.key}
			nodes[key]=next; queue.append(next)
	_call("finish_route_work",[row])
	if is_same(best,first) or Vector2(float(best.r)+.5-threat_r,float(best.c)+.5-threat_c).length()<initial+.75: return false
	var route: Array = []
	var node: Dictionary = best
	while int(node.key)!=start_key:
		route.append({"r":float(node.r)+.5,"c":float(node.c)+.5})
		node=nodes[node.parent]
	route.reverse()
	row._npcWanderSearch=null; row._route=route; row._routeIndex=0; row._routeKind="panic"
	row._routeGoalR=route[-1].r; row._routeGoalC=route[-1].c; row._routeBlockedAt=0
	row.tr=route[0].r; row.tc=route[0].c
	return true

func _path_passable(row: Dictionary, fr: float, fc: float, tr: float, tc: float) -> bool:
	var samples := maxi(1,ceili(Vector2(tr-fr,tc-fc).length()/.14))
	for index in range(1,samples+1):
		var t := float(index)/samples
		var r := fr+(tr-fr)*t
		var c := fc+(tc-fc)*t
		for offset in [Vector2.ZERO,Vector2(-.18,-.18),Vector2(-.18,.18),Vector2(.18,-.18),Vector2(.18,.18)]:
			if _call("source_point_passable",[row,r+offset.x,c+offset.y])!=true: return false
	var swept: Variant = _call("source_sweep",[row,Vector2(fr,fc),Vector2(tr,tc),.18])
	return swept is Dictionary and swept.get("swept")==true and swept.get("blocked")==false

func _advance_route(row: Dictionary, body: CharacterBody3D, dt: float, speed: float) -> String:
	var route: Variant = row.get("_route")
	if not route is Array or route.is_empty(): return "no_route"
	var index := int(row.get("_routeIndex",0))
	if index<0 or index>=route.size(): return "invalid_source_route"
	for point: Variant in route:
		if not point is Dictionary or not _number(point.get("r")) or not _number(point.get("c")): return "invalid_source_route"
	var target: Dictionary = route[index]
	var delta := Vector2(float(target.r)-float(row.r),float(target.c)-float(row.c))
	var distance := delta.length()
	if distance<.34:
		if index+1>=route.size(): return "arrived"
		index+=1; row._routeIndex=index; target=route[index]
		row.tr=target.r; row.tc=target.c
		delta=Vector2(float(target.r)-float(row.r),float(target.c)-float(row.c)); distance=delta.length()
	var step := minf(speed*dt,distance)
	var next := Vector2(float(row.r),float(row.c))+delta/maxf(.001,distance)*step
	if not _path_passable(row,float(row.r),float(row.c),next.x,next.y): return "blocked"
	var wanted := Vector3(next.y*SCALE,body.global_position.y,next.x*SCALE)
	var floor_state: Variant = _call("ground_support",[row,body,wanted])
	if not floor_state is Dictionary or floor_state.get("ok")!=true or not _number(floor_state.get("feet_y")): return "blocked"
	wanted.y=float(floor_state.feet_y)
	var motion := wanted-body.global_position
	# Native admission is additional to the exact source path query. No teleport,
	# second body or second controller: move the borrowed body through physics.
	if body.test_move(body.global_transform,motion): return "blocked"
	var collision := body.move_and_collide(motion)
	var actual := body.global_position
	row.r=actual.z/SCALE; row.c=actual.x/SCALE
	row.position={"x":actual.x,"y":actual.y,"z":actual.z}
	if collision!=null or actual.distance_to(wanted)>.001: return "blocked"
	row.ang=atan2(delta.x,delta.y); body.global_rotation.y=PI*.5-float(row.ang)
	row.walkPhase=float(row.walkPhase)+dt*14; row.walking=true; row._routeBlockedAt=0
	return "moved"

func _release(id: String, reason: String) -> void:
	if not _active.has(id): return
	var active: Dictionary = _active[id]
	active.row.walking=false
	_call("release_body",[active.row,active.body,self])
	_completed.append({"id":id,"bodyInstanceId":active.body.get_instance_id() if is_instance_valid(active.body) else 0,
		"movedMetres":active.moved_metres,"steps":active.steps,"reason":reason})
	if _completed.size()>64: _completed.pop_front()
	_active.erase(id)
	last_error=reason

func diagnostics() -> Dictionary:
	var rows: Array = []
	for id: String in _active:
		var active: Dictionary = _active[id]
		rows.append({"id":id,"bodyInstanceId":active.body.get_instance_id(),"movedMetres":active.moved_metres,
			"steps":active.steps,"lastResult":active.last_result})
	return {"bound":is_instance_valid(_world),"active":rows,"completed":_completed.duplicate(true),
		"lastError":last_error,"nativeAcceptance":"NOT_RUN"}

func _fail(reason: String) -> Dictionary:
	return {"ok":false,"reason":reason}

func dispose() -> void:
	for id: String in _active.keys(): _release(id,"disposed")
	_disposed=true; _services.clear(); _receipts.clear(); _world=null
