extends Node3D
## Local, stationary civilian car lock owner, not a building-door substitute.
## mercenary_vehicle_locks.js owns lock semantics; real imported vehicle art and
## source oracle dimensions own presentation/collision. No drive/board/damage AI.
const Visual = preload("res://scripts/vehicle_visual/vehicle_visual.gd")
const CATALOGUE := "res://assets/vehicle_visual/manifest.json"
const ORACLE := "res://assets/vehicle_visual/vehicle_factory_oracle.v1.json"
const CATALOGUE_SHA := "13dc4703d74f12be8ba9010d8a61e04b6015d21dbf69d2f41b980a75eda89c9b"
const ORACLE_SHA := "d2a7943d34009350f37a59c7238f46d9d1ee714f7826fdf69033c8014b4df2af"
const PROFILE_ID := "compact_sedan"
const WORLD_SCALE := 4.1
const COMPLETED_LIMIT := 4096

# Source Map belongs to the lock service, not to an individual car. Keep it
# across this module's multiple cars/disposals for same-ID target conflicts.
static var _completed: Dictionary = {}
var car_row: Dictionary = {} # Actual native CARS-equivalent row, not UI state.
var local_enabled := true # Explicit local-preview realm; no server authority.
var last_error := ""
var _target_id := ""
var _source_id := ""
var _get_host: Callable
var _visual: RefCounted
var _body: StaticBody3D
var _shape: CollisionShape3D
var _profile: Dictionary = {}
var _configured := false
var _disposed := false
var _side_sign := 0.0


func configure(target_id: String, source_id: String, at: Vector3, yaw: float, get_host: Callable) -> bool:
	if _configured or _disposed or not is_inside_tree() or target_id.is_empty() \
			or _key(source_id).is_empty() or not at.is_finite() or not is_finite(yaw) or not get_host.is_valid():
		return _configuration_failure("invalid_configuration")
	var host: Variant = get_host.call()
	if not _host_supported(host):
		return _configuration_failure("host_authority_missing")
	if not _file_matches(CATALOGUE, CATALOGUE_SHA) or not _file_matches(ORACLE, ORACLE_SHA):
		return _configuration_failure("source_asset_pin_mismatch")
	var catalogue: Dictionary = Visual.load_catalogue(CATALOGUE)
	if not catalogue.get("ok", false) or not catalogue.entries.has(PROFILE_ID):
		return _configuration_failure("source_visual_missing")
	var oracle: Variant = JSON.parse_string(FileAccess.get_file_as_string(ORACLE))
	if not oracle is Dictionary or oracle.get("schema") != "mafiozi.transport.vehicle-factory-oracle.v1":
		return _configuration_failure("oracle_invalid")
	var factory: Dictionary = {}
	for row: Dictionary in oracle.get("profiles", []):
		if row.get("profile_id") == PROFILE_ID:
			factory = row
			break
	var entry: Dictionary = catalogue.entries[PROFILE_ID]
	if factory.is_empty() or factory.get("runtime_profile") != entry.get("runtime_profile") \
			or factory.get("source_glb_sha256") != entry.get("source_glb_sha256"):
		return _configuration_failure("oracle_visual_profile_mismatch")
	_profile = factory.runtime_profile.duplicate(true)
	for field: String in ["half_width_m", "half_length_m", "height_m"]:
		if not _finite(_profile.get(field)) or float(_profile[field]) <= 0.0:
			return _configuration_failure("collision_dimensions_invalid")
	var made: Dictionary = Visual.instantiate_visual(entry, catalogue.base_path)
	if not made.get("ok", false):
		return _configuration_failure(str(made.get("error", "visual_import_rejected")))
	_visual = made.visual
	_target_id = target_id
	_source_id = _key(source_id)
	_get_host = get_host
	# Asset already contains the exporter +Z -> -Z basis conversion. Native yaw
	# is applied once to this owner; do not rotate imported doors/vertices again.
	global_position = at
	global_rotation = Vector3(0, yaw, 0)
	if not global_basis.get_scale().is_equal_approx(Vector3.ONE):
		_visual.dispose()
		_visual = null
		return _configuration_failure("unscaled_vehicle_owner_required")
	add_child(_visual.root)
	_body = StaticBody3D.new()
	_body.name = "SourceParkedChassis"
	_body.collision_layer = 1
	_body.collision_mask = 1
	_body.set_meta("blocks_vehicle", true)
	_body.set_meta("sourceId", _source_id)
	_shape = CollisionShape3D.new()
	_shape.name = "SourceOracleCollision"
	var box := BoxShape3D.new()
	box.size = Vector3(float(_profile.half_width_m) * 2.0, float(_profile.height_m),
		float(_profile.half_length_m) * 2.0)
	_shape.shape = box
	var bounds: Dictionary = _profile.bounds_source_m
	_shape.position.y = float(bounds.min[1]) + float(_profile.height_m) * 0.5
	_body.add_child(_shape)
	add_child(_body)
	set_meta("sourceVehicleId", _source_id)
	set_meta("blocks_vehicle", true)
	set_meta("collisionHalfWidth", _profile.half_width_m)
	car_row = {"id": _source_id.trim_prefix("vehicle_"), "sourceId": _source_id,
		"profile_id": PROFILE_ID, "parked": true, "civilian": true, "_lockpicked": false}
	_configured = true
	_refresh_car_pose()
	last_error = ""
	return true


func _configuration_failure(reason: String) -> bool:
	last_error = reason
	return false


func _file_matches(path: String, expected_sha: String) -> bool:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() <= 0 or file.get_length() > 4194304:
		return false
	return Visual._sha(file.get_buffer(file.get_length())) == expected_sha


func _host_supported(host: Variant) -> bool:
	if not host is Object or not is_instance_valid(host):
		return false
	for method: String in ["get_action", "get_member", "get_roster", "member_row", "get_actor"]:
		if not host.has_method(method):
			return false
	return true


func _live() -> bool:
	return _configured and not _disposed and is_inside_tree() and is_visible_in_tree() \
		and is_instance_valid(_body) and _body.is_inside_tree() and not _body.is_queued_for_deletion() \
		and is_instance_valid(_shape) and not _shape.disabled and _shape.shape is BoxShape3D \
		and _visual != null and is_instance_valid(_visual.root) and _visual.root.is_inside_tree() \
		and _visual.root.is_visible_in_tree() and not _visual.root.is_queued_for_deletion() \
		and global_transform.is_finite() and global_basis.get_scale().is_equal_approx(Vector3.ONE)


func _refresh_car_pose() -> void:
	car_row.r = global_position.z / WORLD_SCALE
	car_row.c = global_position.x / WORLD_SCALE
	car_row.ang = -PI * 0.5 - global_rotation.y # Exported vehicle nose is -Z.


func _intact() -> bool:
	if not _live():
		return false
	for key: String in ["wrecked", "_wrecked", "_shotWrecked", "_destroySequenceAt", "_hidden", "_towed"]:
		if _truth(car_row.get(key)):
			return false
	return not (_finite(car_row.get("hp")) and float(car_row.hp) <= 0.0)


func _locks() -> Dictionary:
	if not local_enabled or not _live():
		return {"available": false, "locked": false, "lockpickable": false, "reason": "source_vehicle_unavailable"}
	var allowed: bool = _intact() and car_row.get("parked") == true
	return {"available": true, "sourceId": _source_id, "locked": allowed and car_row.get("_lockpicked") != true,
		"lockpickable": allowed, "reason": "" if allowed else "only_parked_civilian_supported"}


func describe() -> Dictionary:
	if not _live():
		return {}
	_refresh_car_pose()
	var camera: Camera3D = get_viewport().get_camera_3d()
	if _side_sign == 0.0:
		if not is_instance_valid(camera):
			return {} # Actual source observer required; no invented nearest side.
		_side_sign = -1.0 if global_basis.x.dot(camera.global_position - global_position) < 0.0 else 1.0
	var normal := global_basis.x.normalized() * _side_sign
	var half_width := float(_profile.half_width_m)
	var approach := global_position + normal * (half_width + 0.84)
	var contact := global_position + normal * half_width + Vector3.UP * 0.65
	var locks := _locks()
	return {"id": _target_id, "kind": "vehicle", "object": self, "sourceId": _source_id,
		"position": _point(approach), "center": _point(global_position),
		"workPoint": _point(contact), "workNormal": _point(normal), "workRange": 0.08,
		"valid": _intact(), "destroyed": not _intact(), "wrecked": _truth(car_row.get("wrecked")),
		"locked": locks.locked, "lockpickable": locks.lockpickable, "lockable": true,
		"bombable": false, "opened": get_meta("mercenaryOpened", false) == true,
		"label": "Припаркованный автомобиль"}


func unlock(target: Dictionary, effect: Dictionary) -> Dictionary:
	if not local_enabled:
		return {"ok": false, "reason": "server_unlock_not_connected"}
	var source_value: Variant = target.get("sourceId")
	if not _truth(source_value):
		source_value = target.get("id", "")
	var source_id := _key("" if source_value == null else str(source_value))
	var action_value: Variant = effect.get("actionId")
	var action_key := "" if action_value == null else str(action_value)
	if action_key.is_empty():
		return {"ok": false, "reason": "action_required"}
	# Source idempotency precedes subsequent actor/car-state checks.
	if _completed.has(action_key):
		return {"ok": true, "duplicate": true} if _completed[action_key] == source_id \
			else {"ok": false, "reason": "action_target_mismatch"}
	if not _live() or source_id != _source_id or target.get("id") != _target_id \
			or target.get("kind") != "vehicle" or not is_same(target.get("object"), self):
		return {"ok": false, "reason": "vehicle_unavailable"}
	var host: Variant = _get_host.call() if _get_host.is_valid() else null
	if not _host_supported(host):
		return {"ok": false, "reason": "specialist_action_unconfirmed"}
	var member_id := str(effect.get("memberId", ""))
	var action: Variant = host.get_action(member_id)
	var member: Variant = host.get_member(member_id)
	var operator: Dictionary = host.member_row(member_id)
	var profession := ""
	var roster: Dictionary = host.get_roster()
	for row: Dictionary in roster.get("members", []):
		if str(row.get("id", "")) == member_id:
			profession = str(row.get("profession", ""))
			break
	if profession != "safecracker" or not action is Dictionary or action.get("kind") != "unlock_door" \
			or str(action.get("id", "")) != action_key or action.get("targetId") != effect.get("targetId") \
			or effect.get("targetId") != _target_id or action.get("phase") not in ["working", "awaiting"] \
			or not _finite(action.get("progress")) or float(action.progress) < 1.0 \
			or not member is Dictionary or not _finite(member.get("hp")) or float(member.hp) <= 0.0 \
			or _truth(member.get("dead")) or _truth(member.get("downed")) or member.get("available") == false:
		return {"ok": false, "reason": "specialist_action_unconfirmed"}
	var body: CharacterBody3D = operator.get("body") as CharacterBody3D
	if not is_instance_valid(body) or not body.is_inside_tree() or body.is_queued_for_deletion() \
			or not is_same(host.get_actor(member_id), body) or not _physical_operator_allowed(operator, body):
		return {"ok": false, "reason": "specialist_action_unconfirmed"}
	if not _intact() or car_row.get("parked") != true:
		return {"ok": false, "reason": "vehicle_unavailable"}
	_refresh_car_pose()
	if not body.global_position.is_finite() or Vector2(body.global_position.x - float(car_row.c) * WORLD_SCALE,
		body.global_position.z - float(car_row.r) * WORLD_SCALE).length() > 4.5:
		return {"ok": false, "reason": "specialist_out_of_range"}
	car_row._lockpicked = true
	_completed[action_key] = source_id
	if _completed.size() > COMPLETED_LIMIT:
		_completed.erase(_completed.keys()[0])
	# 'opened' is the original receipt vocabulary. Unlocking changes the lock,
	# never the source visual door angle, chassis geometry or seat/driving state.
	return {"ok": true, "opened": true, "sourceId": source_id}


func _physical_operator_allowed(row: Dictionary, body: CharacterBody3D) -> bool:
	if not _finite(row.get("hp")) or float(row.hp) <= 0.0 or _truth(row.get("dead")) \
			or _truth(row.get("_mercenaryHospital")):
		return false
	# Resolve local authority through the actual body's public registry API,
	# never by copying a requested position or inspecting private host options.
	var ancestor: Node = body.get_parent()
	while is_instance_valid(ancestor):
		if ancestor.has_method("registered_actor_body") and ancestor.has_method("is_local"):
			return ancestor.is_local() == true and is_same(ancestor.registered_actor_body(row), body)
		ancestor = ancestor.get_parent()
	return false


func door_access(door_id: String) -> Dictionary:
	# Actual lock-state query for a future boarding owner, not a boarding permit.
	var locks := _locks()
	var known: bool = _visual != null and _visual.doors.has(door_id)
	return {"available": known and locks.available, "locked": locks.locked,
		"unlocked": known and locks.lockpickable and car_row.get("_lockpicked") == true,
		"doorId": door_id, "sourceId": _source_id, "boardingConnected": false}


func get_state() -> Dictionary:
	if _live():
		_refresh_car_pose()
	return {"ready": _live(), "error": last_error, "targetId": _target_id,
		"sourceId": _source_id, "car": car_row.duplicate(true), "locks": _locks(),
		"profile": _profile.duplicate(true), "bodyId": _body.get_instance_id() if is_instance_valid(_body) else 0,
		"completed_count": _completed.size(), "damageConnected": false, "drivingConnected": false,
		"physicalDoorsOpened": false}


func _key(id: String) -> String:
	return id.trim_prefix("traffic:")


func _finite(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))


func _truth(value: Variant) -> bool:
	if value == null:
		return false
	if value is bool:
		return value
	if value is int or value is float:
		return float(value) != 0.0 and not is_nan(float(value))
	if value is String:
		return not value.is_empty()
	return true


func _point(value: Vector3) -> Dictionary:
	return {"x": value.x, "y": value.y, "z": value.z}


func dispose() -> void:
	if _disposed:
		return
	_disposed = true
	_configured = false
	_get_host = Callable()
	if is_instance_valid(_body):
		_body.collision_layer = 0
		_body.collision_mask = 0
		_body.queue_free()
	if _visual != null:
		_visual.dispose()
	_visual = null
	_body = null
	_shape = null


func _exit_tree() -> void:
	dispose()
